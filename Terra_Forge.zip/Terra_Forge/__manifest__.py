{
    "schema_version": "1.0.0",
    "id": "terrain_generator",
    "version": "1.0.0",
    "name": "Terra Forge",
    "tagline": "Generate procedural terrain with materials and vegetation",
    "maintainer": "Amélie Schroeder, amelieschroeder.ch@gmail.com",
    "type": "add-on",
    "tags": ["Mesh", "Procedural", "Terrain"],
    "blender_version_min": "4",
    "license": [
        "SPDX:GPL-3.0-or-later"
    ],
    "copyright": [
        "2024 Amélie Schroeder"
    ],
    "website": "",
    "permissions": {
        "files": "Import/export terrain data",
        "network": false,
        "clipboard": false,
        "camera": false,
        "microphone": false
    }
}