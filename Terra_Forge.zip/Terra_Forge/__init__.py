#Single addon file less problematic when downloading
#Node to Python Addon for Shaders!


bl_info = {
    "name": "TerraForge",
    "author": "Amélie Schroeder",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Add > Mesh",
    "description": "Generate procedural terrain with materials and vegetation",
    "category": "Add Mesh",
    "support": "COMMUNITY",
}

import bpy
import mathutils
from bpy.props import BoolProperty, IntProperty, FloatProperty, PointerProperty

# MATERIAL CREATION FUNCTIONS 
def create_ice_material():
    mat = bpy.data.materials.new(name = "Ice2")
    mat.use_nodes = True
    #initialize Ice2 node group
    def ice2_node_group():

        ice2 = mat.node_tree
        #start with a clean node tree
        for node in ice2.nodes:
            ice2.nodes.remove(node)
        ice2.color_tag = 'NONE'
        ice2.description = ""
        ice2.default_group_node_width = 140
        

        #ice2 interface

        #initialize ice2 nodes
        #node Principled BSDF
        principled_bsdf = ice2.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'MULTI_GGX'
        principled_bsdf.subsurface_method = 'RANDOM_WALK'
        #Base Color
        principled_bsdf.inputs[0].default_value = (0.31691184639930725, 0.6636978387832642, 0.8000156879425049, 1.0)
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Specular Tint
        principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 1.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Material Output
        material_output = ice2.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Color Ramp
        color_ramp = ice2.nodes.new("ShaderNodeValToRGB")
        color_ramp.name = "Color Ramp"
        color_ramp.color_ramp.color_mode = 'RGB'
        color_ramp.color_ramp.hue_interpolation = 'NEAR'
        color_ramp.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
        color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
        color_ramp_cre_0.position = 0.5400000214576721
        color_ramp_cre_0.alpha = 1.0
        color_ramp_cre_0.color = (0.21814706921577454, 0.21814706921577454, 0.21814706921577454, 1.0)

        color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.7599999904632568)
        color_ramp_cre_1.alpha = 1.0
        color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)


        #node Noise Texture
        noise_texture = ice2.nodes.new("ShaderNodeTexNoise")
        noise_texture.name = "Noise Texture"
        noise_texture.noise_dimensions = '3D'
        noise_texture.noise_type = 'FBM'
        noise_texture.normalize = True
        #Scale
        noise_texture.inputs[2].default_value = 4.199999809265137
        #Detail
        noise_texture.inputs[3].default_value = 8.0
        #Roughness
        noise_texture.inputs[4].default_value = 0.5
        #Lacunarity
        noise_texture.inputs[5].default_value = 2.0
        #Distortion
        noise_texture.inputs[8].default_value = 0.0

        #node Texture Coordinate
        texture_coordinate = ice2.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.from_instancer = False

        #node Bump
        bump = ice2.nodes.new("ShaderNodeBump")
        bump.name = "Bump"
        bump.invert = False
        #Strength
        bump.inputs[0].default_value = 0.05999999865889549
        #Distance
        bump.inputs[1].default_value = 1.0

        #node Bump.001
        bump_001 = ice2.nodes.new("ShaderNodeBump")
        bump_001.name = "Bump.001"
        bump_001.invert = False
        #Strength
        bump_001.inputs[0].default_value = 0.20000000298023224
        #Distance
        bump_001.inputs[1].default_value = 1.0
        #Normal
        bump_001.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Color Ramp.001
        color_ramp_001 = ice2.nodes.new("ShaderNodeValToRGB")
        color_ramp_001.name = "Color Ramp.001"
        color_ramp_001.color_ramp.color_mode = 'RGB'
        color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_001.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
        color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
        color_ramp_001_cre_0.position = 0.4699999988079071
        color_ramp_001_cre_0.alpha = 1.0
        color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.7699999809265137)
        color_ramp_001_cre_1.alpha = 1.0
        color_ramp_001_cre_1.color = (0.29240360856056213, 0.29240360856056213, 0.29240360856056213, 1.0)


        #node Noise Texture.001
        noise_texture_001 = ice2.nodes.new("ShaderNodeTexNoise")
        noise_texture_001.name = "Noise Texture.001"
        noise_texture_001.noise_dimensions = '3D'
        noise_texture_001.noise_type = 'FBM'
        noise_texture_001.normalize = True
        #Scale
        noise_texture_001.inputs[2].default_value = 4.0
        #Detail
        noise_texture_001.inputs[3].default_value = 8.0
        #Roughness
        noise_texture_001.inputs[4].default_value = 0.800000011920929
        #Lacunarity
        noise_texture_001.inputs[5].default_value = 2.0
        #Distortion
        noise_texture_001.inputs[8].default_value = 0.0

        #node Displacement
        displacement = ice2.nodes.new("ShaderNodeDisplacement")
        displacement.name = "Displacement"
        displacement.space = 'OBJECT'
        #Midlevel
        displacement.inputs[1].default_value = 0.5
        #Scale
        displacement.inputs[2].default_value = 0.10000000149011612
        #Normal
        displacement.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Voronoi Texture
        voronoi_texture = ice2.nodes.new("ShaderNodeTexVoronoi")
        voronoi_texture.name = "Voronoi Texture"
        voronoi_texture.distance = 'EUCLIDEAN'
        voronoi_texture.feature = 'F1'
        voronoi_texture.normalize = False
        voronoi_texture.voronoi_dimensions = '3D'
        #Scale
        voronoi_texture.inputs[2].default_value = 5.0
        #Detail
        voronoi_texture.inputs[3].default_value = 0.05000000074505806
        #Roughness
        voronoi_texture.inputs[4].default_value = 0.30000001192092896
        #Lacunarity
        voronoi_texture.inputs[5].default_value = 2.0
        #Randomness
        voronoi_texture.inputs[8].default_value = 1.0

        #node Mapping
        mapping = ice2.nodes.new("ShaderNodeMapping")
        mapping.name = "Mapping"
        mapping.vector_type = 'POINT'
        #Location
        mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Scale
        mapping.inputs[3].default_value = (1.0, 1.0, 1.0)

        #node Texture Coordinate.001
        texture_coordinate_001 = ice2.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_001.name = "Texture Coordinate.001"
        texture_coordinate_001.from_instancer = False


        #Set locations
        principled_bsdf.location = (10.0, 300.0)
        material_output.location = (985.4541625976562, 284.3935546875)
        color_ramp.location = (-321.40802001953125, 271.47735595703125)
        noise_texture.location = (-596.8087768554688, 297.5543518066406)
        texture_coordinate.location = (-842.8753662109375, 269.1257019042969)
        bump.location = (-223.7842559814453, -32.943389892578125)
        bump_001.location = (-424.294921875, -306.1869812011719)
        color_ramp_001.location = (-769.402587890625, -293.295654296875)
        noise_texture_001.location = (-428.71881103515625, 23.876541137695312)
        displacement.location = (810.1715698242188, 34.117149353027344)
        voronoi_texture.location = (632.0584716796875, 21.142066955566406)
        mapping.location = (458.5825500488281, 36.74848175048828)
        texture_coordinate_001.location = (289.365478515625, 31.121047973632812)

        #Set dimensions
        principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
        material_output.width, material_output.height = 140.0, 100.0
        color_ramp.width, color_ramp.height = 240.0, 100.0
        noise_texture.width, noise_texture.height = 140.0, 100.0
        texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
        bump.width, bump.height = 140.0, 100.0
        bump_001.width, bump_001.height = 140.0, 100.0
        color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
        noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
        displacement.width, displacement.height = 140.0, 100.0
        voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
        mapping.width, mapping.height = 140.0, 100.0
        texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0

        #initialize ice2 links
        #principled_bsdf.BSDF -> material_output.Surface
        ice2.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
        #color_ramp.Color -> principled_bsdf.Roughness
        ice2.links.new(color_ramp.outputs[0], principled_bsdf.inputs[2])
        #noise_texture.Fac -> color_ramp.Fac
        ice2.links.new(noise_texture.outputs[0], color_ramp.inputs[0])
        #texture_coordinate.Object -> noise_texture.Vector
        ice2.links.new(texture_coordinate.outputs[3], noise_texture.inputs[0])
        #bump.Normal -> principled_bsdf.Normal
        ice2.links.new(bump.outputs[0], principled_bsdf.inputs[5])
        #bump_001.Normal -> bump.Normal
        ice2.links.new(bump_001.outputs[0], bump.inputs[3])
        #color_ramp_001.Color -> bump_001.Height
        ice2.links.new(color_ramp_001.outputs[0], bump_001.inputs[2])
        #noise_texture_001.Fac -> bump.Height
        ice2.links.new(noise_texture_001.outputs[0], bump.inputs[2])
        #texture_coordinate.Object -> noise_texture_001.Vector
        ice2.links.new(texture_coordinate.outputs[3], noise_texture_001.inputs[0])
        #noise_texture.Fac -> color_ramp_001.Fac
        ice2.links.new(noise_texture.outputs[0], color_ramp_001.inputs[0])
        #displacement.Displacement -> material_output.Displacement
        ice2.links.new(displacement.outputs[0], material_output.inputs[2])
        #mapping.Vector -> voronoi_texture.Vector
        ice2.links.new(mapping.outputs[0], voronoi_texture.inputs[0])
        #voronoi_texture.Color -> displacement.Height
        ice2.links.new(voronoi_texture.outputs[1], displacement.inputs[0])
        #texture_coordinate_001.Generated -> mapping.Vector
        ice2.links.new(texture_coordinate_001.outputs[0], mapping.inputs[0])
        return ice2

    ice2_node_group()
    return mat


def create_sand_desert_material():
    if "sand" in bpy.data.materials:
        return bpy.data.materials["sand"]

    mat = bpy.data.materials.new(name = "sand")
    mat.use_nodes = True
    #initialize vector scale node group
    def vector_scale_node_group():

        vector_scale = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "vector scale")

        vector_scale.color_tag = 'NONE'
        vector_scale.description = ""
        vector_scale.default_group_node_width = 140
        

        #vector_scale interface
        #Socket Vector
        vector_socket = vector_scale.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket.default_value = (0.0, 0.0, 0.0)
        vector_socket.min_value = 0.0
        vector_socket.max_value = 0.0
        vector_socket.subtype = 'NONE'
        vector_socket.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_1 = vector_scale.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_1.default_value = (0.0, 0.0, 0.0)
        vector_socket_1.min_value = -10000.0
        vector_socket_1.max_value = 10000.0
        vector_socket_1.subtype = 'NONE'
        vector_socket_1.attribute_domain = 'POINT'

        #Socket Value
        value_socket = vector_scale.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
        value_socket.default_value = 0.5
        value_socket.min_value = -10000.0
        value_socket.max_value = 10000.0
        value_socket.subtype = 'NONE'
        value_socket.attribute_domain = 'POINT'


        #initialize vector_scale nodes
        #node Separate XYZ
        separate_xyz = vector_scale.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"

        #node Math.005
        math_005 = vector_scale.nodes.new("ShaderNodeMath")
        math_005.name = "Math.005"
        math_005.operation = 'DIVIDE'
        math_005.use_clamp = False
        #Value
        math_005.inputs[0].default_value = 1.0

        #node Math.002
        math_002 = vector_scale.nodes.new("ShaderNodeMath")
        math_002.name = "Math.002"
        math_002.operation = 'MULTIPLY'
        math_002.use_clamp = False

        #node Math.003
        math_003 = vector_scale.nodes.new("ShaderNodeMath")
        math_003.name = "Math.003"
        math_003.operation = 'MULTIPLY'
        math_003.use_clamp = False

        #node Math.004
        math_004 = vector_scale.nodes.new("ShaderNodeMath")
        math_004.name = "Math.004"
        math_004.operation = 'MULTIPLY'
        math_004.use_clamp = False

        #node Combine XYZ
        combine_xyz = vector_scale.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz.name = "Combine XYZ"

        #node Group Input
        group_input = vector_scale.nodes.new("NodeGroupInput")
        group_input.name = "Group Input"

        #node Group Output
        group_output = vector_scale.nodes.new("NodeGroupOutput")
        group_output.name = "Group Output"
        group_output.is_active_output = True


        #Set locations
        separate_xyz.location = (-249.12030029296875, -55.39402770996094)
        math_005.location = (-245.85919189453125, 132.30279541015625)
        math_002.location = (86.083740234375, 137.73651123046875)
        math_003.location = (95.06280517578125, 16.468490600585938)
        math_004.location = (98.80413818359375, -137.73651123046875)
        combine_xyz.location = (249.12030029296875, -31.975540161132812)
        group_input.location = (-449.12030029296875, -0.0)
        group_output.location = (449.12030029296875, -0.0)

        #Set dimensions
        separate_xyz.width, separate_xyz.height = 140.0, 100.0
        math_005.width, math_005.height = 140.0, 100.0
        math_002.width, math_002.height = 140.0, 100.0
        math_003.width, math_003.height = 140.0, 100.0
        math_004.width, math_004.height = 140.0, 100.0
        combine_xyz.width, combine_xyz.height = 140.0, 100.0
        group_input.width, group_input.height = 140.0, 100.0
        group_output.width, group_output.height = 140.0, 100.0

        #initialize vector_scale links
        #combine_xyz.Vector -> group_output.Vector
        vector_scale.links.new(combine_xyz.outputs[0], group_output.inputs[0])
        #group_input.Vector -> separate_xyz.Vector
        vector_scale.links.new(group_input.outputs[0], separate_xyz.inputs[0])
        #separate_xyz.X -> math_002.Value
        vector_scale.links.new(separate_xyz.outputs[0], math_002.inputs[0])
        #separate_xyz.Y -> math_003.Value
        vector_scale.links.new(separate_xyz.outputs[1], math_003.inputs[0])
        #separate_xyz.Z -> math_004.Value
        vector_scale.links.new(separate_xyz.outputs[2], math_004.inputs[0])
        #math_002.Value -> combine_xyz.X
        vector_scale.links.new(math_002.outputs[0], combine_xyz.inputs[0])
        #math_003.Value -> combine_xyz.Y
        vector_scale.links.new(math_003.outputs[0], combine_xyz.inputs[1])
        #math_004.Value -> combine_xyz.Z
        vector_scale.links.new(math_004.outputs[0], combine_xyz.inputs[2])
        #math_005.Value -> math_002.Value
        vector_scale.links.new(math_005.outputs[0], math_002.inputs[1])
        #math_005.Value -> math_003.Value
        vector_scale.links.new(math_005.outputs[0], math_003.inputs[1])
        #math_005.Value -> math_004.Value
        vector_scale.links.new(math_005.outputs[0], math_004.inputs[1])
        #group_input.Value -> math_005.Value
        vector_scale.links.new(group_input.outputs[1], math_005.inputs[1])
        return vector_scale

    vector_scale = vector_scale_node_group()

    #initialize sand node group
    def sand_node_group():

        sand = mat.node_tree
        #start with a clean node tree
        for node in sand.nodes:
            sand.nodes.remove(node)
        sand.color_tag = 'NONE'
        sand.description = ""
        sand.default_group_node_width = 140
        

        #sand interface

        #initialize sand nodes
        #node Material Output
        material_output = sand.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        #Displacement
        material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Principled BSDF
        principled_bsdf = sand.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'MULTI_GGX'
        principled_bsdf.subsurface_method = 'BURLEY'
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf.inputs[3].default_value = 1.4500000476837158
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 1.0, 1.0)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Specular Tint
        principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf.inputs[27].default_value = (0.0, 0.0, 0.0, 1.0)
        #Emission Strength
        principled_bsdf.inputs[28].default_value = 1.0
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Voronoi Texture
        voronoi_texture = sand.nodes.new("ShaderNodeTexVoronoi")
        voronoi_texture.name = "Voronoi Texture"
        voronoi_texture.distance = 'EUCLIDEAN'
        voronoi_texture.feature = 'F1'
        voronoi_texture.normalize = False
        voronoi_texture.voronoi_dimensions = '3D'
        #Scale
        voronoi_texture.inputs[2].default_value = 2000.0
        #Detail
        voronoi_texture.inputs[3].default_value = 0.0
        #Roughness
        voronoi_texture.inputs[4].default_value = 0.5
        #Lacunarity
        voronoi_texture.inputs[5].default_value = 2.0
        #Randomness
        voronoi_texture.inputs[8].default_value = 1.0

        #node Math.001
        math_001 = sand.nodes.new("ShaderNodeMath")
        math_001.name = "Math.001"
        math_001.operation = 'MULTIPLY'
        math_001.use_clamp = False
        #Value_001
        math_001.inputs[1].default_value = 0.10000000149011612

        #node ColorRamp
        colorramp = sand.nodes.new("ShaderNodeValToRGB")
        colorramp.name = "ColorRamp"
        colorramp.color_ramp.color_mode = 'RGB'
        colorramp.color_ramp.hue_interpolation = 'NEAR'
        colorramp.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        colorramp.color_ramp.elements.remove(colorramp.color_ramp.elements[0])
        colorramp_cre_0 = colorramp.color_ramp.elements[0]
        colorramp_cre_0.position = 0.06363635510206223
        colorramp_cre_0.alpha = 1.0
        colorramp_cre_0.color = (0.8009858727455139, 0.48958122730255127, 0.29771724343299866, 1.0)

        colorramp_cre_1 = colorramp.color_ramp.elements.new(1.0)
        colorramp_cre_1.alpha = 1.0
        colorramp_cre_1.color = (0.9040948152542114, 0.6356258392333984, 0.31681424379348755, 1.0)


        #node Geometry
        geometry = sand.nodes.new("ShaderNodeNewGeometry")
        geometry.name = "Geometry"

        #node SCALE
        scale = sand.nodes.new("ShaderNodeValue")
        scale.label = "scale"
        scale.name = "SCALE"
        scale.use_custom_color = True
        scale.color = (0.6079999804496765, 0.12015260756015778, 0.09485706686973572)

        scale.outputs[0].default_value = 2.0
        #node Image Texture
        image_texture = sand.nodes.new("ShaderNodeTexImage")
        image_texture.name = "Image Texture"
        image_texture.extension = 'REPEAT'
        if "sand.jpg" in bpy.data.images:
            image_texture.image = bpy.data.images["sand.jpg"]
        image_texture.image_user.frame_current = 0
        image_texture.image_user.frame_duration = 1
        image_texture.image_user.frame_offset = -1
        image_texture.image_user.frame_start = 1
        image_texture.image_user.tile = 0
        image_texture.image_user.use_auto_refresh = False
        image_texture.image_user.use_cyclic = False
        image_texture.interpolation = 'Linear'
        image_texture.projection = 'BOX'
        image_texture.projection_blend = 0.10000000149011612

        #node Mapping
        mapping = sand.nodes.new("ShaderNodeMapping")
        mapping.name = "Mapping"
        mapping.vector_type = 'TEXTURE'
        #Location
        mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Scale
        mapping.inputs[3].default_value = (2.0, 2.0, 2.0)

        #node Math
        math = sand.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.operation = 'ADD'
        math.use_clamp = False

        #node Reroute
        reroute = sand.nodes.new("NodeReroute")
        reroute.name = "Reroute"
        reroute.socket_idname = "NodeSocketFloat"
        #node Math.006
        math_006 = sand.nodes.new("ShaderNodeMath")
        math_006.name = "Math.006"
        math_006.operation = 'MULTIPLY'
        math_006.use_clamp = False

        #node Math.007
        math_007 = sand.nodes.new("ShaderNodeMath")
        math_007.name = "Math.007"
        math_007.operation = 'MULTIPLY'
        math_007.use_clamp = False
        #Value_001
        math_007.inputs[1].default_value = 0.07999999821186066

        #node Bump
        bump = sand.nodes.new("ShaderNodeBump")
        bump.name = "Bump"
        bump.invert = False
        #Strength
        bump.inputs[0].default_value = 0.4590908885002136
        #Distance
        bump.inputs[1].default_value = 0.10000000149011612
        #Normal
        bump.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node ColorRamp.001
        colorramp_001 = sand.nodes.new("ShaderNodeValToRGB")
        colorramp_001.name = "ColorRamp.001"
        colorramp_001.color_ramp.color_mode = 'RGB'
        colorramp_001.color_ramp.hue_interpolation = 'NEAR'
        colorramp_001.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        colorramp_001.color_ramp.elements.remove(colorramp_001.color_ramp.elements[0])
        colorramp_001_cre_0 = colorramp_001.color_ramp.elements[0]
        colorramp_001_cre_0.position = 0.004545454401522875
        colorramp_001_cre_0.alpha = 1.0
        colorramp_001_cre_0.color = (0.80841064453125, 0.80841064453125, 0.80841064453125, 1.0)

        colorramp_001_cre_1 = colorramp_001.color_ramp.elements.new(0.10909087210893631)
        colorramp_001_cre_1.alpha = 1.0
        colorramp_001_cre_1.color = (0.9819239974021912, 0.9819239974021912, 0.9819239974021912, 1.0)


        #node Mix
        mix = sand.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.blend_type = 'MULTIPLY'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'RGBA'
        mix.factor_mode = 'UNIFORM'
        #Factor_Float
        mix.inputs[0].default_value = 0.699999988079071

        #node vector scale
        vector_scale_1 = sand.nodes.new("ShaderNodeGroup")
        vector_scale_1.label = "vector scale"
        vector_scale_1.name = "vector scale"
        vector_scale_1.node_tree = vector_scale


        #Set locations
        material_output.location = (1129.65625, 300.0)
        principled_bsdf.location = (879.8305053710938, 316.5048522949219)
        voronoi_texture.location = (-469.384521484375, 273.7554016113281)
        math_001.location = (-239.2373046875, 174.5637969970703)
        colorramp.location = (104.99797058105469, 322.8050842285156)
        geometry.location = (-1480.3953857421875, -27.915843963623047)
        scale.location = (-1556.258056640625, 120.3376693725586)
        image_texture.location = (-189.76734924316406, -19.60942840576172)
        mapping.location = (-554.59521484375, -73.34178161621094)
        math.location = (209.451171875, -55.01222229003906)
        reroute.location = (-1336.258056640625, 79.9183120727539)
        math_006.location = (429.451171875, -82.68285369873047)
        math_007.location = (691.826171875, 41.523406982421875)
        bump.location = (655.2909545898438, -142.30120849609375)
        colorramp_001.location = (-216.38284301757812, 379.82171630859375)
        mix.location = (535.2099609375, 351.598876953125)
        vector_scale_1.location = (-990.2304077148438, 128.4503173828125)

        #Set dimensions
        material_output.width, material_output.height = 140.0, 100.0
        principled_bsdf.width, principled_bsdf.height = 150.0, 100.0
        voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
        math_001.width, math_001.height = 140.0, 100.0
        colorramp.width, colorramp.height = 240.0, 100.0
        geometry.width, geometry.height = 140.0, 100.0
        scale.width, scale.height = 140.0, 100.0
        image_texture.width, image_texture.height = 140.0, 100.0
        mapping.width, mapping.height = 140.0, 100.0
        math.width, math.height = 140.0, 100.0
        reroute.width, reroute.height = 16.0, 100.0
        math_006.width, math_006.height = 140.0, 100.0
        math_007.width, math_007.height = 140.0, 100.0
        bump.width, bump.height = 140.0, 100.0
        colorramp_001.width, colorramp_001.height = 240.0, 100.0
        mix.width, mix.height = 140.0, 100.0
        vector_scale_1.width, vector_scale_1.height = 140.0, 100.0

        #initialize sand links
        #principled_bsdf.BSDF -> material_output.Surface
        sand.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
        #image_texture.Color -> math.Value
        sand.links.new(image_texture.outputs[0], math.inputs[0])
        #image_texture.Color -> colorramp.Fac
        sand.links.new(image_texture.outputs[0], colorramp.inputs[0])
        #colorramp.Color -> mix.A
        sand.links.new(colorramp.outputs[0], mix.inputs[6])
        #colorramp_001.Color -> principled_bsdf.Roughness
        sand.links.new(colorramp_001.outputs[0], principled_bsdf.inputs[2])
        #math.Value -> math_006.Value
        sand.links.new(math.outputs[0], math_006.inputs[0])
        #math_001.Value -> math.Value
        sand.links.new(math_001.outputs[0], math.inputs[1])
        #mapping.Vector -> image_texture.Vector
        sand.links.new(mapping.outputs[0], image_texture.inputs[0])
        #vector_scale_1.Vector -> voronoi_texture.Vector
        sand.links.new(vector_scale_1.outputs[0], voronoi_texture.inputs[0])
        #geometry.Position -> vector_scale_1.Vector
        sand.links.new(geometry.outputs[0], vector_scale_1.inputs[0])
        #vector_scale_1.Vector -> mapping.Vector
        sand.links.new(vector_scale_1.outputs[0], mapping.inputs[0])
        #scale.Value -> reroute.Input
        sand.links.new(scale.outputs[0], reroute.inputs[0])
        #reroute.Output -> vector_scale_1.Value
        sand.links.new(reroute.outputs[0], vector_scale_1.inputs[1])
        #math_006.Value -> bump.Height
        sand.links.new(math_006.outputs[0], bump.inputs[2])
        #reroute.Output -> math_006.Value
        sand.links.new(reroute.outputs[0], math_006.inputs[1])
        #math_006.Value -> math_007.Value
        sand.links.new(math_006.outputs[0], math_007.inputs[0])
        #mix.Result -> principled_bsdf.Base Color
        sand.links.new(mix.outputs[2], principled_bsdf.inputs[0])
        #bump.Normal -> principled_bsdf.Normal
        sand.links.new(bump.outputs[0], principled_bsdf.inputs[5])
        #voronoi_texture.Color -> mix.B
        sand.links.new(voronoi_texture.outputs[1], mix.inputs[7])
        #voronoi_texture.Color -> math_001.Value
        sand.links.new(voronoi_texture.outputs[1], math_001.inputs[0])
        #voronoi_texture.Color -> colorramp_001.Fac
        sand.links.new(voronoi_texture.outputs[1], colorramp_001.inputs[0])
        return sand

    sand = sand_node_group()
    return mat


def create_sandstone_material():
    if "Sandstone" in bpy.data.materials:
        return bpy.data.materials["Sandstone"]


    mat = bpy.data.materials.new(name = "Sandstone")
    mat.use_nodes = True
    #initialize Sandstone node group
    def sandstone_node_group():

        sandstone = mat.node_tree
        #start with a clean node tree
        for node in sandstone.nodes:
            sandstone.nodes.remove(node)
        sandstone.color_tag = 'NONE'
        sandstone.description = ""
        sandstone.default_group_node_width = 140
        

        #sandstone interface

        #initialize sandstone nodes
        #node Principled BSDF
        principled_bsdf = sandstone.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'MULTI_GGX'
        principled_bsdf.subsurface_method = 'RANDOM_WALK'
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #Roughness
        principled_bsdf.inputs[2].default_value = 0.699999988079071
        #IOR
        principled_bsdf.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Specular Tint
        principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Material Output
        material_output = sandstone.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        #Displacement
        material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Noise Texture
        noise_texture = sandstone.nodes.new("ShaderNodeTexNoise")
        noise_texture.name = "Noise Texture"
        noise_texture.noise_dimensions = '3D'
        noise_texture.noise_type = 'FBM'
        noise_texture.normalize = False
        #Scale
        noise_texture.inputs[2].default_value = 5.0
        #Detail
        noise_texture.inputs[3].default_value = 15.0
        #Roughness
        noise_texture.inputs[4].default_value = 0.0
        #Lacunarity
        noise_texture.inputs[5].default_value = 2.0
        #Distortion
        noise_texture.inputs[8].default_value = 0.0

        #node Texture Coordinate
        texture_coordinate = sandstone.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.from_instancer = False

        #node Noise Texture.001
        noise_texture_001 = sandstone.nodes.new("ShaderNodeTexNoise")
        noise_texture_001.name = "Noise Texture.001"
        noise_texture_001.noise_dimensions = '3D'
        noise_texture_001.noise_type = 'FBM'
        noise_texture_001.normalize = True
        #Scale
        noise_texture_001.inputs[2].default_value = 6.0
        #Detail
        noise_texture_001.inputs[3].default_value = 15.0
        #Roughness
        noise_texture_001.inputs[4].default_value = 1.0
        #Lacunarity
        noise_texture_001.inputs[5].default_value = 2.0
        #Distortion
        noise_texture_001.inputs[8].default_value = 0.0

        #node Color Ramp
        color_ramp = sandstone.nodes.new("ShaderNodeValToRGB")
        color_ramp.name = "Color Ramp"
        color_ramp.color_ramp.color_mode = 'RGB'
        color_ramp.color_ramp.hue_interpolation = 'NEAR'
        color_ramp.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
        color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
        color_ramp_cre_0.position = 0.0
        color_ramp_cre_0.alpha = 1.0
        color_ramp_cre_0.color = (0.18781979382038116, 0.056128546595573425, 0.016807394102215767, 1.0)

        color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.290909081697464)
        color_ramp_cre_1.alpha = 1.0
        color_ramp_cre_1.color = (0.3139871060848236, 0.08228276669979095, 0.019382385537028313, 1.0)

        color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.7022727131843567)
        color_ramp_cre_2.alpha = 1.0
        color_ramp_cre_2.color = (0.8713624477386475, 0.2961385250091553, 0.13563348352909088, 1.0)

        color_ramp_cre_3 = color_ramp.color_ramp.elements.new(1.0)
        color_ramp_cre_3.alpha = 1.0
        color_ramp_cre_3.color = (1.0, 0.33716389536857605, 0.05780553072690964, 1.0)


        #node Voronoi Texture
        voronoi_texture = sandstone.nodes.new("ShaderNodeTexVoronoi")
        voronoi_texture.name = "Voronoi Texture"
        voronoi_texture.distance = 'EUCLIDEAN'
        voronoi_texture.feature = 'F1'
        voronoi_texture.normalize = False
        voronoi_texture.voronoi_dimensions = '3D'
        #Scale
        voronoi_texture.inputs[2].default_value = 300.0
        #Detail
        voronoi_texture.inputs[3].default_value = 0.0
        #Roughness
        voronoi_texture.inputs[4].default_value = 0.5
        #Lacunarity
        voronoi_texture.inputs[5].default_value = 2.0
        #Randomness
        voronoi_texture.inputs[8].default_value = 1.0

        #node Bump
        bump = sandstone.nodes.new("ShaderNodeBump")
        bump.name = "Bump"
        bump.invert = True
        #Strength
        bump.inputs[0].default_value = 0.30000001192092896
        #Distance
        bump.inputs[1].default_value = 1.0
        #Normal
        bump.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Noise Texture.002
        noise_texture_002 = sandstone.nodes.new("ShaderNodeTexNoise")
        noise_texture_002.name = "Noise Texture.002"
        noise_texture_002.noise_dimensions = '3D'
        noise_texture_002.noise_type = 'FBM'
        noise_texture_002.normalize = True
        #Scale
        noise_texture_002.inputs[2].default_value = 15.0
        #Detail
        noise_texture_002.inputs[3].default_value = 15.0
        #Roughness
        noise_texture_002.inputs[4].default_value = 0.6000000238418579
        #Lacunarity
        noise_texture_002.inputs[5].default_value = 2.0
        #Distortion
        noise_texture_002.inputs[8].default_value = 0.0

        #node Bump.001
        bump_001 = sandstone.nodes.new("ShaderNodeBump")
        bump_001.name = "Bump.001"
        bump_001.invert = False
        #Strength
        bump_001.inputs[0].default_value = 0.30000001192092896
        #Distance
        bump_001.inputs[1].default_value = 1.0

        #node Noise Texture.003
        noise_texture_003 = sandstone.nodes.new("ShaderNodeTexNoise")
        noise_texture_003.name = "Noise Texture.003"
        noise_texture_003.noise_dimensions = '3D'
        noise_texture_003.noise_type = 'FBM'
        noise_texture_003.normalize = True
        #Scale
        noise_texture_003.inputs[2].default_value = 8.0
        #Detail
        noise_texture_003.inputs[3].default_value = 0.0
        #Roughness
        noise_texture_003.inputs[4].default_value = 0.5
        #Lacunarity
        noise_texture_003.inputs[5].default_value = 2.0
        #Distortion
        noise_texture_003.inputs[8].default_value = 0.0

        #node Bump.002
        bump_002 = sandstone.nodes.new("ShaderNodeBump")
        bump_002.name = "Bump.002"
        bump_002.invert = False
        #Strength
        bump_002.inputs[0].default_value = 0.15000000596046448
        #Distance
        bump_002.inputs[1].default_value = 1.0


        #Set locations
        principled_bsdf.location = (358.39324951171875, 305.4974060058594)
        material_output.location = (646.8190307617188, 301.3743591308594)
        noise_texture.location = (-255.7804718017578, 287.6824035644531)
        texture_coordinate.location = (-616.038330078125, 236.24131774902344)
        noise_texture_001.location = (-435.99993896484375, 274.3490295410156)
        color_ramp.location = (-76.0, 297.9884948730469)
        voronoi_texture.location = (-430.293701171875, -44.024906158447266)
        bump.location = (-187.2978515625, -14.425987243652344)
        noise_texture_002.location = (-424.93145751953125, -402.5257568359375)
        bump_001.location = (-1.36419677734375, 73.40762329101562)
        noise_texture_003.location = (-410.08038330078125, -714.9237060546875)
        bump_002.location = (178.49996948242188, 86.40713500976562)

        #Set dimensions
        principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
        material_output.width, material_output.height = 140.0, 100.0
        noise_texture.width, noise_texture.height = 140.0, 100.0
        texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
        noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
        color_ramp.width, color_ramp.height = 240.0, 100.0
        voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
        bump.width, bump.height = 140.0, 100.0
        noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
        bump_001.width, bump_001.height = 140.0, 100.0
        noise_texture_003.width, noise_texture_003.height = 140.0, 100.0
        bump_002.width, bump_002.height = 140.0, 100.0

        #initialize sandstone links
        #noise_texture_001.Color -> noise_texture.Vector
        sandstone.links.new(noise_texture_001.outputs[1], noise_texture.inputs[0])
        #texture_coordinate.Object -> noise_texture_001.Vector
        sandstone.links.new(texture_coordinate.outputs[3], noise_texture_001.inputs[0])
        #color_ramp.Color -> principled_bsdf.Base Color
        sandstone.links.new(color_ramp.outputs[0], principled_bsdf.inputs[0])
        #noise_texture.Fac -> color_ramp.Fac
        sandstone.links.new(noise_texture.outputs[0], color_ramp.inputs[0])
        #texture_coordinate.Object -> voronoi_texture.Vector
        sandstone.links.new(texture_coordinate.outputs[3], voronoi_texture.inputs[0])
        #bump_002.Normal -> principled_bsdf.Normal
        sandstone.links.new(bump_002.outputs[0], principled_bsdf.inputs[5])
        #principled_bsdf.BSDF -> material_output.Surface
        sandstone.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
        #voronoi_texture.Distance -> bump.Height
        sandstone.links.new(voronoi_texture.outputs[0], bump.inputs[2])
        #texture_coordinate.Object -> noise_texture_002.Vector
        sandstone.links.new(texture_coordinate.outputs[3], noise_texture_002.inputs[0])
        #bump.Normal -> bump_001.Normal
        sandstone.links.new(bump.outputs[0], bump_001.inputs[3])
        #noise_texture_002.Fac -> bump_001.Height
        sandstone.links.new(noise_texture_002.outputs[0], bump_001.inputs[2])
        #texture_coordinate.Object -> noise_texture_003.Vector
        sandstone.links.new(texture_coordinate.outputs[3], noise_texture_003.inputs[0])
        #bump_001.Normal -> bump_002.Normal
        sandstone.links.new(bump_001.outputs[0], bump_002.inputs[3])
        #noise_texture_003.Fac -> bump_002.Height
        sandstone.links.new(noise_texture_003.outputs[0], bump_002.inputs[2])
        return sandstone

    sandstone_node_group()
    return mat


def create_snow_material():
    if "Snow Material" in bpy.data.materials:
        return bpy.data.materials["Snow Material"]


    mat = bpy.data.materials.new(name = "Snow Material")
    mat.use_nodes = True
    #initialize NodeGroup.Snow node group
    def nodegroup_snow_node_group():

        nodegroup_snow = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "NodeGroup.Snow")

        nodegroup_snow.color_tag = 'NONE'
        nodegroup_snow.description = ""
        nodegroup_snow.default_group_node_width = 140
        

        #nodegroup_snow interface
        #Socket Displacement
        displacement_socket = nodegroup_snow.interface.new_socket(name = "Displacement", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        displacement_socket.default_value = (0.0, 0.0, 0.0)
        displacement_socket.min_value = -3.4028234663852886e+38
        displacement_socket.max_value = 3.4028234663852886e+38
        displacement_socket.subtype = 'NONE'
        displacement_socket.attribute_domain = 'POINT'

        #Socket Shader
        shader_socket = nodegroup_snow.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
        shader_socket.attribute_domain = 'POINT'

        #Socket Rock Strength
        rock_strength_socket = nodegroup_snow.interface.new_socket(name = "Rock Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rock_strength_socket.default_value = 0.09000000357627869
        rock_strength_socket.min_value = 0.0
        rock_strength_socket.max_value = 0.30000001192092896
        rock_strength_socket.subtype = 'NONE'
        rock_strength_socket.attribute_domain = 'POINT'

        #Socket Rock Scale
        rock_scale_socket = nodegroup_snow.interface.new_socket(name = "Rock Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rock_scale_socket.default_value = 1.0
        rock_scale_socket.min_value = 1.0
        rock_scale_socket.max_value = 3.4028234663852886e+38
        rock_scale_socket.subtype = 'NONE'
        rock_scale_socket.attribute_domain = 'POINT'

        #Socket Grass Scale
        grass_scale_socket = nodegroup_snow.interface.new_socket(name = "Grass Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_scale_socket.default_value = 10.0
        grass_scale_socket.min_value = 10.0
        grass_scale_socket.max_value = 10.0
        grass_scale_socket.subtype = 'NONE'
        grass_scale_socket.attribute_domain = 'POINT'

        #Socket Rock Color
        rock_color_socket = nodegroup_snow.interface.new_socket(name = "Rock Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        rock_color_socket.default_value = (1.0, 0.48254817724227905, 0.328963965177536, 1.0)
        rock_color_socket.attribute_domain = 'POINT'

        #Socket Grass Color
        grass_color_socket = nodegroup_snow.interface.new_socket(name = "Grass Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        grass_color_socket.default_value = (0.8460381031036377, 0.9430891275405884, 0.20860043168067932, 1.0)
        grass_color_socket.attribute_domain = 'POINT'

        #Socket Grass Covered
        grass_covered_socket = nodegroup_snow.interface.new_socket(name = "Grass Covered", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_covered_socket.default_value = 0.0
        grass_covered_socket.min_value = 0.0
        grass_covered_socket.max_value = 0.30000001192092896
        grass_covered_socket.subtype = 'NONE'
        grass_covered_socket.attribute_domain = 'POINT'

        #Socket Grass Strength
        grass_strength_socket = nodegroup_snow.interface.new_socket(name = "Grass Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_strength_socket.default_value = 3.0
        grass_strength_socket.min_value = 0.0
        grass_strength_socket.max_value = 10.0
        grass_strength_socket.subtype = 'NONE'
        grass_strength_socket.attribute_domain = 'POINT'


        #initialize nodegroup_snow nodes
        #node Group Output
        group_output = nodegroup_snow.nodes.new("NodeGroupOutput")
        group_output.name = "Group Output"
        group_output.is_active_output = True

        #node Group Input
        group_input = nodegroup_snow.nodes.new("NodeGroupInput")
        group_input.name = "Group Input"

        #node Principled BSDF
        principled_bsdf = nodegroup_snow.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'MULTI_GGX'
        principled_bsdf.subsurface_method = 'RANDOM_WALK'
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Normal
        principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Specular Tint
        principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Image Texture
        image_texture = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture.label = "Displacement"
        image_texture.name = "Image Texture"
        image_texture.extension = 'REPEAT'
        if "rock_face_03_disp_4k.png" in bpy.data.images:
            image_texture.image = bpy.data.images["rock_face_03_disp_4k.png"]
        image_texture.image_user.frame_current = 1
        image_texture.image_user.frame_duration = 1
        image_texture.image_user.frame_offset = 3
        image_texture.image_user.frame_start = 1
        image_texture.image_user.tile = 0
        image_texture.image_user.use_auto_refresh = False
        image_texture.image_user.use_cyclic = False
        image_texture.interpolation = 'Linear'
        image_texture.projection = 'FLAT'
        image_texture.projection_blend = 0.0

        #node Displacement
        displacement = nodegroup_snow.nodes.new("ShaderNodeDisplacement")
        displacement.name = "Displacement"
        displacement.space = 'OBJECT'
        #Midlevel
        displacement.inputs[1].default_value = 0.0
        #Normal
        displacement.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Image Texture.001
        image_texture_001 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_001.label = "Base Color"
        image_texture_001.name = "Image Texture.001"
        image_texture_001.extension = 'REPEAT'
        if "rock_face_03_diff.png" in bpy.data.images:
            image_texture_001.image = bpy.data.images["rock_face_03_diff.png"]
        image_texture_001.image_user.frame_current = 1
        image_texture_001.image_user.frame_duration = 1
        image_texture_001.image_user.frame_offset = 2
        image_texture_001.image_user.frame_start = 1
        image_texture_001.image_user.tile = 0
        image_texture_001.image_user.use_auto_refresh = False
        image_texture_001.image_user.use_cyclic = False
        image_texture_001.interpolation = 'Linear'
        image_texture_001.projection = 'FLAT'
        image_texture_001.projection_blend = 0.0

        #node Image Texture.002
        image_texture_002 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_002.label = "Roughness"
        image_texture_002.name = "Image Texture.002"
        image_texture_002.extension = 'REPEAT'
        if "rock_face_03_rough.png" in bpy.data.images:
            image_texture_002.image = bpy.data.images["rock_face_03_rough.png"]
        image_texture_002.image_user.frame_current = 1
        image_texture_002.image_user.frame_duration = 1
        image_texture_002.image_user.frame_offset = 2
        image_texture_002.image_user.frame_start = 1
        image_texture_002.image_user.tile = 0
        image_texture_002.image_user.use_auto_refresh = False
        image_texture_002.image_user.use_cyclic = False
        image_texture_002.interpolation = 'Linear'
        image_texture_002.projection = 'FLAT'
        image_texture_002.projection_blend = 0.0

        #node Image Texture.003
        image_texture_003 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_003.label = "Normal"
        image_texture_003.name = "Image Texture.003"
        image_texture_003.extension = 'REPEAT'
        image_texture_003.image_user.frame_current = 1
        image_texture_003.image_user.frame_duration = 1
        image_texture_003.image_user.frame_offset = 2
        image_texture_003.image_user.frame_start = 1
        image_texture_003.image_user.tile = 0
        image_texture_003.image_user.use_auto_refresh = False
        image_texture_003.image_user.use_cyclic = False
        image_texture_003.interpolation = 'Linear'
        image_texture_003.projection = 'FLAT'
        image_texture_003.projection_blend = 0.0

        #node Normal Map
        normal_map = nodegroup_snow.nodes.new("ShaderNodeNormalMap")
        normal_map.name = "Normal Map"
        normal_map.space = 'TANGENT'
        normal_map.uv_map = ""
        #Strength
        normal_map.inputs[0].default_value = 1.0

        #node Mapping
        mapping = nodegroup_snow.nodes.new("ShaderNodeMapping")
        mapping.name = "Mapping"
        mapping.vector_type = 'POINT'
        #Location
        mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute
        reroute = nodegroup_snow.nodes.new("NodeReroute")
        reroute.name = "Reroute"
        reroute.socket_idname = "NodeSocketVector"
        #node Texture Coordinate
        texture_coordinate = nodegroup_snow.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.from_instancer = False

        #node Frame
        frame = nodegroup_snow.nodes.new("NodeFrame")
        frame.label = "Mapping"
        frame.name = "Frame"
        frame.label_size = 20
        frame.shrink = True

        #node Frame.001
        frame_001 = nodegroup_snow.nodes.new("NodeFrame")
        frame_001.label = "Textures"
        frame_001.name = "Frame.001"
        frame_001.label_size = 20
        frame_001.shrink = True

        #node Principled BSDF.001
        principled_bsdf_001 = nodegroup_snow.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf_001.name = "Principled BSDF.001"
        principled_bsdf_001.distribution = 'MULTI_GGX'
        principled_bsdf_001.subsurface_method = 'RANDOM_WALK'
        #Metallic
        principled_bsdf_001.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf_001.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf_001.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf_001.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf_001.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf_001.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf_001.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf_001.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf_001.inputs[13].default_value = 0.0
        #Specular Tint
        principled_bsdf_001.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf_001.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf_001.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf_001.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf_001.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf_001.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf_001.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf_001.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf_001.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf_001.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf_001.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf_001.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf_001.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf_001.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf_001.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf_001.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf_001.inputs[30].default_value = 1.3300000429153442

        #node Mix Shader
        mix_shader = nodegroup_snow.nodes.new("ShaderNodeMixShader")
        mix_shader.name = "Mix Shader"

        #node Image Texture.004
        image_texture_004 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_004.label = "Base Color"
        image_texture_004.name = "Image Texture.004"
        image_texture_004.extension = 'REPEAT'
        if "grass 03_Albedo.jpg" in bpy.data.images:
            image_texture_004.image = bpy.data.images["grass 03_Albedo.jpg"]
        image_texture_004.image_user.frame_current = 1
        image_texture_004.image_user.frame_duration = 1
        image_texture_004.image_user.frame_offset = 2
        image_texture_004.image_user.frame_start = 1
        image_texture_004.image_user.tile = 0
        image_texture_004.image_user.use_auto_refresh = False
        image_texture_004.image_user.use_cyclic = False
        image_texture_004.interpolation = 'Linear'
        image_texture_004.projection = 'FLAT'
        image_texture_004.projection_blend = 0.0

        #node Image Texture.005
        image_texture_005 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_005.label = "Roughness"
        image_texture_005.name = "Image Texture.005"
        image_texture_005.extension = 'REPEAT'
        if "grass 03_Roughness.jpg" in bpy.data.images:
            image_texture_005.image = bpy.data.images["grass 03_Roughness.jpg"]
        image_texture_005.image_user.frame_current = 1
        image_texture_005.image_user.frame_duration = 1
        image_texture_005.image_user.frame_offset = 2
        image_texture_005.image_user.frame_start = 1
        image_texture_005.image_user.tile = 0
        image_texture_005.image_user.use_auto_refresh = False
        image_texture_005.image_user.use_cyclic = False
        image_texture_005.interpolation = 'Linear'
        image_texture_005.projection = 'FLAT'
        image_texture_005.projection_blend = 0.0

        #node Image Texture.006
        image_texture_006 = nodegroup_snow.nodes.new("ShaderNodeTexImage")
        image_texture_006.label = "Normal"
        image_texture_006.name = "Image Texture.006"
        image_texture_006.extension = 'REPEAT'
        if "grass 03_Normal.jpg" in bpy.data.images:
            image_texture_006.image = bpy.data.images["grass 03_Normal.jpg"]
        image_texture_006.image_user.frame_current = 1
        image_texture_006.image_user.frame_duration = 1
        image_texture_006.image_user.frame_offset = 2
        image_texture_006.image_user.frame_start = 1
        image_texture_006.image_user.tile = 0
        image_texture_006.image_user.use_auto_refresh = False
        image_texture_006.image_user.use_cyclic = False
        image_texture_006.interpolation = 'Linear'
        image_texture_006.projection = 'FLAT'
        image_texture_006.projection_blend = 0.0

        #node Normal Map.001
        normal_map_001 = nodegroup_snow.nodes.new("ShaderNodeNormalMap")
        normal_map_001.name = "Normal Map.001"
        normal_map_001.space = 'TANGENT'
        normal_map_001.uv_map = ""

        #node Mapping.001
        mapping_001 = nodegroup_snow.nodes.new("ShaderNodeMapping")
        mapping_001.name = "Mapping.001"
        mapping_001.vector_type = 'POINT'
        #Location
        mapping_001.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping_001.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute.001
        reroute_001 = nodegroup_snow.nodes.new("NodeReroute")
        reroute_001.name = "Reroute.001"
        reroute_001.socket_idname = "NodeSocketVector"
        #node Texture Coordinate.001
        texture_coordinate_001 = nodegroup_snow.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_001.name = "Texture Coordinate.001"
        texture_coordinate_001.from_instancer = False

        #node Frame.002
        frame_002 = nodegroup_snow.nodes.new("NodeFrame")
        frame_002.label = "Mapping"
        frame_002.name = "Frame.002"
        frame_002.label_size = 20
        frame_002.shrink = True

        #node Frame.003
        frame_003 = nodegroup_snow.nodes.new("NodeFrame")
        frame_003.label = "Textures"
        frame_003.name = "Frame.003"
        frame_003.label_size = 20
        frame_003.shrink = True

        #node Geometry
        geometry = nodegroup_snow.nodes.new("ShaderNodeNewGeometry")
        geometry.name = "Geometry"

        #node Separate XYZ
        separate_xyz = nodegroup_snow.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"

        #node Color Ramp
        color_ramp = nodegroup_snow.nodes.new("ShaderNodeValToRGB")
        color_ramp.name = "Color Ramp"
        color_ramp.color_ramp.color_mode = 'RGB'
        color_ramp.color_ramp.hue_interpolation = 'NEAR'
        color_ramp.color_ramp.interpolation = 'EASE'

        #initialize color ramp elements
        color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
        color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
        color_ramp_cre_0.position = 0.0
        color_ramp_cre_0.alpha = 1.0
        color_ramp_cre_0.color = (0.49229443073272705, 0.49229443073272705, 0.49229443073272705, 1.0)

        color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
        color_ramp_cre_1.alpha = 1.0
        color_ramp_cre_1.color = (0.9645918607711792, 0.9645918607711792, 0.9645918607711792, 1.0)


        #node Mix
        mix = nodegroup_snow.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.blend_type = 'MIX'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'RGBA'
        mix.factor_mode = 'UNIFORM'
        #B_Color
        mix.inputs[7].default_value = (0.6028310060501099, 0.6028310060501099, 0.6028310060501099, 1.0)

        #node Group Input.001
        group_input_001 = nodegroup_snow.nodes.new("NodeGroupInput")
        group_input_001.name = "Group Input.001"

        #node Color Ramp.002
        color_ramp_002 = nodegroup_snow.nodes.new("ShaderNodeValToRGB")
        color_ramp_002.name = "Color Ramp.002"
        color_ramp_002.color_ramp.color_mode = 'RGB'
        color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_002.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
        color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
        color_ramp_002_cre_0.position = 0.0
        color_ramp_002_cre_0.alpha = 1.0
        color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(1.0)
        color_ramp_002_cre_1.alpha = 1.0
        color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)


        #node Mix.001
        mix_001 = nodegroup_snow.nodes.new("ShaderNodeMix")
        mix_001.name = "Mix.001"
        mix_001.blend_type = 'MIX'
        mix_001.clamp_factor = True
        mix_001.clamp_result = False
        mix_001.data_type = 'RGBA'
        mix_001.factor_mode = 'UNIFORM'
        #A_Color
        mix_001.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)

        #node Color Ramp.001
        color_ramp_001 = nodegroup_snow.nodes.new("ShaderNodeValToRGB")
        color_ramp_001.name = "Color Ramp.001"
        color_ramp_001.color_ramp.color_mode = 'RGB'
        color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_001.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
        color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
        color_ramp_001_cre_0.position = 0.0
        color_ramp_001_cre_0.alpha = 1.0
        color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(1.0)
        color_ramp_001_cre_1.alpha = 1.0
        color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)


        #node Mix.002
        mix_002 = nodegroup_snow.nodes.new("ShaderNodeMix")
        mix_002.name = "Mix.002"
        mix_002.blend_type = 'MIX'
        mix_002.clamp_factor = True
        mix_002.clamp_result = False
        mix_002.data_type = 'RGBA'
        mix_002.factor_mode = 'UNIFORM'
        #A_Color
        mix_002.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)

        #node Math
        math = nodegroup_snow.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.operation = 'ADD'
        math.use_clamp = False

        #node Mix.003
        mix_003 = nodegroup_snow.nodes.new("ShaderNodeMix")
        mix_003.name = "Mix.003"
        mix_003.blend_type = 'MIX'
        mix_003.clamp_factor = True
        mix_003.clamp_result = False
        mix_003.data_type = 'RGBA'
        mix_003.factor_mode = 'UNIFORM'
        #Factor_Float
        mix_003.inputs[0].default_value = 0.5083333253860474
        #B_Color
        mix_003.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)

        #node Noise Texture
        noise_texture = nodegroup_snow.nodes.new("ShaderNodeTexNoise")
        noise_texture.name = "Noise Texture"
        noise_texture.noise_dimensions = '3D'
        noise_texture.noise_type = 'FBM'
        noise_texture.normalize = True
        #Scale
        noise_texture.inputs[2].default_value = 45.0
        #Detail
        noise_texture.inputs[3].default_value = 4.199999809265137
        #Roughness
        noise_texture.inputs[4].default_value = 0.5
        #Lacunarity
        noise_texture.inputs[5].default_value = 2.0
        #Distortion
        noise_texture.inputs[8].default_value = 0.0

        #node Mapping.002
        mapping_002 = nodegroup_snow.nodes.new("ShaderNodeMapping")
        mapping_002.name = "Mapping.002"
        mapping_002.vector_type = 'POINT'
        #Location
        mapping_002.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping_002.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Scale
        mapping_002.inputs[3].default_value = (1.0, 1.0, 1.0)

        #node Texture Coordinate.002
        texture_coordinate_002 = nodegroup_snow.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_002.name = "Texture Coordinate.002"
        texture_coordinate_002.from_instancer = False

        #Set parents
        image_texture.parent = frame_001
        image_texture_001.parent = frame_001
        image_texture_002.parent = frame_001
        image_texture_003.parent = frame_001
        mapping.parent = frame
        reroute.parent = frame_001
        texture_coordinate.parent = frame
        image_texture_004.parent = frame_003
        image_texture_005.parent = frame_003
        image_texture_006.parent = frame_003
        mapping_001.parent = frame_002
        reroute_001.parent = frame_003
        texture_coordinate_001.parent = frame_002
        group_input_001.parent = frame

        #Set locations
        group_output.location = (1862.6331787109375, 0.0)
        group_input.location = (-73.310302734375, -1062.5828857421875)
        principled_bsdf.location = (123.935302734375, 516.8970947265625)
        image_texture.location = (-540.9822998046875, -12.877304077148438)
        displacement.location = (1378.4278564453125, 95.91932678222656)
        image_texture_001.location = (-580.1441040039062, 645.1151123046875)
        image_texture_002.location = (-569.3236694335938, 319.1101989746094)
        image_texture_003.location = (-540.0, -340.0)
        normal_map.location = (-229.93890380859375, -43.9849853515625)
        mapping.location = (-1040.0, 300.0)
        reroute.location = (-590.0, -56.0)
        texture_coordinate.location = (-1240.0, 300.0)
        frame.location = (11.40283203125, 216.89712524414062)
        frame_001.location = (11.40283203125, 216.89712524414062)
        principled_bsdf_001.location = (1212.1942138671875, -437.73736572265625)
        mix_shader.location = (1406.980224609375, 592.17529296875)
        image_texture_004.location = (323.49432373046875, -455.69580078125)
        image_texture_005.location = (323.49432373046875, -735.69580078125)
        image_texture_006.location = (323.49432373046875, -1015.69580078125)
        normal_map_001.location = (837.7806396484375, -743.755126953125)
        mapping_001.location = (-174.93695068359375, -679.2033081054688)
        reroute_001.location = (273.49432373046875, -671.7718505859375)
        texture_coordinate_001.location = (-376.50567626953125, -655.69580078125)
        frame_002.location = (45.29180908203125, 179.69601440429688)
        frame_003.location = (46.29180908203125, 179.696044921875)
        geometry.location = (241.89498901367188, 957.1224975585938)
        separate_xyz.location = (412.03533935546875, 893.85546875)
        color_ramp.location = (629.1055908203125, 920.2234497070312)
        mix.location = (1054.762939453125, 457.1654052734375)
        group_input_001.location = (-1040.681884765625, -111.18919372558594)
        color_ramp_002.location = (-232.00286865234375, 1127.3812255859375)
        mix_001.location = (44.89693069458008, 1043.0)
        color_ramp_001.location = (629.3560180664062, -36.09300994873047)
        mix_002.location = (942.7572021484375, -131.34803771972656)
        math.location = (1101.5970458984375, 727.1475830078125)
        mix_003.location = (983.9714965820312, 1045.10009765625)
        noise_texture.location = (668.6510009765625, 1221.7752685546875)
        mapping_002.location = (456.531494140625, 1294.8138427734375)
        texture_coordinate_002.location = (276.531494140625, 1294.8138427734375)

        #Set dimensions
        group_output.width, group_output.height = 140.0, 100.0
        group_input.width, group_input.height = 140.0, 100.0
        principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
        image_texture.width, image_texture.height = 240.0, 100.0
        displacement.width, displacement.height = 140.0, 100.0
        image_texture_001.width, image_texture_001.height = 252.6068115234375, 100.0
        image_texture_002.width, image_texture_002.height = 240.0, 100.0
        image_texture_003.width, image_texture_003.height = 240.0, 100.0
        normal_map.width, normal_map.height = 150.0, 100.0
        mapping.width, mapping.height = 140.0, 100.0
        reroute.width, reroute.height = 16.0, 100.0
        texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
        frame.width, frame.height = 400.0, 685.0
        frame_001.width, frame_001.height = 357.59716796875, 1251.0
        principled_bsdf_001.width, principled_bsdf_001.height = 240.0, 100.0
        mix_shader.width, mix_shader.height = 140.0, 100.0
        image_texture_004.width, image_texture_004.height = 240.0, 100.0
        image_texture_005.width, image_texture_005.height = 240.0, 100.0
        image_texture_006.width, image_texture_006.height = 240.0, 100.0
        normal_map_001.width, normal_map_001.height = 150.0, 100.0
        mapping_001.width, mapping_001.height = 140.0, 100.0
        reroute_001.width, reroute_001.height = 16.0, 100.0
        texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
        frame_002.width, frame_002.height = 401.0, 383.0
        frame_003.width, frame_003.height = 358.2138671875, 901.0
        geometry.width, geometry.height = 140.0, 100.0
        separate_xyz.width, separate_xyz.height = 140.0, 100.0
        color_ramp.width, color_ramp.height = 240.0, 100.0
        mix.width, mix.height = 140.0, 100.0
        group_input_001.width, group_input_001.height = 140.0, 100.0
        color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
        mix_001.width, mix_001.height = 140.0, 100.0
        color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
        mix_002.width, mix_002.height = 140.0, 100.0
        math.width, math.height = 140.0, 100.0
        mix_003.width, mix_003.height = 140.0, 100.0
        noise_texture.width, noise_texture.height = 140.0, 100.0
        mapping_002.width, mapping_002.height = 140.0, 100.0
        texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0

        #initialize nodegroup_snow links
        #normal_map_001.Normal -> principled_bsdf_001.Normal
        nodegroup_snow.links.new(normal_map_001.outputs[0], principled_bsdf_001.inputs[5])
        #reroute_001.Output -> image_texture_006.Vector
        nodegroup_snow.links.new(reroute_001.outputs[0], image_texture_006.inputs[0])
        #image_texture_002.Color -> principled_bsdf.Roughness
        nodegroup_snow.links.new(image_texture_002.outputs[0], principled_bsdf.inputs[2])
        #texture_coordinate_001.Generated -> mapping_001.Vector
        nodegroup_snow.links.new(texture_coordinate_001.outputs[0], mapping_001.inputs[0])
        #reroute.Output -> image_texture_001.Vector
        nodegroup_snow.links.new(reroute.outputs[0], image_texture_001.inputs[0])
        #image_texture.Color -> mix.A
        nodegroup_snow.links.new(image_texture.outputs[0], mix.inputs[6])
        #reroute.Output -> image_texture_003.Vector
        nodegroup_snow.links.new(reroute.outputs[0], image_texture_003.inputs[0])
        #mapping.Vector -> reroute.Input
        nodegroup_snow.links.new(mapping.outputs[0], reroute.inputs[0])
        #color_ramp.Color -> mix.Factor
        nodegroup_snow.links.new(color_ramp.outputs[0], mix.inputs[0])
        #texture_coordinate.Generated -> mapping.Vector
        nodegroup_snow.links.new(texture_coordinate.outputs[0], mapping.inputs[0])
        #image_texture_005.Color -> principled_bsdf_001.Roughness
        nodegroup_snow.links.new(image_texture_005.outputs[0], principled_bsdf_001.inputs[2])
        #principled_bsdf_001.BSDF -> mix_shader.Shader
        nodegroup_snow.links.new(principled_bsdf_001.outputs[0], mix_shader.inputs[2])
        #mix.Result -> displacement.Height
        nodegroup_snow.links.new(mix.outputs[2], displacement.inputs[0])
        #geometry.Normal -> separate_xyz.Vector
        nodegroup_snow.links.new(geometry.outputs[1], separate_xyz.inputs[0])
        #image_texture_003.Color -> normal_map.Color
        nodegroup_snow.links.new(image_texture_003.outputs[0], normal_map.inputs[1])
        #reroute.Output -> image_texture_002.Vector
        nodegroup_snow.links.new(reroute.outputs[0], image_texture_002.inputs[0])
        #reroute.Output -> image_texture.Vector
        nodegroup_snow.links.new(reroute.outputs[0], image_texture.inputs[0])
        #mapping_001.Vector -> reroute_001.Input
        nodegroup_snow.links.new(mapping_001.outputs[0], reroute_001.inputs[0])
        #reroute_001.Output -> image_texture_005.Vector
        nodegroup_snow.links.new(reroute_001.outputs[0], image_texture_005.inputs[0])
        #reroute_001.Output -> image_texture_004.Vector
        nodegroup_snow.links.new(reroute_001.outputs[0], image_texture_004.inputs[0])
        #principled_bsdf.BSDF -> mix_shader.Shader
        nodegroup_snow.links.new(principled_bsdf.outputs[0], mix_shader.inputs[1])
        #displacement.Displacement -> group_output.Displacement
        nodegroup_snow.links.new(displacement.outputs[0], group_output.inputs[0])
        #mix_shader.Shader -> group_output.Shader
        nodegroup_snow.links.new(mix_shader.outputs[0], group_output.inputs[1])
        #group_input.Grass Scale -> mapping_001.Scale
        nodegroup_snow.links.new(group_input.outputs[2], mapping_001.inputs[3])
        #group_input_001.Rock Scale -> mapping.Scale
        nodegroup_snow.links.new(group_input_001.outputs[1], mapping.inputs[3])
        #image_texture_001.Color -> color_ramp_002.Fac
        nodegroup_snow.links.new(image_texture_001.outputs[0], color_ramp_002.inputs[0])
        #color_ramp_002.Color -> mix_001.Factor
        nodegroup_snow.links.new(color_ramp_002.outputs[0], mix_001.inputs[0])
        #mix_001.Result -> principled_bsdf.Base Color
        nodegroup_snow.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
        #group_input_001.Rock Color -> mix_001.B
        nodegroup_snow.links.new(group_input_001.outputs[3], mix_001.inputs[7])
        #image_texture_004.Color -> color_ramp_001.Fac
        nodegroup_snow.links.new(image_texture_004.outputs[0], color_ramp_001.inputs[0])
        #color_ramp_001.Color -> mix_002.Factor
        nodegroup_snow.links.new(color_ramp_001.outputs[0], mix_002.inputs[0])
        #mix_002.Result -> principled_bsdf_001.Base Color
        nodegroup_snow.links.new(mix_002.outputs[2], principled_bsdf_001.inputs[0])
        #group_input.Grass Color -> mix_002.B
        nodegroup_snow.links.new(group_input.outputs[4], mix_002.inputs[7])
        #group_input_001.Rock Strength -> displacement.Scale
        nodegroup_snow.links.new(group_input_001.outputs[0], displacement.inputs[2])
        #math.Value -> mix_shader.Fac
        nodegroup_snow.links.new(math.outputs[0], mix_shader.inputs[0])
        #group_input_001.Grass Covered -> math.Value
        nodegroup_snow.links.new(group_input_001.outputs[5], math.inputs[1])
        #separate_xyz.Z -> color_ramp.Fac
        nodegroup_snow.links.new(separate_xyz.outputs[2], color_ramp.inputs[0])
        #mapping_002.Vector -> noise_texture.Vector
        nodegroup_snow.links.new(mapping_002.outputs[0], noise_texture.inputs[0])
        #texture_coordinate_002.Generated -> mapping_002.Vector
        nodegroup_snow.links.new(texture_coordinate_002.outputs[0], mapping_002.inputs[0])
        #noise_texture.Fac -> mix_003.A
        nodegroup_snow.links.new(noise_texture.outputs[0], mix_003.inputs[6])
        #color_ramp.Color -> math.Value
        nodegroup_snow.links.new(color_ramp.outputs[0], math.inputs[0])
        #image_texture_006.Color -> normal_map_001.Color
        nodegroup_snow.links.new(image_texture_006.outputs[0], normal_map_001.inputs[1])
        #group_input.Grass Strength -> normal_map_001.Strength
        nodegroup_snow.links.new(group_input.outputs[6], normal_map_001.inputs[0])
        return nodegroup_snow

    nodegroup_snow = nodegroup_snow_node_group()

    #initialize Snow Material node group
    def snow_material_node_group():

        snow_material = mat.node_tree
        #start with a clean node tree
        for node in snow_material.nodes:
            snow_material.nodes.remove(node)
        snow_material.color_tag = 'NONE'
        snow_material.description = ""
        snow_material.default_group_node_width = 140
        

        #snow_material interface

        #initialize snow_material nodes
        #node Material Output
        material_output = snow_material.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Group
        group = snow_material.nodes.new("ShaderNodeGroup")
        group.name = "Group"
        group.node_tree = nodegroup_snow
        #Socket_6
        group.inputs[0].default_value = 0.30000001192092896
        #Socket_3
        group.inputs[1].default_value = 18.600000381469727
        #Socket_2
        group.inputs[2].default_value = 2.0
        #Socket_4
        group.inputs[3].default_value = (0.47076845169067383, 0.15473628044128418, 0.049583423882722855, 1.0)
        #Socket_5
        group.inputs[4].default_value = (1.0, 1.0, 1.0, 1.0)
        #Socket_7
        group.inputs[5].default_value = 0.10000002384185791
        #Socket_8
        group.inputs[6].default_value = 5.960464477539063e-08


        #Set locations
        material_output.location = (1722.140869140625, 239.97830200195312)
        group.location = (1443.3685302734375, 220.238037109375)

        #Set dimensions
        material_output.width, material_output.height = 140.0, 100.0
        group.width, group.height = 207.6400146484375, 100.0

        #initialize snow_material links
        #group.Shader -> material_output.Surface
        snow_material.links.new(group.outputs[1], material_output.inputs[0])
        #group.Displacement -> material_output.Displacement
        snow_material.links.new(group.outputs[0], material_output.inputs[2])
        return snow_material

    snow_material_node_group()
    return mat


def create_terrain_material():
    if "Terrain Material" in bpy.data.materials:
        return bpy.data.materials["Terrain Material"]


    mat = bpy.data.materials.new(name = "Terrain Material")
    mat.use_nodes = True
    #initialize NodeGroup.001 node group
    def nodegroup_001_node_group():

        nodegroup_001 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "NodeGroup.001")

        nodegroup_001.color_tag = 'NONE'
        nodegroup_001.description = ""
        nodegroup_001.default_group_node_width = 140
        

        #nodegroup_001 interface
        #Socket Displacement
        displacement_socket = nodegroup_001.interface.new_socket(name = "Displacement", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        displacement_socket.default_value = (0.0, 0.0, 0.0)
        displacement_socket.min_value = -3.4028234663852886e+38
        displacement_socket.max_value = 3.4028234663852886e+38
        displacement_socket.subtype = 'NONE'
        displacement_socket.attribute_domain = 'POINT'

        #Socket Shader
        shader_socket = nodegroup_001.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
        shader_socket.attribute_domain = 'POINT'

        #Socket Rock Strength
        rock_strength_socket = nodegroup_001.interface.new_socket(name = "Rock Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rock_strength_socket.default_value = 0.09000000357627869
        rock_strength_socket.min_value = 0.0
        rock_strength_socket.max_value = 0.30000001192092896
        rock_strength_socket.subtype = 'NONE'
        rock_strength_socket.attribute_domain = 'POINT'

        #Socket Rock Scale
        rock_scale_socket = nodegroup_001.interface.new_socket(name = "Rock Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rock_scale_socket.default_value = 1.0
        rock_scale_socket.min_value = 1.0
        rock_scale_socket.max_value = 3.4028234663852886e+38
        rock_scale_socket.subtype = 'NONE'
        rock_scale_socket.attribute_domain = 'POINT'

        #Socket Grass Scale
        grass_scale_socket = nodegroup_001.interface.new_socket(name = "Grass Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_scale_socket.default_value = 10.0
        grass_scale_socket.min_value = 10.0
        grass_scale_socket.max_value = 10.0
        grass_scale_socket.subtype = 'NONE'
        grass_scale_socket.attribute_domain = 'POINT'

        #Socket Rock Color
        rock_color_socket = nodegroup_001.interface.new_socket(name = "Rock Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        rock_color_socket.default_value = (1.0, 0.48254817724227905, 0.328963965177536, 1.0)
        rock_color_socket.attribute_domain = 'POINT'

        #Socket Grass Color
        grass_color_socket = nodegroup_001.interface.new_socket(name = "Grass Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        grass_color_socket.default_value = (0.8460381031036377, 0.9430891275405884, 0.20860043168067932, 1.0)
        grass_color_socket.attribute_domain = 'POINT'

        #Socket Grass Covered
        grass_covered_socket = nodegroup_001.interface.new_socket(name = "Grass Covered", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_covered_socket.default_value = 0.0
        grass_covered_socket.min_value = 0.0
        grass_covered_socket.max_value = 0.30000001192092896
        grass_covered_socket.subtype = 'NONE'
        grass_covered_socket.attribute_domain = 'POINT'

        #Socket Grass Strength
        grass_strength_socket = nodegroup_001.interface.new_socket(name = "Grass Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        grass_strength_socket.default_value = 3.0
        grass_strength_socket.min_value = 0.0
        grass_strength_socket.max_value = 10.0
        grass_strength_socket.subtype = 'NONE'
        grass_strength_socket.attribute_domain = 'POINT'


        #initialize nodegroup_001 nodes
        #node Group Output
        group_output = nodegroup_001.nodes.new("NodeGroupOutput")
        group_output.name = "Group Output"
        group_output.is_active_output = True

        #node Group Input
        group_input = nodegroup_001.nodes.new("NodeGroupInput")
        group_input.name = "Group Input"

        #node Principled BSDF
        principled_bsdf = nodegroup_001.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'MULTI_GGX'
        principled_bsdf.subsurface_method = 'RANDOM_WALK'
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Normal
        principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Specular Tint
        principled_bsdf.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Image Texture
        image_texture = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture.label = "Displacement"
        image_texture.name = "Image Texture"
        image_texture.extension = 'REPEAT'
        if "rock_face_03_disp_4k.png" in bpy.data.images:
            image_texture.image = bpy.data.images["rock_face_03_disp_4k.png"]
        image_texture.image_user.frame_current = 1
        image_texture.image_user.frame_duration = 1
        image_texture.image_user.frame_offset = 3
        image_texture.image_user.frame_start = 1
        image_texture.image_user.tile = 0
        image_texture.image_user.use_auto_refresh = False
        image_texture.image_user.use_cyclic = False
        image_texture.interpolation = 'Linear'
        image_texture.projection = 'FLAT'
        image_texture.projection_blend = 0.0

        #node Displacement
        displacement = nodegroup_001.nodes.new("ShaderNodeDisplacement")
        displacement.name = "Displacement"
        displacement.space = 'OBJECT'
        #Midlevel
        displacement.inputs[1].default_value = 0.0
        #Normal
        displacement.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Image Texture.001
        image_texture_001 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_001.label = "Base Color"
        image_texture_001.name = "Image Texture.001"
        image_texture_001.extension = 'REPEAT'
        if "rock_face_03_diff.png" in bpy.data.images:
            image_texture_001.image = bpy.data.images["rock_face_03_diff.png"]
        image_texture_001.image_user.frame_current = 1
        image_texture_001.image_user.frame_duration = 1
        image_texture_001.image_user.frame_offset = 2
        image_texture_001.image_user.frame_start = 1
        image_texture_001.image_user.tile = 0
        image_texture_001.image_user.use_auto_refresh = False
        image_texture_001.image_user.use_cyclic = False
        image_texture_001.interpolation = 'Linear'
        image_texture_001.projection = 'FLAT'
        image_texture_001.projection_blend = 0.0

        #node Image Texture.002
        image_texture_002 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_002.label = "Roughness"
        image_texture_002.name = "Image Texture.002"
        image_texture_002.extension = 'REPEAT'
        if "rock_face_03_rough.png" in bpy.data.images:
            image_texture_002.image = bpy.data.images["rock_face_03_rough.png"]
        image_texture_002.image_user.frame_current = 1
        image_texture_002.image_user.frame_duration = 1
        image_texture_002.image_user.frame_offset = 2
        image_texture_002.image_user.frame_start = 1
        image_texture_002.image_user.tile = 0
        image_texture_002.image_user.use_auto_refresh = False
        image_texture_002.image_user.use_cyclic = False
        image_texture_002.interpolation = 'Linear'
        image_texture_002.projection = 'FLAT'
        image_texture_002.projection_blend = 0.0

        #node Image Texture.003
        image_texture_003 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_003.label = "Normal"
        image_texture_003.name = "Image Texture.003"
        image_texture_003.extension = 'REPEAT'
        image_texture_003.image_user.frame_current = 1
        image_texture_003.image_user.frame_duration = 1
        image_texture_003.image_user.frame_offset = 2
        image_texture_003.image_user.frame_start = 1
        image_texture_003.image_user.tile = 0
        image_texture_003.image_user.use_auto_refresh = False
        image_texture_003.image_user.use_cyclic = False
        image_texture_003.interpolation = 'Linear'
        image_texture_003.projection = 'FLAT'
        image_texture_003.projection_blend = 0.0

        #node Normal Map
        normal_map = nodegroup_001.nodes.new("ShaderNodeNormalMap")
        normal_map.name = "Normal Map"
        normal_map.space = 'TANGENT'
        normal_map.uv_map = ""
        #Strength
        normal_map.inputs[0].default_value = 1.0

        #node Mapping
        mapping = nodegroup_001.nodes.new("ShaderNodeMapping")
        mapping.name = "Mapping"
        mapping.vector_type = 'POINT'
        #Location
        mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute
        reroute = nodegroup_001.nodes.new("NodeReroute")
        reroute.name = "Reroute"
        reroute.socket_idname = "NodeSocketVector"
        #node Texture Coordinate
        texture_coordinate = nodegroup_001.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.from_instancer = False

        #node Frame
        frame = nodegroup_001.nodes.new("NodeFrame")
        frame.label = "Mapping"
        frame.name = "Frame"
        frame.label_size = 20
        frame.shrink = True

        #node Frame.001
        frame_001 = nodegroup_001.nodes.new("NodeFrame")
        frame_001.label = "Textures"
        frame_001.name = "Frame.001"
        frame_001.label_size = 20
        frame_001.shrink = True

        #node Principled BSDF.001
        principled_bsdf_001 = nodegroup_001.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf_001.name = "Principled BSDF.001"
        principled_bsdf_001.distribution = 'MULTI_GGX'
        principled_bsdf_001.subsurface_method = 'RANDOM_WALK'
        #Metallic
        principled_bsdf_001.inputs[1].default_value = 0.0
        #IOR
        principled_bsdf_001.inputs[3].default_value = 1.5
        #Alpha
        principled_bsdf_001.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf_001.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf_001.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf_001.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf_001.inputs[10].default_value = 0.05000000074505806
        #Subsurface Anisotropy
        principled_bsdf_001.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf_001.inputs[13].default_value = 0.0
        #Specular Tint
        principled_bsdf_001.inputs[14].default_value = (1.0, 1.0, 1.0, 1.0)
        #Anisotropic
        principled_bsdf_001.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf_001.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf_001.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf_001.inputs[18].default_value = 0.0
        #Coat Weight
        principled_bsdf_001.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf_001.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf_001.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf_001.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf_001.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf_001.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf_001.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf_001.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Color
        principled_bsdf_001.inputs[27].default_value = (1.0, 1.0, 1.0, 1.0)
        #Emission Strength
        principled_bsdf_001.inputs[28].default_value = 0.0
        #Thin Film Thickness
        principled_bsdf_001.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf_001.inputs[30].default_value = 1.3300000429153442

        #node Mix Shader
        mix_shader = nodegroup_001.nodes.new("ShaderNodeMixShader")
        mix_shader.name = "Mix Shader"

        #node Image Texture.004
        image_texture_004 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_004.label = "Base Color"
        image_texture_004.name = "Image Texture.004"
        image_texture_004.extension = 'REPEAT'
        if "grass 03_Albedo.jpg" in bpy.data.images:
            image_texture_004.image = bpy.data.images["grass 03_Albedo.jpg"]
        image_texture_004.image_user.frame_current = 1
        image_texture_004.image_user.frame_duration = 1
        image_texture_004.image_user.frame_offset = 2
        image_texture_004.image_user.frame_start = 1
        image_texture_004.image_user.tile = 0
        image_texture_004.image_user.use_auto_refresh = False
        image_texture_004.image_user.use_cyclic = False
        image_texture_004.interpolation = 'Linear'
        image_texture_004.projection = 'FLAT'
        image_texture_004.projection_blend = 0.0

        #node Image Texture.005
        image_texture_005 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_005.label = "Roughness"
        image_texture_005.name = "Image Texture.005"
        image_texture_005.extension = 'REPEAT'
        if "grass 03_Roughness.jpg" in bpy.data.images:
            image_texture_005.image = bpy.data.images["grass 03_Roughness.jpg"]
        image_texture_005.image_user.frame_current = 1
        image_texture_005.image_user.frame_duration = 1
        image_texture_005.image_user.frame_offset = 2
        image_texture_005.image_user.frame_start = 1
        image_texture_005.image_user.tile = 0
        image_texture_005.image_user.use_auto_refresh = False
        image_texture_005.image_user.use_cyclic = False
        image_texture_005.interpolation = 'Linear'
        image_texture_005.projection = 'FLAT'
        image_texture_005.projection_blend = 0.0

        #node Image Texture.006
        image_texture_006 = nodegroup_001.nodes.new("ShaderNodeTexImage")
        image_texture_006.label = "Normal"
        image_texture_006.name = "Image Texture.006"
        image_texture_006.extension = 'REPEAT'
        if "grass 03_Normal.jpg" in bpy.data.images:
            image_texture_006.image = bpy.data.images["grass 03_Normal.jpg"]
        image_texture_006.image_user.frame_current = 1
        image_texture_006.image_user.frame_duration = 1
        image_texture_006.image_user.frame_offset = 2
        image_texture_006.image_user.frame_start = 1
        image_texture_006.image_user.tile = 0
        image_texture_006.image_user.use_auto_refresh = False
        image_texture_006.image_user.use_cyclic = False
        image_texture_006.interpolation = 'Linear'
        image_texture_006.projection = 'FLAT'
        image_texture_006.projection_blend = 0.0

        #node Normal Map.001
        normal_map_001 = nodegroup_001.nodes.new("ShaderNodeNormalMap")
        normal_map_001.name = "Normal Map.001"
        normal_map_001.space = 'TANGENT'
        normal_map_001.uv_map = ""

        #node Mapping.001
        mapping_001 = nodegroup_001.nodes.new("ShaderNodeMapping")
        mapping_001.name = "Mapping.001"
        mapping_001.vector_type = 'POINT'
        #Location
        mapping_001.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping_001.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute.001
        reroute_001 = nodegroup_001.nodes.new("NodeReroute")
        reroute_001.name = "Reroute.001"
        reroute_001.socket_idname = "NodeSocketVector"
        #node Texture Coordinate.001
        texture_coordinate_001 = nodegroup_001.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_001.name = "Texture Coordinate.001"
        texture_coordinate_001.from_instancer = False

        #node Frame.002
        frame_002 = nodegroup_001.nodes.new("NodeFrame")
        frame_002.label = "Mapping"
        frame_002.name = "Frame.002"
        frame_002.label_size = 20
        frame_002.shrink = True

        #node Frame.003
        frame_003 = nodegroup_001.nodes.new("NodeFrame")
        frame_003.label = "Textures"
        frame_003.name = "Frame.003"
        frame_003.label_size = 20
        frame_003.shrink = True

        #node Geometry
        geometry = nodegroup_001.nodes.new("ShaderNodeNewGeometry")
        geometry.name = "Geometry"

        #node Separate XYZ
        separate_xyz = nodegroup_001.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"

        #node Color Ramp
        color_ramp = nodegroup_001.nodes.new("ShaderNodeValToRGB")
        color_ramp.name = "Color Ramp"
        color_ramp.color_ramp.color_mode = 'RGB'
        color_ramp.color_ramp.hue_interpolation = 'NEAR'
        color_ramp.color_ramp.interpolation = 'EASE'

        #initialize color ramp elements
        color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
        color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
        color_ramp_cre_0.position = 0.0
        color_ramp_cre_0.alpha = 1.0
        color_ramp_cre_0.color = (0.49229443073272705, 0.49229443073272705, 0.49229443073272705, 1.0)

        color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
        color_ramp_cre_1.alpha = 1.0
        color_ramp_cre_1.color = (0.9645918607711792, 0.9645918607711792, 0.9645918607711792, 1.0)


        #node Mix
        mix = nodegroup_001.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.blend_type = 'MIX'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'RGBA'
        mix.factor_mode = 'UNIFORM'
        #B_Color
        mix.inputs[7].default_value = (0.6028310060501099, 0.6028310060501099, 0.6028310060501099, 1.0)

        #node Group Input.001
        group_input_001 = nodegroup_001.nodes.new("NodeGroupInput")
        group_input_001.name = "Group Input.001"

        #node Color Ramp.002
        color_ramp_002 = nodegroup_001.nodes.new("ShaderNodeValToRGB")
        color_ramp_002.name = "Color Ramp.002"
        color_ramp_002.color_ramp.color_mode = 'RGB'
        color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_002.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
        color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
        color_ramp_002_cre_0.position = 0.0
        color_ramp_002_cre_0.alpha = 1.0
        color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(1.0)
        color_ramp_002_cre_1.alpha = 1.0
        color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)


        #node Mix.001
        mix_001 = nodegroup_001.nodes.new("ShaderNodeMix")
        mix_001.name = "Mix.001"
        mix_001.blend_type = 'MIX'
        mix_001.clamp_factor = True
        mix_001.clamp_result = False
        mix_001.data_type = 'RGBA'
        mix_001.factor_mode = 'UNIFORM'
        #A_Color
        mix_001.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)

        #node Color Ramp.001
        color_ramp_001 = nodegroup_001.nodes.new("ShaderNodeValToRGB")
        color_ramp_001.name = "Color Ramp.001"
        color_ramp_001.color_ramp.color_mode = 'RGB'
        color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_001.color_ramp.interpolation = 'LINEAR'

        #initialize color ramp elements
        color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
        color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
        color_ramp_001_cre_0.position = 0.0
        color_ramp_001_cre_0.alpha = 1.0
        color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(1.0)
        color_ramp_001_cre_1.alpha = 1.0
        color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)


        #node Mix.002
        mix_002 = nodegroup_001.nodes.new("ShaderNodeMix")
        mix_002.name = "Mix.002"
        mix_002.blend_type = 'MIX'
        mix_002.clamp_factor = True
        mix_002.clamp_result = False
        mix_002.data_type = 'RGBA'
        mix_002.factor_mode = 'UNIFORM'
        #A_Color
        mix_002.inputs[6].default_value = (0.0, 0.0, 0.0, 1.0)

        #node Math
        math = nodegroup_001.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.operation = 'ADD'
        math.use_clamp = False

        #node Mix.003
        mix_003 = nodegroup_001.nodes.new("ShaderNodeMix")
        mix_003.name = "Mix.003"
        mix_003.blend_type = 'MIX'
        mix_003.clamp_factor = True
        mix_003.clamp_result = False
        mix_003.data_type = 'RGBA'
        mix_003.factor_mode = 'UNIFORM'
        #Factor_Float
        mix_003.inputs[0].default_value = 0.5083333253860474
        #B_Color
        mix_003.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)

        #node Noise Texture
        noise_texture = nodegroup_001.nodes.new("ShaderNodeTexNoise")
        noise_texture.name = "Noise Texture"
        noise_texture.noise_dimensions = '3D'
        noise_texture.noise_type = 'FBM'
        noise_texture.normalize = True
        #Scale
        noise_texture.inputs[2].default_value = 45.0
        #Detail
        noise_texture.inputs[3].default_value = 4.199999809265137
        #Roughness
        noise_texture.inputs[4].default_value = 0.5
        #Lacunarity
        noise_texture.inputs[5].default_value = 2.0
        #Distortion
        noise_texture.inputs[8].default_value = 0.0

        #node Mapping.002
        mapping_002 = nodegroup_001.nodes.new("ShaderNodeMapping")
        mapping_002.name = "Mapping.002"
        mapping_002.vector_type = 'POINT'
        #Location
        mapping_002.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Rotation
        mapping_002.inputs[2].default_value = (0.0, 0.0, 0.0)
        #Scale
        mapping_002.inputs[3].default_value = (1.0, 1.0, 1.0)

        #node Texture Coordinate.002
        texture_coordinate_002 = nodegroup_001.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_002.name = "Texture Coordinate.002"
        texture_coordinate_002.from_instancer = False

        #Set parents
        image_texture.parent = frame_001
        image_texture_001.parent = frame_001
        image_texture_002.parent = frame_001
        image_texture_003.parent = frame_001
        mapping.parent = frame
        reroute.parent = frame_001
        texture_coordinate.parent = frame
        image_texture_004.parent = frame_003
        image_texture_005.parent = frame_003
        image_texture_006.parent = frame_003
        mapping_001.parent = frame_002
        reroute_001.parent = frame_003
        texture_coordinate_001.parent = frame_002
        group_input_001.parent = frame

        #Set locations
        group_output.location = (1862.6331787109375, 0.0)
        group_input.location = (-73.310302734375, -1062.5828857421875)
        principled_bsdf.location = (123.935302734375, 516.8970947265625)
        image_texture.location = (-540.9822998046875, -12.877304077148438)
        displacement.location = (1378.4278564453125, 95.91932678222656)
        image_texture_001.location = (-580.1441040039062, 645.1151123046875)
        image_texture_002.location = (-569.3236694335938, 319.1101989746094)
        image_texture_003.location = (-540.0, -340.0)
        normal_map.location = (-229.93890380859375, -43.9849853515625)
        mapping.location = (-1040.0, 300.0)
        reroute.location = (-590.0, -56.0)
        texture_coordinate.location = (-1240.0, 300.0)
        frame.location = (11.40283203125, 216.89712524414062)
        frame_001.location = (11.40283203125, 216.89712524414062)
        principled_bsdf_001.location = (1212.1942138671875, -437.73736572265625)
        mix_shader.location = (1406.980224609375, 592.17529296875)
        image_texture_004.location = (323.49432373046875, -455.69580078125)
        image_texture_005.location = (323.49432373046875, -735.69580078125)
        image_texture_006.location = (323.49432373046875, -1015.69580078125)
        normal_map_001.location = (837.7806396484375, -743.755126953125)
        mapping_001.location = (-174.93695068359375, -679.2033081054688)
        reroute_001.location = (273.49432373046875, -671.7718505859375)
        texture_coordinate_001.location = (-376.50567626953125, -655.69580078125)
        frame_002.location = (45.29180908203125, 179.69601440429688)
        frame_003.location = (46.29180908203125, 179.696044921875)
        geometry.location = (241.89498901367188, 957.1224975585938)
        separate_xyz.location = (412.03533935546875, 893.85546875)
        color_ramp.location = (629.1055908203125, 920.2234497070312)
        mix.location = (1054.762939453125, 457.1654052734375)
        group_input_001.location = (-1040.681884765625, -111.18919372558594)
        color_ramp_002.location = (-232.00286865234375, 1127.3812255859375)
        mix_001.location = (44.89693069458008, 1043.0)
        color_ramp_001.location = (629.3560180664062, -36.09300994873047)
        mix_002.location = (942.7572021484375, -131.34803771972656)
        math.location = (1101.5970458984375, 727.1475830078125)
        mix_003.location = (983.9714965820312, 1045.10009765625)
        noise_texture.location = (668.6510009765625, 1221.7752685546875)
        mapping_002.location = (456.531494140625, 1294.8138427734375)
        texture_coordinate_002.location = (276.531494140625, 1294.8138427734375)

        #Set dimensions
        group_output.width, group_output.height = 140.0, 100.0
        group_input.width, group_input.height = 140.0, 100.0
        principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
        image_texture.width, image_texture.height = 240.0, 100.0
        displacement.width, displacement.height = 140.0, 100.0
        image_texture_001.width, image_texture_001.height = 252.6068115234375, 100.0
        image_texture_002.width, image_texture_002.height = 240.0, 100.0
        image_texture_003.width, image_texture_003.height = 240.0, 100.0
        normal_map.width, normal_map.height = 150.0, 100.0
        mapping.width, mapping.height = 140.0, 100.0
        reroute.width, reroute.height = 16.0, 100.0
        texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
        frame.width, frame.height = 400.0, 685.0
        frame_001.width, frame_001.height = 357.59716796875, 1251.0
        principled_bsdf_001.width, principled_bsdf_001.height = 240.0, 100.0
        mix_shader.width, mix_shader.height = 140.0, 100.0
        image_texture_004.width, image_texture_004.height = 240.0, 100.0
        image_texture_005.width, image_texture_005.height = 240.0, 100.0
        image_texture_006.width, image_texture_006.height = 240.0, 100.0
        normal_map_001.width, normal_map_001.height = 150.0, 100.0
        mapping_001.width, mapping_001.height = 140.0, 100.0
        reroute_001.width, reroute_001.height = 16.0, 100.0
        texture_coordinate_001.width, texture_coordinate_001.height = 140.0, 100.0
        frame_002.width, frame_002.height = 401.0, 383.0
        frame_003.width, frame_003.height = 358.2138671875, 901.0
        geometry.width, geometry.height = 140.0, 100.0
        separate_xyz.width, separate_xyz.height = 140.0, 100.0
        color_ramp.width, color_ramp.height = 240.0, 100.0
        mix.width, mix.height = 140.0, 100.0
        group_input_001.width, group_input_001.height = 140.0, 100.0
        color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
        mix_001.width, mix_001.height = 140.0, 100.0
        color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
        mix_002.width, mix_002.height = 140.0, 100.0
        math.width, math.height = 140.0, 100.0
        mix_003.width, mix_003.height = 140.0, 100.0
        noise_texture.width, noise_texture.height = 140.0, 100.0
        mapping_002.width, mapping_002.height = 140.0, 100.0
        texture_coordinate_002.width, texture_coordinate_002.height = 140.0, 100.0

        #initialize nodegroup_001 links
        #normal_map_001.Normal -> principled_bsdf_001.Normal
        nodegroup_001.links.new(normal_map_001.outputs[0], principled_bsdf_001.inputs[5])
        #reroute_001.Output -> image_texture_006.Vector
        nodegroup_001.links.new(reroute_001.outputs[0], image_texture_006.inputs[0])
        #image_texture_002.Color -> principled_bsdf.Roughness
        nodegroup_001.links.new(image_texture_002.outputs[0], principled_bsdf.inputs[2])
        #texture_coordinate_001.Generated -> mapping_001.Vector
        nodegroup_001.links.new(texture_coordinate_001.outputs[0], mapping_001.inputs[0])
        #reroute.Output -> image_texture_001.Vector
        nodegroup_001.links.new(reroute.outputs[0], image_texture_001.inputs[0])
        #image_texture.Color -> mix.A
        nodegroup_001.links.new(image_texture.outputs[0], mix.inputs[6])
        #reroute.Output -> image_texture_003.Vector
        nodegroup_001.links.new(reroute.outputs[0], image_texture_003.inputs[0])
        #mapping.Vector -> reroute.Input
        nodegroup_001.links.new(mapping.outputs[0], reroute.inputs[0])
        #color_ramp.Color -> mix.Factor
        nodegroup_001.links.new(color_ramp.outputs[0], mix.inputs[0])
        #texture_coordinate.Generated -> mapping.Vector
        nodegroup_001.links.new(texture_coordinate.outputs[0], mapping.inputs[0])
        #image_texture_005.Color -> principled_bsdf_001.Roughness
        nodegroup_001.links.new(image_texture_005.outputs[0], principled_bsdf_001.inputs[2])
        #principled_bsdf_001.BSDF -> mix_shader.Shader
        nodegroup_001.links.new(principled_bsdf_001.outputs[0], mix_shader.inputs[2])
        #mix.Result -> displacement.Height
        nodegroup_001.links.new(mix.outputs[2], displacement.inputs[0])
        #geometry.Normal -> separate_xyz.Vector
        nodegroup_001.links.new(geometry.outputs[1], separate_xyz.inputs[0])
        #image_texture_003.Color -> normal_map.Color
        nodegroup_001.links.new(image_texture_003.outputs[0], normal_map.inputs[1])
        #reroute.Output -> image_texture_002.Vector
        nodegroup_001.links.new(reroute.outputs[0], image_texture_002.inputs[0])
        #reroute.Output -> image_texture.Vector
        nodegroup_001.links.new(reroute.outputs[0], image_texture.inputs[0])
        #mapping_001.Vector -> reroute_001.Input
        nodegroup_001.links.new(mapping_001.outputs[0], reroute_001.inputs[0])
        #reroute_001.Output -> image_texture_005.Vector
        nodegroup_001.links.new(reroute_001.outputs[0], image_texture_005.inputs[0])
        #reroute_001.Output -> image_texture_004.Vector
        nodegroup_001.links.new(reroute_001.outputs[0], image_texture_004.inputs[0])
        #principled_bsdf.BSDF -> mix_shader.Shader
        nodegroup_001.links.new(principled_bsdf.outputs[0], mix_shader.inputs[1])
        #displacement.Displacement -> group_output.Displacement
        nodegroup_001.links.new(displacement.outputs[0], group_output.inputs[0])
        #mix_shader.Shader -> group_output.Shader
        nodegroup_001.links.new(mix_shader.outputs[0], group_output.inputs[1])
        #group_input.Grass Scale -> mapping_001.Scale
        nodegroup_001.links.new(group_input.outputs[2], mapping_001.inputs[3])
        #group_input_001.Rock Scale -> mapping.Scale
        nodegroup_001.links.new(group_input_001.outputs[1], mapping.inputs[3])
        #image_texture_001.Color -> color_ramp_002.Fac
        nodegroup_001.links.new(image_texture_001.outputs[0], color_ramp_002.inputs[0])
        #color_ramp_002.Color -> mix_001.Factor
        nodegroup_001.links.new(color_ramp_002.outputs[0], mix_001.inputs[0])
        #mix_001.Result -> principled_bsdf.Base Color
        nodegroup_001.links.new(mix_001.outputs[2], principled_bsdf.inputs[0])
        #group_input_001.Rock Color -> mix_001.B
        nodegroup_001.links.new(group_input_001.outputs[3], mix_001.inputs[7])
        #image_texture_004.Color -> color_ramp_001.Fac
        nodegroup_001.links.new(image_texture_004.outputs[0], color_ramp_001.inputs[0])
        #color_ramp_001.Color -> mix_002.Factor
        nodegroup_001.links.new(color_ramp_001.outputs[0], mix_002.inputs[0])
        #mix_002.Result -> principled_bsdf_001.Base Color
        nodegroup_001.links.new(mix_002.outputs[2], principled_bsdf_001.inputs[0])
        #group_input.Grass Color -> mix_002.B
        nodegroup_001.links.new(group_input.outputs[4], mix_002.inputs[7])
        #group_input_001.Rock Strength -> displacement.Scale
        nodegroup_001.links.new(group_input_001.outputs[0], displacement.inputs[2])
        #math.Value -> mix_shader.Fac
        nodegroup_001.links.new(math.outputs[0], mix_shader.inputs[0])
        #group_input_001.Grass Covered -> math.Value
        nodegroup_001.links.new(group_input_001.outputs[5], math.inputs[1])
        #separate_xyz.Z -> color_ramp.Fac
        nodegroup_001.links.new(separate_xyz.outputs[2], color_ramp.inputs[0])
        #mapping_002.Vector -> noise_texture.Vector
        nodegroup_001.links.new(mapping_002.outputs[0], noise_texture.inputs[0])
        #texture_coordinate_002.Generated -> mapping_002.Vector
        nodegroup_001.links.new(texture_coordinate_002.outputs[0], mapping_002.inputs[0])
        #noise_texture.Fac -> mix_003.A
        nodegroup_001.links.new(noise_texture.outputs[0], mix_003.inputs[6])
        #color_ramp.Color -> math.Value
        nodegroup_001.links.new(color_ramp.outputs[0], math.inputs[0])
        #image_texture_006.Color -> normal_map_001.Color
        nodegroup_001.links.new(image_texture_006.outputs[0], normal_map_001.inputs[1])
        #group_input.Grass Strength -> normal_map_001.Strength
        nodegroup_001.links.new(group_input.outputs[6], normal_map_001.inputs[0])
        return nodegroup_001

    nodegroup_001 = nodegroup_001_node_group()

    #initialize Terrain Material node group
    def terrain_material_node_group():

        terrain_material = mat.node_tree
        #start with a clean node tree
        for node in terrain_material.nodes:
            terrain_material.nodes.remove(node)
        terrain_material.color_tag = 'NONE'
        terrain_material.description = ""
        terrain_material.default_group_node_width = 140
        

        #terrain_material interface

        #initialize terrain_material nodes
        #node Material Output
        material_output = terrain_material.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Group
        group = terrain_material.nodes.new("ShaderNodeGroup")
        group.name = "Group"
        group.node_tree = nodegroup_001
        #Socket_6
        group.inputs[0].default_value = 0.09000000357627869
        #Socket_3
        group.inputs[1].default_value = 25.0
        #Socket_2
        group.inputs[2].default_value = 3.0
        #Socket_4
        group.inputs[3].default_value = (1.0, 0.4207128882408142, 0.2090924233198166, 1.0)
        #Socket_5
        group.inputs[4].default_value = (0.365018367767334, 0.5576605796813965, 0.1692390739917755, 1.0)
        #Socket_7
        group.inputs[5].default_value = 0.009999999776482582
        #Socket_8
        group.inputs[6].default_value = 1.0


        #Set locations
        material_output.location = (1722.140869140625, 239.97830200195312)
        group.location = (1443.3685302734375, 220.238037109375)

        #Set dimensions
        material_output.width, material_output.height = 140.0, 100.0
        group.width, group.height = 207.6400146484375, 100.0

        #initialize terrain_material links
        #group.Shader -> material_output.Surface
        terrain_material.links.new(group.outputs[1], material_output.inputs[0])
        #group.Displacement -> material_output.Displacement
        terrain_material.links.new(group.outputs[0], material_output.inputs[2])
        return terrain_material

    terrain_material = terrain_material_node_group()
    return mat

def create_ocean_material():
    if "Ocean.001" in bpy.data.materials:
        return bpy.data.materials["Ocean.001"]


    mat = bpy.data.materials.new(name = "Ocean.001")
    mat.use_nodes = True
    #initialize Fresnel node group
    def fresnel_node_group():

        fresnel = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Fresnel")

        fresnel.color_tag = 'NONE'
        fresnel.description = ""
        fresnel.default_group_node_width = 140
        

        #fresnel interface
        #Socket Fresnel
        fresnel_socket = fresnel.interface.new_socket(name = "Fresnel", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        fresnel_socket.default_value = 0.0
        fresnel_socket.min_value = 0.0
        fresnel_socket.max_value = 1.0
        fresnel_socket.subtype = 'FACTOR'
        fresnel_socket.attribute_domain = 'POINT'

        #Socket Metallic Rim
        metallic_rim_socket = fresnel.interface.new_socket(name = "Metallic Rim", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        metallic_rim_socket.default_value = 0.0
        metallic_rim_socket.min_value = 0.0
        metallic_rim_socket.max_value = 0.0
        metallic_rim_socket.subtype = 'NONE'
        metallic_rim_socket.attribute_domain = 'POINT'

        #Socket Metallic Fresnel
        metallic_fresnel_socket = fresnel.interface.new_socket(name = "Metallic Fresnel", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        metallic_fresnel_socket.default_value = 0.0
        metallic_fresnel_socket.min_value = 0.0
        metallic_fresnel_socket.max_value = 0.0
        metallic_fresnel_socket.subtype = 'NONE'
        metallic_fresnel_socket.attribute_domain = 'POINT'

        #Socket Roughness
        roughness_socket = fresnel.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        roughness_socket.default_value = 0.5
        roughness_socket.min_value = 0.0
        roughness_socket.max_value = 1.0
        roughness_socket.subtype = 'FACTOR'
        roughness_socket.attribute_domain = 'POINT'

        #Socket Fac
        fac_socket = fresnel.interface.new_socket(name = "Fac", in_out='INPUT', socket_type = 'NodeSocketFloat')
        fac_socket.default_value = 0.5
        fac_socket.min_value = 0.0
        fac_socket.max_value = 1.0
        fac_socket.subtype = 'FACTOR'
        fac_socket.attribute_domain = 'POINT'

        #Socket Rim
        rim_socket = fresnel.interface.new_socket(name = "Rim", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rim_socket.default_value = 0.5
        rim_socket.min_value = 0.0
        rim_socket.max_value = 1.0
        rim_socket.subtype = 'NONE'
        rim_socket.attribute_domain = 'POINT'

        #Socket Normal
        normal_socket = fresnel.interface.new_socket(name = "Normal", in_out='INPUT', socket_type = 'NodeSocketVector')
        normal_socket.default_value = (0.0, 0.0, 0.0)
        normal_socket.min_value = -1.0
        normal_socket.max_value = 1.0
        normal_socket.subtype = 'NONE'
        normal_socket.attribute_domain = 'POINT'
        normal_socket.hide_value = True


        #initialize fresnel nodes
        #node FRENSEL NODE
        frensel_node = fresnel.nodes.new("NodeFrame")
        frensel_node.label = "FRENSEL NODE"
        frensel_node.name = "FRENSEL NODE"
        frensel_node.use_custom_color = True
        frensel_node.color = (0.0, 0.5738130211830139, 0.6080020070075989)
        frensel_node.label_size = 15
        frensel_node.shrink = True

        #node Author
        author = fresnel.nodes.new("NodeFrame")
        author.label = "By: Dr. Hacker \"BE HACK 2000\""
        author.name = "Author"
        author.use_custom_color = True
        author.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author.label_size = 16
        author.shrink = True

        #node Mix
        mix = fresnel.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.blend_type = 'MIX'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'RGBA'
        mix.factor_mode = 'UNIFORM'

        #node Reroute.003
        reroute_003 = fresnel.nodes.new("NodeReroute")
        reroute_003.name = "Reroute.003"
        reroute_003.socket_idname = "NodeSocketVector"
        #node Reroute.009
        reroute_009 = fresnel.nodes.new("NodeReroute")
        reroute_009.name = "Reroute.009"
        reroute_009.socket_idname = "NodeSocketColor"
        #node Reroute.008
        reroute_008 = fresnel.nodes.new("NodeReroute")
        reroute_008.name = "Reroute.008"
        reroute_008.socket_idname = "NodeSocketColor"
        #node Layer Weight.001
        layer_weight_001 = fresnel.nodes.new("ShaderNodeLayerWeight")
        layer_weight_001.name = "Layer Weight.001"

        #node Reroute.006
        reroute_006 = fresnel.nodes.new("NodeReroute")
        reroute_006.name = "Reroute.006"
        reroute_006.socket_idname = "NodeSocketColor"
        #node Reroute.011
        reroute_011 = fresnel.nodes.new("NodeReroute")
        reroute_011.name = "Reroute.011"
        reroute_011.socket_idname = "NodeSocketColor"
        #node Reroute.007
        reroute_007 = fresnel.nodes.new("NodeReroute")
        reroute_007.name = "Reroute.007"
        reroute_007.socket_idname = "NodeSocketFloatFactor"
        #node Math.001
        math_001 = fresnel.nodes.new("ShaderNodeMath")
        math_001.name = "Math.001"
        math_001.operation = 'SUBTRACT'
        math_001.use_clamp = True
        #Value_001
        math_001.inputs[1].default_value = 0.032999999821186066

        #node Reroute.015
        reroute_015 = fresnel.nodes.new("NodeReroute")
        reroute_015.name = "Reroute.015"
        reroute_015.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012 = fresnel.nodes.new("NodeReroute")
        reroute_012.name = "Reroute.012"
        reroute_012.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016 = fresnel.nodes.new("NodeReroute")
        reroute_016.name = "Reroute.016"
        reroute_016.socket_idname = "NodeSocketFloat"
        #node Reroute.017
        reroute_017 = fresnel.nodes.new("NodeReroute")
        reroute_017.name = "Reroute.017"
        reroute_017.socket_idname = "NodeSocketFloat"
        #node Reroute.018
        reroute_018 = fresnel.nodes.new("NodeReroute")
        reroute_018.name = "Reroute.018"
        reroute_018.socket_idname = "NodeSocketFloat"
        #node Reroute.019
        reroute_019 = fresnel.nodes.new("NodeReroute")
        reroute_019.name = "Reroute.019"
        reroute_019.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021 = fresnel.nodes.new("NodeReroute")
        reroute_021.name = "Reroute.021"
        reroute_021.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020 = fresnel.nodes.new("NodeReroute")
        reroute_020.name = "Reroute.020"
        reroute_020.socket_idname = "NodeSocketFloat"
        #node RGB Curves
        rgb_curves = fresnel.nodes.new("ShaderNodeRGBCurve")
        rgb_curves.name = "RGB Curves"
        #mapping settings
        rgb_curves.mapping.extend = 'EXTRAPOLATED'
        rgb_curves.mapping.tone = 'STANDARD'
        rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
        rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
        rgb_curves.mapping.clip_min_x = 0.0
        rgb_curves.mapping.clip_min_y = 0.0
        rgb_curves.mapping.clip_max_x = 1.0
        rgb_curves.mapping.clip_max_y = 1.0
        rgb_curves.mapping.use_clip = True
        #curve 0
        rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
        rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
        rgb_curves_curve_0_point_0.location = (0.0, 0.0)
        rgb_curves_curve_0_point_0.handle_type = 'AUTO'
        rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
        rgb_curves_curve_0_point_1.location = (1.0, 1.0)
        rgb_curves_curve_0_point_1.handle_type = 'AUTO'
        #curve 1
        rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
        rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
        rgb_curves_curve_1_point_0.location = (0.0, 0.0)
        rgb_curves_curve_1_point_0.handle_type = 'AUTO'
        rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
        rgb_curves_curve_1_point_1.location = (1.0, 1.0)
        rgb_curves_curve_1_point_1.handle_type = 'AUTO'
        #curve 2
        rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
        rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
        rgb_curves_curve_2_point_0.location = (0.0, 0.0)
        rgb_curves_curve_2_point_0.handle_type = 'AUTO'
        rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
        rgb_curves_curve_2_point_1.location = (1.0, 1.0)
        rgb_curves_curve_2_point_1.handle_type = 'AUTO'
        #curve 3
        rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
        rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
        rgb_curves_curve_3_point_0.location = (0.0, 0.0)
        rgb_curves_curve_3_point_0.handle_type = 'AUTO'
        rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
        rgb_curves_curve_3_point_1.location = (0.5, 0.33000001311302185)
        rgb_curves_curve_3_point_1.handle_type = 'AUTO'
        rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(1.0, 1.0)
        rgb_curves_curve_3_point_2.handle_type = 'AUTO'
        #update curve after changes
        rgb_curves.mapping.update()
        #Fac
        rgb_curves.inputs[0].default_value = 1.0

        #node Reroute.010
        reroute_010 = fresnel.nodes.new("NodeReroute")
        reroute_010.name = "Reroute.010"
        reroute_010.socket_idname = "NodeSocketFloatFactor"
        #node Bump.001
        bump_001 = fresnel.nodes.new("ShaderNodeBump")
        bump_001.name = "Bump.001"
        bump_001.invert = False
        #Strength
        bump_001.inputs[0].default_value = 1.0
        #Distance
        bump_001.inputs[1].default_value = 0.10000000149011612
        #Height
        bump_001.inputs[2].default_value = 1.0

        #node Geometry.001
        geometry_001 = fresnel.nodes.new("ShaderNodeNewGeometry")
        geometry_001.name = "Geometry.001"
        geometry_001.outputs[0].hide = True
        geometry_001.outputs[1].hide = True
        geometry_001.outputs[2].hide = True
        geometry_001.outputs[3].hide = True
        geometry_001.outputs[5].hide = True
        geometry_001.outputs[6].hide = True
        geometry_001.outputs[7].hide = True

        #node Reroute.002
        reroute_002 = fresnel.nodes.new("NodeReroute")
        reroute_002.name = "Reroute.002"
        reroute_002.socket_idname = "NodeSocketVector"
        #node Reroute.004
        reroute_004 = fresnel.nodes.new("NodeReroute")
        reroute_004.name = "Reroute.004"
        reroute_004.socket_idname = "NodeSocketVector"
        #node Reroute
        reroute = fresnel.nodes.new("NodeReroute")
        reroute.name = "Reroute"
        reroute.socket_idname = "NodeSocketVector"
        #node Reroute.001
        reroute_001 = fresnel.nodes.new("NodeReroute")
        reroute_001.name = "Reroute.001"
        reroute_001.socket_idname = "NodeSocketVector"
        #node Reroute.014
        reroute_014 = fresnel.nodes.new("NodeReroute")
        reroute_014.name = "Reroute.014"
        reroute_014.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022 = fresnel.nodes.new("NodeReroute")
        reroute_022.name = "Reroute.022"
        reroute_022.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013 = fresnel.nodes.new("NodeReroute")
        reroute_013.name = "Reroute.013"
        reroute_013.socket_idname = "NodeSocketFloat"
        #node Layer Weight
        layer_weight = fresnel.nodes.new("ShaderNodeLayerWeight")
        layer_weight.name = "Layer Weight"

        #node Math
        math = fresnel.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.operation = 'POWER'
        math.use_clamp = True
        #Value_001
        math.inputs[1].default_value = 2.5

        #node Reroute.024
        reroute_024 = fresnel.nodes.new("NodeReroute")
        reroute_024.name = "Reroute.024"
        reroute_024.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.005
        reroute_005 = fresnel.nodes.new("NodeReroute")
        reroute_005.name = "Reroute.005"
        reroute_005.socket_idname = "NodeSocketVector"
        #node Reroute.025
        reroute_025 = fresnel.nodes.new("NodeReroute")
        reroute_025.name = "Reroute.025"
        reroute_025.socket_idname = "NodeSocketFloatFactor"
        #node Group Input
        group_input = fresnel.nodes.new("NodeGroupInput")
        group_input.name = "Group Input"
        group_input.use_custom_color = True
        group_input.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input.outputs[4].hide = True

        #node Group Output
        group_output = fresnel.nodes.new("NodeGroupOutput")
        group_output.name = "Group Output"
        group_output.use_custom_color = True
        group_output.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output.is_active_output = True
        group_output.inputs[3].hide = True


        #Set locations
        frensel_node.location = (-1141.7890625, 15.756927490234375)
        author.location = (-560.0, -260.0)
        mix.location = (-660.0, -40.0)
        reroute_003.location = (-681.3536376953125, -175.15481567382812)
        reroute_009.location = (-499.5115966796875, -104.8412094116211)
        reroute_008.location = (-499.80999755859375, -75.20447540283203)
        layer_weight_001.location = (-460.4625244140625, -1.397003173828125)
        reroute_006.location = (-479.525634765625, -83.27304077148438)
        reroute_011.location = (-480.4625244140625, 142.98818969726562)
        reroute_007.location = (-960.0, -122.16914367675781)
        math_001.location = (-274.76300048828125, -1.397003173828125)
        reroute_015.location = (-293.1423034667969, -117.18264770507812)
        reroute_012.location = (-295.0032958984375, -36.048553466796875)
        reroute_016.location = (-295.5211181640625, 20.0)
        reroute_017.location = (-99.24838256835938, 20.692581176757812)
        reroute_018.location = (-99.24838256835938, -34.96910095214844)
        reroute_019.location = (-120.0, -80.0)
        reroute_021.location = (-120.23623657226562, -35.508453369140625)
        reroute_020.location = (-99.76129150390625, -58.48030090332031)
        rgb_curves.location = (-940.0, 179.99996948242188)
        reroute_010.location = (-959.5667114257812, -206.87545776367188)
        bump_001.location = (-840.0, -289.04461669921875)
        geometry_001.location = (-1000.0, -289.04461669921875)
        reroute_002.location = (-680.6239013671875, -325.16168212890625)
        reroute_004.location = (-864.7286987304688, -323.7213134765625)
        reroute.location = (-1013.631103515625, -249.0446014404297)
        reroute_001.location = (-1015.17431640625, -443.3625183105469)
        reroute_014.location = (-294.8819580078125, -206.63311767578125)
        reroute_022.location = (-99.059326171875, -225.15530395507812)
        reroute_013.location = (-294.78558349609375, -305.1499328613281)
        layer_weight.location = (-460.4625244140625, -150.44158935546875)
        math.location = (-274.76300048828125, -190.44158935546875)
        reroute_024.location = (-1008.9244995117188, -185.36416625976562)
        reroute_005.location = (-864.6777954101562, -195.96347045898438)
        reroute_025.location = (-1008.398193359375, -154.63580322265625)
        group_input.location = (-1173.631103515625, -149.04461669921875)
        group_output.location = (-74.01138305664062, -0.7044219970703125)

        #Set dimensions
        frensel_node.width, frensel_node.height = 221.2734375, 124.36505126953125
        author.width, author.height = 290.4298095703125, 30.0
        mix.width, mix.height = 140.0, 100.0
        reroute_003.width, reroute_003.height = 16.0, 100.0
        reroute_009.width, reroute_009.height = 16.0, 100.0
        reroute_008.width, reroute_008.height = 16.0, 100.0
        layer_weight_001.width, layer_weight_001.height = 140.0, 100.0
        reroute_006.width, reroute_006.height = 16.0, 100.0
        reroute_011.width, reroute_011.height = 16.0, 100.0
        reroute_007.width, reroute_007.height = 16.0, 100.0
        math_001.width, math_001.height = 140.0, 100.0
        reroute_015.width, reroute_015.height = 16.0, 100.0
        reroute_012.width, reroute_012.height = 16.0, 100.0
        reroute_016.width, reroute_016.height = 16.0, 100.0
        reroute_017.width, reroute_017.height = 16.0, 100.0
        reroute_018.width, reroute_018.height = 16.0, 100.0
        reroute_019.width, reroute_019.height = 16.0, 100.0
        reroute_021.width, reroute_021.height = 16.0, 100.0
        reroute_020.width, reroute_020.height = 16.0, 100.0
        rgb_curves.width, rgb_curves.height = 240.0, 100.0
        reroute_010.width, reroute_010.height = 16.0, 100.0
        bump_001.width, bump_001.height = 140.0, 100.0
        geometry_001.width, geometry_001.height = 100.0, 100.0
        reroute_002.width, reroute_002.height = 16.0, 100.0
        reroute_004.width, reroute_004.height = 16.0, 100.0
        reroute.width, reroute.height = 16.0, 100.0
        reroute_001.width, reroute_001.height = 16.0, 100.0
        reroute_014.width, reroute_014.height = 16.0, 100.0
        reroute_022.width, reroute_022.height = 16.0, 100.0
        reroute_013.width, reroute_013.height = 16.0, 100.0
        layer_weight.width, layer_weight.height = 140.0, 100.0
        math.width, math.height = 140.0, 100.0
        reroute_024.width, reroute_024.height = 16.0, 100.0
        reroute_005.width, reroute_005.height = 16.0, 100.0
        reroute_025.width, reroute_025.height = 16.0, 100.0
        group_input.width, group_input.height = 140.0, 100.0
        group_output.width, group_output.height = 140.0, 100.0

        #initialize fresnel links
        #reroute_013.Output -> math.Value
        fresnel.links.new(reroute_013.outputs[0], math.inputs[0])
        #reroute_020.Output -> group_output.Metallic Rim
        fresnel.links.new(reroute_020.outputs[0], group_output.inputs[1])
        #group_input.Rim -> layer_weight.Blend
        fresnel.links.new(group_input.outputs[2], layer_weight.inputs[0])
        #reroute_005.Output -> mix.B
        fresnel.links.new(reroute_005.outputs[0], mix.inputs[7])
        #reroute_007.Output -> rgb_curves.Color
        fresnel.links.new(reroute_007.outputs[0], rgb_curves.inputs[1])
        #reroute_015.Output -> math_001.Value
        fresnel.links.new(reroute_015.outputs[0], math_001.inputs[0])
        #reroute_018.Output -> group_output.Fresnel
        fresnel.links.new(reroute_018.outputs[0], group_output.inputs[0])
        #reroute_001.Output -> bump_001.Normal
        fresnel.links.new(reroute_001.outputs[0], bump_001.inputs[3])
        #reroute_003.Output -> mix.A
        fresnel.links.new(reroute_003.outputs[0], mix.inputs[6])
        #reroute_009.Output -> layer_weight_001.Normal
        fresnel.links.new(reroute_009.outputs[0], layer_weight_001.inputs[1])
        #reroute_025.Output -> mix.Factor
        fresnel.links.new(reroute_025.outputs[0], mix.inputs[0])
        #reroute.Output -> layer_weight.Normal
        fresnel.links.new(reroute.outputs[0], layer_weight.inputs[1])
        #reroute_019.Output -> group_output.Metallic Fresnel
        fresnel.links.new(reroute_019.outputs[0], group_output.inputs[2])
        #reroute_006.Output -> layer_weight_001.Blend
        fresnel.links.new(reroute_006.outputs[0], layer_weight_001.inputs[0])
        #group_input.Normal -> reroute.Input
        fresnel.links.new(group_input.outputs[3], reroute.inputs[0])
        #reroute.Output -> reroute_001.Input
        fresnel.links.new(reroute.outputs[0], reroute_001.inputs[0])
        #bump_001.Normal -> reroute_002.Input
        fresnel.links.new(bump_001.outputs[0], reroute_002.inputs[0])
        #reroute_002.Output -> reroute_003.Input
        fresnel.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
        #geometry_001.Incoming -> reroute_004.Input
        fresnel.links.new(geometry_001.outputs[4], reroute_004.inputs[0])
        #reroute_004.Output -> reroute_005.Input
        fresnel.links.new(reroute_004.outputs[0], reroute_005.inputs[0])
        #reroute_011.Output -> reroute_006.Input
        fresnel.links.new(reroute_011.outputs[0], reroute_006.inputs[0])
        #mix.Result -> reroute_008.Input
        fresnel.links.new(mix.outputs[2], reroute_008.inputs[0])
        #reroute_008.Output -> reroute_009.Input
        fresnel.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
        #reroute_010.Output -> reroute_007.Input
        fresnel.links.new(reroute_010.outputs[0], reroute_007.inputs[0])
        #group_input.Fac -> reroute_010.Input
        fresnel.links.new(group_input.outputs[1], reroute_010.inputs[0])
        #rgb_curves.Color -> reroute_011.Input
        fresnel.links.new(rgb_curves.outputs[0], reroute_011.inputs[0])
        #layer_weight_001.Fresnel -> reroute_012.Input
        fresnel.links.new(layer_weight_001.outputs[0], reroute_012.inputs[0])
        #reroute_014.Output -> reroute_013.Input
        fresnel.links.new(reroute_014.outputs[0], reroute_013.inputs[0])
        #layer_weight.Facing -> reroute_014.Input
        fresnel.links.new(layer_weight.outputs[1], reroute_014.inputs[0])
        #reroute_012.Output -> reroute_015.Input
        fresnel.links.new(reroute_012.outputs[0], reroute_015.inputs[0])
        #reroute_012.Output -> reroute_016.Input
        fresnel.links.new(reroute_012.outputs[0], reroute_016.inputs[0])
        #reroute_016.Output -> reroute_017.Input
        fresnel.links.new(reroute_016.outputs[0], reroute_017.inputs[0])
        #reroute_017.Output -> reroute_018.Input
        fresnel.links.new(reroute_017.outputs[0], reroute_018.inputs[0])
        #reroute_021.Output -> reroute_019.Input
        fresnel.links.new(reroute_021.outputs[0], reroute_019.inputs[0])
        #reroute_022.Output -> reroute_020.Input
        fresnel.links.new(reroute_022.outputs[0], reroute_020.inputs[0])
        #math_001.Value -> reroute_021.Input
        fresnel.links.new(math_001.outputs[0], reroute_021.inputs[0])
        #math.Value -> reroute_022.Input
        fresnel.links.new(math.outputs[0], reroute_022.inputs[0])
        #group_input.Roughness -> reroute_024.Input
        fresnel.links.new(group_input.outputs[0], reroute_024.inputs[0])
        #reroute_024.Output -> reroute_025.Input
        fresnel.links.new(reroute_024.outputs[0], reroute_025.inputs[0])
        return fresnel

    fresnel = fresnel_node_group()

    #initialize Reflection.001 node group
    def reflection_001_node_group():

        reflection_001 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Reflection.001")

        reflection_001.color_tag = 'NONE'
        reflection_001.description = ""
        reflection_001.default_group_node_width = 140
        

        #reflection_001 interface
        #Socket Shader
        shader_socket = reflection_001.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
        shader_socket.attribute_domain = 'POINT'

        #Socket Color
        color_socket = reflection_001.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
        color_socket.default_value = (0.0, 0.0, 0.0, 0.0)
        color_socket.attribute_domain = 'POINT'

        #Socket Shader
        shader_socket_1 = reflection_001.interface.new_socket(name = "Shader", in_out='INPUT', socket_type = 'NodeSocketShader')
        shader_socket_1.attribute_domain = 'POINT'

        #Socket Roughness
        roughness_socket_1 = reflection_001.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        roughness_socket_1.default_value = 0.10000000149011612
        roughness_socket_1.min_value = 0.0
        roughness_socket_1.max_value = 1.0
        roughness_socket_1.subtype = 'FACTOR'
        roughness_socket_1.attribute_domain = 'POINT'

        #Socket Reflection Color
        reflection_color_socket = reflection_001.interface.new_socket(name = "Reflection Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        reflection_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)
        reflection_color_socket.attribute_domain = 'POINT'

        #Socket Reflection Factor
        reflection_factor_socket = reflection_001.interface.new_socket(name = "Reflection Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
        reflection_factor_socket.default_value = 0.5
        reflection_factor_socket.min_value = 0.0
        reflection_factor_socket.max_value = 1.0
        reflection_factor_socket.subtype = 'FACTOR'
        reflection_factor_socket.attribute_domain = 'POINT'

        #Socket Normal
        normal_socket_1 = reflection_001.interface.new_socket(name = "Normal", in_out='INPUT', socket_type = 'NodeSocketVector')
        normal_socket_1.default_value = (0.0, 0.0, 0.0)
        normal_socket_1.min_value = -1.0
        normal_socket_1.max_value = 1.0
        normal_socket_1.subtype = 'NONE'
        normal_socket_1.attribute_domain = 'POINT'
        normal_socket_1.hide_value = True


        #initialize reflection_001 nodes
        #node REFLECTION NODE
        reflection_node = reflection_001.nodes.new("NodeFrame")
        reflection_node.label = "REFLECTION NODE"
        reflection_node.name = "REFLECTION NODE"
        reflection_node.use_custom_color = True
        reflection_node.color = (0.6079999804496765, 0.5312550067901611, 0.4991360008716583)
        reflection_node.label_size = 15
        reflection_node.shrink = True

        #node Author
        author_1 = reflection_001.nodes.new("NodeFrame")
        author_1.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_1.name = "Author"
        author_1.use_custom_color = True
        author_1.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_1.label_size = 16
        author_1.shrink = True

        #node Mix Shader
        mix_shader = reflection_001.nodes.new("ShaderNodeMixShader")
        mix_shader.name = "Mix Shader"

        #node Reroute.003
        reroute_003_1 = reflection_001.nodes.new("NodeReroute")
        reroute_003_1.name = "Reroute.003"
        reroute_003_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.004
        reroute_004_1 = reflection_001.nodes.new("NodeReroute")
        reroute_004_1.name = "Reroute.004"
        reroute_004_1.socket_idname = "NodeSocketFloatFactor"
        #node Glossy BSDF
        glossy_bsdf = reflection_001.nodes.new("ShaderNodeBsdfAnisotropic")
        glossy_bsdf.name = "Glossy BSDF"
        glossy_bsdf.distribution = 'GGX'
        #Anisotropy
        glossy_bsdf.inputs[2].default_value = 0.0
        #Rotation
        glossy_bsdf.inputs[3].default_value = 0.0
        #Tangent
        glossy_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)

        #node Reroute.010
        reroute_010_1 = reflection_001.nodes.new("NodeReroute")
        reroute_010_1.name = "Reroute.010"
        reroute_010_1.socket_idname = "NodeSocketShader"
        #node Reroute.005
        reroute_005_1 = reflection_001.nodes.new("NodeReroute")
        reroute_005_1.name = "Reroute.005"
        reroute_005_1.socket_idname = "NodeSocketShader"
        #node Reroute.001
        reroute_001_1 = reflection_001.nodes.new("NodeReroute")
        reroute_001_1.name = "Reroute.001"
        reroute_001_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.011
        reroute_011_1 = reflection_001.nodes.new("NodeReroute")
        reroute_011_1.name = "Reroute.011"
        reroute_011_1.socket_idname = "NodeSocketFloat"
        #node Math.001
        math_001_1 = reflection_001.nodes.new("ShaderNodeMath")
        math_001_1.name = "Math.001"
        math_001_1.operation = 'POWER'
        math_001_1.use_clamp = False
        #Value_001
        math_001_1.inputs[1].default_value = 0.5

        #node Math
        math_1 = reflection_001.nodes.new("ShaderNodeMath")
        math_1.name = "Math"
        math_1.operation = 'POWER'
        math_1.use_clamp = False
        #Value_001
        math_1.inputs[1].default_value = 2.0

        #node Reroute.018
        reroute_018_1 = reflection_001.nodes.new("NodeReroute")
        reroute_018_1.name = "Reroute.018"
        reroute_018_1.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_1 = reflection_001.nodes.new("NodeReroute")
        reroute_013_1.name = "Reroute.013"
        reroute_013_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.008
        reroute_008_1 = reflection_001.nodes.new("NodeReroute")
        reroute_008_1.name = "Reroute.008"
        reroute_008_1.socket_idname = "NodeSocketShader"
        #node Reroute.007
        reroute_007_1 = reflection_001.nodes.new("NodeReroute")
        reroute_007_1.name = "Reroute.007"
        reroute_007_1.socket_idname = "NodeSocketShader"
        #node Reroute.024
        reroute_024_1 = reflection_001.nodes.new("NodeReroute")
        reroute_024_1.name = "Reroute.024"
        reroute_024_1.socket_idname = "NodeSocketColor"
        #node Reroute.027
        reroute_027 = reflection_001.nodes.new("NodeReroute")
        reroute_027.name = "Reroute.027"
        reroute_027.socket_idname = "NodeSocketVector"
        #node Reroute.026
        reroute_026 = reflection_001.nodes.new("NodeReroute")
        reroute_026.name = "Reroute.026"
        reroute_026.socket_idname = "NodeSocketColor"
        #node Reroute.028
        reroute_028 = reflection_001.nodes.new("NodeReroute")
        reroute_028.name = "Reroute.028"
        reroute_028.socket_idname = "NodeSocketVector"
        #node Reroute.012
        reroute_012_1 = reflection_001.nodes.new("NodeReroute")
        reroute_012_1.name = "Reroute.012"
        reroute_012_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.022
        reroute_022_1 = reflection_001.nodes.new("NodeReroute")
        reroute_022_1.name = "Reroute.022"
        reroute_022_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.025
        reroute_025_1 = reflection_001.nodes.new("NodeReroute")
        reroute_025_1.name = "Reroute.025"
        reroute_025_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.014
        reroute_014_1 = reflection_001.nodes.new("NodeReroute")
        reroute_014_1.name = "Reroute.014"
        reroute_014_1.socket_idname = "NodeSocketFloat"
        #node Reroute.019
        reroute_019_1 = reflection_001.nodes.new("NodeReroute")
        reroute_019_1.name = "Reroute.019"
        reroute_019_1.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_1 = reflection_001.nodes.new("NodeReroute")
        reroute_020_1.name = "Reroute.020"
        reroute_020_1.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021_1 = reflection_001.nodes.new("NodeReroute")
        reroute_021_1.name = "Reroute.021"
        reroute_021_1.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_1 = reflection_001.nodes.new("NodeReroute")
        reroute_016_1.name = "Reroute.016"
        reroute_016_1.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_1 = reflection_001.nodes.new("NodeReroute")
        reroute_006_1.name = "Reroute.006"
        reroute_006_1.socket_idname = "NodeSocketShader"
        #node Reroute.009
        reroute_009_1 = reflection_001.nodes.new("NodeReroute")
        reroute_009_1.name = "Reroute.009"
        reroute_009_1.socket_idname = "NodeSocketShader"
        #node Reroute.002
        reroute_002_1 = reflection_001.nodes.new("NodeReroute")
        reroute_002_1.name = "Reroute.002"
        reroute_002_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute
        reroute_1 = reflection_001.nodes.new("NodeReroute")
        reroute_1.name = "Reroute"
        reroute_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.023
        reroute_023 = reflection_001.nodes.new("NodeReroute")
        reroute_023.name = "Reroute.023"
        reroute_023.socket_idname = "NodeSocketVector"
        #node Group Input
        group_input_1 = reflection_001.nodes.new("NodeGroupInput")
        group_input_1.name = "Group Input"
        group_input_1.use_custom_color = True
        group_input_1.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)

        #node Group Output
        group_output_1 = reflection_001.nodes.new("NodeGroupOutput")
        group_output_1.name = "Group Output"
        group_output_1.use_custom_color = True
        group_output_1.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_1.is_active_output = True
        group_output_1.inputs[2].hide = True

        #node Fresnel
        fresnel_1 = reflection_001.nodes.new("ShaderNodeGroup")
        fresnel_1.label = "Fresnel"
        fresnel_1.name = "Fresnel"
        fresnel_1.use_custom_color = True
        fresnel_1.color = (0.22681938111782074, 0.6080002188682556, 0.6080002188682556)
        fresnel_1.node_tree = fresnel
        #Input_21
        fresnel_1.inputs[2].default_value = 0.5


        #Set locations
        reflection_node.location = (-900.0, 168.08560180664062)
        author_1.location = (-106.255859375, -84.7783203125)
        mix_shader.location = (-190.0, 0.0)
        reroute_003_1.location = (-219.07110595703125, -35.556884765625)
        reroute_004_1.location = (-218.2032470703125, -59.943817138671875)
        glossy_bsdf.location = (-400.0, -240.0)
        reroute_010_1.location = (-220.0, -275.85638427734375)
        reroute_005_1.location = (-240.74749755859375, 34.95843505859375)
        reroute_001_1.location = (-29.6226806640625, 34.95843505859375)
        reroute_011_1.location = (-440.64862060546875, -31.6875)
        math_001_1.location = (-599.6605834960938, 4.207489013671875)
        math_1.location = (-779.8387451171875, 4.794769287109375)
        reroute_018_1.location = (-619.2470703125, -30.469757080078125)
        reroute_013_1.location = (-799.65234375, -109.7430419921875)
        reroute_008_1.location = (-852.2476196289062, -30.424896240234375)
        reroute_007_1.location = (-853.4042358398438, 39.713409423828125)
        reroute_024_1.location = (-839.0414428710938, -74.30999755859375)
        reroute_027.location = (-857.9572143554688, -118.24688720703125)
        reroute_026.location = (-839.0414428710938, -329.4621276855469)
        reroute_028.location = (-859.474609375, -373.8612060546875)
        reroute_012_1.location = (-819.7618408203125, -96.90118408203125)
        reroute_022_1.location = (-819.0414428710938, -156.847900390625)
        reroute_025_1.location = (-798.9884643554688, -53.271514892578125)
        reroute_014_1.location = (-439.40869140625, -352.31982421875)
        reroute_019_1.location = (-420.0, 20.0)
        reroute_020_1.location = (-620.0, 20.0)
        reroute_021_1.location = (-619.2914428710938, -111.15814208984375)
        reroute_016_1.location = (-420.43048095703125, -133.4442138671875)
        reroute_006_1.location = (-239.45269775390625, -82.19021606445312)
        reroute_009_1.location = (-218.2249755859375, -103.39308166503906)
        reroute_002_1.location = (-220.74755859375, 34.95843505859375)
        reroute_1.location = (-30.280029296875, -56.432342529296875)
        reroute_023.location = (-858.5352172851562, -198.6958465576172)
        group_input_1.location = (-1012.6566772460938, 4.75506591796875)
        group_output_1.location = (-8.87506103515625, 0.0)
        fresnel_1.location = (-400.0, 0.0)

        #Set dimensions
        reflection_node.width, reflection_node.height = 337.6953125, 109.02239990234375
        author_1.width, author_1.height = 290.4298095703125, 30.0
        mix_shader.width, mix_shader.height = 140.0, 100.0
        reroute_003_1.width, reroute_003_1.height = 16.0, 100.0
        reroute_004_1.width, reroute_004_1.height = 16.0, 100.0
        glossy_bsdf.width, glossy_bsdf.height = 150.0, 100.0
        reroute_010_1.width, reroute_010_1.height = 16.0, 100.0
        reroute_005_1.width, reroute_005_1.height = 16.0, 100.0
        reroute_001_1.width, reroute_001_1.height = 16.0, 100.0
        reroute_011_1.width, reroute_011_1.height = 16.0, 100.0
        math_001_1.width, math_001_1.height = 140.0, 100.0
        math_1.width, math_1.height = 140.0, 100.0
        reroute_018_1.width, reroute_018_1.height = 16.0, 100.0
        reroute_013_1.width, reroute_013_1.height = 16.0, 100.0
        reroute_008_1.width, reroute_008_1.height = 16.0, 100.0
        reroute_007_1.width, reroute_007_1.height = 16.0, 100.0
        reroute_024_1.width, reroute_024_1.height = 16.0, 100.0
        reroute_027.width, reroute_027.height = 16.0, 100.0
        reroute_026.width, reroute_026.height = 16.0, 100.0
        reroute_028.width, reroute_028.height = 16.0, 100.0
        reroute_012_1.width, reroute_012_1.height = 16.0, 100.0
        reroute_022_1.width, reroute_022_1.height = 16.0, 100.0
        reroute_025_1.width, reroute_025_1.height = 16.0, 100.0
        reroute_014_1.width, reroute_014_1.height = 16.0, 100.0
        reroute_019_1.width, reroute_019_1.height = 16.0, 100.0
        reroute_020_1.width, reroute_020_1.height = 16.0, 100.0
        reroute_021_1.width, reroute_021_1.height = 16.0, 100.0
        reroute_016_1.width, reroute_016_1.height = 16.0, 100.0
        reroute_006_1.width, reroute_006_1.height = 16.0, 100.0
        reroute_009_1.width, reroute_009_1.height = 16.0, 100.0
        reroute_002_1.width, reroute_002_1.height = 16.0, 100.0
        reroute_1.width, reroute_1.height = 16.0, 100.0
        reroute_023.width, reroute_023.height = 16.0, 100.0
        group_input_1.width, group_input_1.height = 140.0, 100.0
        group_output_1.width, group_output_1.height = 140.0, 100.0
        fresnel_1.width, fresnel_1.height = 140.0, 100.0

        #initialize reflection_001 links
        #reroute_006_1.Output -> mix_shader.Shader
        reflection_001.links.new(reroute_006_1.outputs[0], mix_shader.inputs[1])
        #reroute_009_1.Output -> mix_shader.Shader
        reflection_001.links.new(reroute_009_1.outputs[0], mix_shader.inputs[2])
        #reroute_013_1.Output -> math_1.Value
        reflection_001.links.new(reroute_013_1.outputs[0], math_1.inputs[0])
        #mix_shader.Shader -> group_output_1.Shader
        reflection_001.links.new(mix_shader.outputs[0], group_output_1.inputs[0])
        #reroute_028.Output -> glossy_bsdf.Normal
        reflection_001.links.new(reroute_028.outputs[0], glossy_bsdf.inputs[4])
        #reroute_1.Output -> group_output_1.Color
        reflection_001.links.new(reroute_1.outputs[0], group_output_1.inputs[1])
        #reroute_026.Output -> glossy_bsdf.Color
        reflection_001.links.new(reroute_026.outputs[0], glossy_bsdf.inputs[0])
        #reroute_014_1.Output -> glossy_bsdf.Roughness
        reflection_001.links.new(reroute_014_1.outputs[0], glossy_bsdf.inputs[1])
        #reroute_001_1.Output -> reroute_1.Input
        reflection_001.links.new(reroute_001_1.outputs[0], reroute_1.inputs[0])
        #reroute_002_1.Output -> reroute_001_1.Input
        reflection_001.links.new(reroute_002_1.outputs[0], reroute_001_1.inputs[0])
        #reroute_003_1.Output -> reroute_002_1.Input
        reflection_001.links.new(reroute_003_1.outputs[0], reroute_002_1.inputs[0])
        #reroute_004_1.Output -> mix_shader.Fac
        reflection_001.links.new(reroute_004_1.outputs[0], mix_shader.inputs[0])
        #reroute_003_1.Output -> reroute_004_1.Input
        reflection_001.links.new(reroute_003_1.outputs[0], reroute_004_1.inputs[0])
        #reroute_007_1.Output -> reroute_005_1.Input
        reflection_001.links.new(reroute_007_1.outputs[0], reroute_005_1.inputs[0])
        #reroute_005_1.Output -> reroute_006_1.Input
        reflection_001.links.new(reroute_005_1.outputs[0], reroute_006_1.inputs[0])
        #reroute_008_1.Output -> reroute_007_1.Input
        reflection_001.links.new(reroute_008_1.outputs[0], reroute_007_1.inputs[0])
        #group_input_1.Shader -> reroute_008_1.Input
        reflection_001.links.new(group_input_1.outputs[0], reroute_008_1.inputs[0])
        #reroute_010_1.Output -> reroute_009_1.Input
        reflection_001.links.new(reroute_010_1.outputs[0], reroute_009_1.inputs[0])
        #glossy_bsdf.BSDF -> reroute_010_1.Input
        reflection_001.links.new(glossy_bsdf.outputs[0], reroute_010_1.inputs[0])
        #math_001_1.Value -> reroute_011_1.Input
        reflection_001.links.new(math_001_1.outputs[0], reroute_011_1.inputs[0])
        #reroute_011_1.Output -> reroute_014_1.Input
        reflection_001.links.new(reroute_011_1.outputs[0], reroute_014_1.inputs[0])
        #reroute_019_1.Output -> reroute_016_1.Input
        reflection_001.links.new(reroute_019_1.outputs[0], reroute_016_1.inputs[0])
        #math_1.Value -> reroute_018_1.Input
        reflection_001.links.new(math_1.outputs[0], reroute_018_1.inputs[0])
        #reroute_020_1.Output -> reroute_019_1.Input
        reflection_001.links.new(reroute_020_1.outputs[0], reroute_019_1.inputs[0])
        #reroute_018_1.Output -> reroute_020_1.Input
        reflection_001.links.new(reroute_018_1.outputs[0], reroute_020_1.inputs[0])
        #reroute_021_1.Output -> math_001_1.Value
        reflection_001.links.new(reroute_021_1.outputs[0], math_001_1.inputs[0])
        #reroute_018_1.Output -> reroute_021_1.Input
        reflection_001.links.new(reroute_018_1.outputs[0], reroute_021_1.inputs[0])
        #reroute_012_1.Output -> reroute_022_1.Input
        reflection_001.links.new(reroute_012_1.outputs[0], reroute_022_1.inputs[0])
        #reroute_027.Output -> reroute_023.Input
        reflection_001.links.new(reroute_027.outputs[0], reroute_023.inputs[0])
        #group_input_1.Reflection Color -> reroute_024_1.Input
        reflection_001.links.new(group_input_1.outputs[2], reroute_024_1.inputs[0])
        #group_input_1.Roughness -> reroute_025_1.Input
        reflection_001.links.new(group_input_1.outputs[1], reroute_025_1.inputs[0])
        #reroute_024_1.Output -> reroute_026.Input
        reflection_001.links.new(reroute_024_1.outputs[0], reroute_026.inputs[0])
        #group_input_1.Normal -> reroute_027.Input
        reflection_001.links.new(group_input_1.outputs[4], reroute_027.inputs[0])
        #reroute_023.Output -> reroute_028.Input
        reflection_001.links.new(reroute_023.outputs[0], reroute_028.inputs[0])
        #group_input_1.Reflection Factor -> reroute_012_1.Input
        reflection_001.links.new(group_input_1.outputs[3], reroute_012_1.inputs[0])
        #reroute_025_1.Output -> reroute_013_1.Input
        reflection_001.links.new(reroute_025_1.outputs[0], reroute_013_1.inputs[0])
        #reroute_023.Output -> fresnel_1.Normal
        reflection_001.links.new(reroute_023.outputs[0], fresnel_1.inputs[3])
        #reroute_022_1.Output -> fresnel_1.Fac
        reflection_001.links.new(reroute_022_1.outputs[0], fresnel_1.inputs[1])
        #reroute_016_1.Output -> fresnel_1.Roughness
        reflection_001.links.new(reroute_016_1.outputs[0], fresnel_1.inputs[0])
        #fresnel_1.Fresnel -> reroute_003_1.Input
        reflection_001.links.new(fresnel_1.outputs[0], reroute_003_1.inputs[0])
        return reflection_001

    reflection_001 = reflection_001_node_group()

    #initialize Color Variation Ver. 3 node group
    def color_variation_ver__3_node_group():

        color_variation_ver__3 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Color Variation Ver. 3")

        color_variation_ver__3.color_tag = 'NONE'
        color_variation_ver__3.description = ""
        color_variation_ver__3.default_group_node_width = 140
        

        #color_variation_ver__3 interface
        #Socket Color
        color_socket_1 = color_variation_ver__3.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
        color_socket_1.default_value = (0.0, 0.0, 0.0, 0.0)
        color_socket_1.attribute_domain = 'POINT'

        #Socket Input Color
        input_color_socket = color_variation_ver__3.interface.new_socket(name = "Input Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        input_color_socket.default_value = (0.5, 0.5, 0.5, 1.0)
        input_color_socket.attribute_domain = 'POINT'

        #Socket COLOR VARIATION
        color_variation_socket = color_variation_ver__3.interface.new_socket(name = "COLOR VARIATION", in_out='INPUT', socket_type = 'NodeSocketFloat')
        color_variation_socket.default_value = 0.0
        color_variation_socket.min_value = -3.4028234663852886e+38
        color_variation_socket.max_value = 3.4028234663852886e+38
        color_variation_socket.subtype = 'FACTOR'
        color_variation_socket.attribute_domain = 'POINT'
        color_variation_socket.hide_value = True

        #Socket   Color Variation Scale
        __color_variation_scale_socket = color_variation_ver__3.interface.new_socket(name = "  Color Variation Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_variation_scale_socket.default_value = 0.5
        __color_variation_scale_socket.min_value = 0.05000000074505806
        __color_variation_scale_socket.max_value = 10.0
        __color_variation_scale_socket.subtype = 'FACTOR'
        __color_variation_scale_socket.attribute_domain = 'POINT'

        #Socket   Color Variation Distortion
        __color_variation_distortion_socket = color_variation_ver__3.interface.new_socket(name = "  Color Variation Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_variation_distortion_socket.default_value = 0.0
        __color_variation_distortion_socket.min_value = 0.0
        __color_variation_distortion_socket.max_value = 3.0
        __color_variation_distortion_socket.subtype = 'FACTOR'
        __color_variation_distortion_socket.attribute_domain = 'POINT'

        #Socket   Random Color Var
        __random_color_var_socket = color_variation_ver__3.interface.new_socket(name = "  Random Color Var", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __random_color_var_socket.default_value = 1.0
        __random_color_var_socket.min_value = 0.0
        __random_color_var_socket.max_value = 1.0
        __random_color_var_socket.subtype = 'FACTOR'
        __random_color_var_socket.attribute_domain = 'POINT'

        #Socket COLOR ADJUSTMENTS
        color_adjustments_socket = color_variation_ver__3.interface.new_socket(name = "COLOR ADJUSTMENTS", in_out='INPUT', socket_type = 'NodeSocketFloat')
        color_adjustments_socket.default_value = 0.0
        color_adjustments_socket.min_value = -3.4028234663852886e+38
        color_adjustments_socket.max_value = 3.4028234663852886e+38
        color_adjustments_socket.subtype = 'NONE'
        color_adjustments_socket.attribute_domain = 'POINT'
        color_adjustments_socket.hide_value = True

        #Socket   Unpaint
        __unpaint_socket = color_variation_ver__3.interface.new_socket(name = "  Unpaint", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __unpaint_socket.default_value = 0.0
        __unpaint_socket.min_value = 0.0
        __unpaint_socket.max_value = 1.0
        __unpaint_socket.subtype = 'FACTOR'
        __unpaint_socket.attribute_domain = 'POINT'

        #Socket   Color Inverter
        __color_inverter_socket = color_variation_ver__3.interface.new_socket(name = "  Color Inverter", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_inverter_socket.default_value = 0.0
        __color_inverter_socket.min_value = 0.0
        __color_inverter_socket.max_value = 1.0
        __color_inverter_socket.subtype = 'FACTOR'
        __color_inverter_socket.attribute_domain = 'POINT'

        #Socket   Contrast
        __contrast_socket = color_variation_ver__3.interface.new_socket(name = "  Contrast", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __contrast_socket.default_value = 0.0
        __contrast_socket.min_value = -100.0
        __contrast_socket.max_value = 100.0
        __contrast_socket.subtype = 'NONE'
        __contrast_socket.attribute_domain = 'POINT'

        #Socket   Gamma
        __gamma_socket = color_variation_ver__3.interface.new_socket(name = "  Gamma", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __gamma_socket.default_value = 1.0
        __gamma_socket.min_value = 0.0010000000474974513
        __gamma_socket.max_value = 10.0
        __gamma_socket.attribute_domain = 'POINT'

        #Socket   Hue / Sat Value
        __hue___sat_value_socket = color_variation_ver__3.interface.new_socket(name = "  Hue / Sat Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __hue___sat_value_socket.default_value = 2.0
        __hue___sat_value_socket.min_value = 0.0
        __hue___sat_value_socket.max_value = 2.0
        __hue___sat_value_socket.subtype = 'NONE'
        __hue___sat_value_socket.attribute_domain = 'POINT'

        #Socket     Hue
        ____hue_socket = color_variation_ver__3.interface.new_socket(name = "    Hue", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____hue_socket.default_value = 0.49999991059303284
        ____hue_socket.min_value = 0.0
        ____hue_socket.max_value = 1.0
        ____hue_socket.subtype = 'NONE'
        ____hue_socket.attribute_domain = 'POINT'

        #Socket     Saturation
        ____saturation_socket = color_variation_ver__3.interface.new_socket(name = "    Saturation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____saturation_socket.default_value = 1.0
        ____saturation_socket.min_value = 0.0
        ____saturation_socket.max_value = 2.0
        ____saturation_socket.subtype = 'NONE'
        ____saturation_socket.attribute_domain = 'POINT'

        #Socket BRIGHTNESS
        brightness_socket = color_variation_ver__3.interface.new_socket(name = "BRIGHTNESS", in_out='INPUT', socket_type = 'NodeSocketFloat')
        brightness_socket.default_value = 0.0
        brightness_socket.min_value = -3.4028234663852886e+38
        brightness_socket.max_value = 3.4028234663852886e+38
        brightness_socket.subtype = 'NONE'
        brightness_socket.attribute_domain = 'POINT'
        brightness_socket.hide_value = True

        #Socket   Glowing Level
        __glowing_level_socket = color_variation_ver__3.interface.new_socket(name = "  Glowing Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __glowing_level_socket.default_value = 1.0
        __glowing_level_socket.min_value = -3.4028234663852886e+38
        __glowing_level_socket.max_value = 3.4028234663852886e+38
        __glowing_level_socket.subtype = 'NONE'
        __glowing_level_socket.attribute_domain = 'POINT'

        #Socket   Brightness
        __brightness_socket = color_variation_ver__3.interface.new_socket(name = "  Brightness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __brightness_socket.default_value = 0.0
        __brightness_socket.min_value = -100.0
        __brightness_socket.max_value = 100.0
        __brightness_socket.subtype = 'NONE'
        __brightness_socket.attribute_domain = 'POINT'

        #Socket   Dark / Bright Threshold
        __dark___bright_threshold_socket = color_variation_ver__3.interface.new_socket(name = "  Dark / Bright Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __dark___bright_threshold_socket.default_value = 0.0
        __dark___bright_threshold_socket.min_value = -10000.0
        __dark___bright_threshold_socket.max_value = 10000.0
        __dark___bright_threshold_socket.subtype = 'NONE'
        __dark___bright_threshold_socket.attribute_domain = 'POINT'

        #Socket     Dark Spot Intensity
        ____dark_spot_intensity_socket = color_variation_ver__3.interface.new_socket(name = "    Dark Spot Intensity", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____dark_spot_intensity_socket.default_value = 0.5
        ____dark_spot_intensity_socket.min_value = 0.0
        ____dark_spot_intensity_socket.max_value = 1.0
        ____dark_spot_intensity_socket.subtype = 'FACTOR'
        ____dark_spot_intensity_socket.attribute_domain = 'POINT'

        #Socket     Bright Spot Intensity
        ____bright_spot_intensity_socket = color_variation_ver__3.interface.new_socket(name = "    Bright Spot Intensity", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____bright_spot_intensity_socket.default_value = 0.5
        ____bright_spot_intensity_socket.min_value = 0.0
        ____bright_spot_intensity_socket.max_value = 1.0
        ____bright_spot_intensity_socket.subtype = 'FACTOR'
        ____bright_spot_intensity_socket.attribute_domain = 'POINT'

        #Socket   Roughness
        __roughness_socket = color_variation_ver__3.interface.new_socket(name = "  Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __roughness_socket.default_value = 0.5
        __roughness_socket.min_value = 0.0
        __roughness_socket.max_value = 1.0
        __roughness_socket.subtype = 'FACTOR'
        __roughness_socket.attribute_domain = 'POINT'


        #initialize color_variation_ver__3 nodes
        #node Node Group Description
        node_group_description = color_variation_ver__3.nodes.new("NodeFrame")
        node_group_description.label = "COLOR VARIATIOON NODE"
        node_group_description.name = "Node Group Description"
        node_group_description.use_custom_color = True
        node_group_description.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        node_group_description.label_size = 15
        node_group_description.shrink = True

        #node Author.001
        author_001 = color_variation_ver__3.nodes.new("NodeFrame")
        author_001.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_001.name = "Author.001"
        author_001.use_custom_color = True
        author_001.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_001.label_size = 16
        author_001.shrink = True

        #node Hue Saturation Value
        hue_saturation_value = color_variation_ver__3.nodes.new("ShaderNodeHueSaturation")
        hue_saturation_value.name = "Hue Saturation Value"
        hue_saturation_value.inputs[0].hide = True
        #Hue
        hue_saturation_value.inputs[0].default_value = 0.4999999701976776

        #node Map Range.005
        map_range_005 = color_variation_ver__3.nodes.new("ShaderNodeMapRange")
        map_range_005.name = "Map Range.005"
        map_range_005.clamp = True
        map_range_005.data_type = 'FLOAT'
        map_range_005.interpolation_type = 'LINEAR'
        map_range_005.inputs[1].hide = True
        map_range_005.inputs[2].hide = True
        map_range_005.inputs[3].hide = True
        map_range_005.inputs[4].hide = True
        map_range_005.inputs[5].hide = True
        map_range_005.inputs[6].hide = True
        map_range_005.inputs[7].hide = True
        map_range_005.inputs[8].hide = True
        map_range_005.inputs[9].hide = True
        map_range_005.inputs[10].hide = True
        map_range_005.inputs[11].hide = True
        map_range_005.outputs[1].hide = True
        #From Min
        map_range_005.inputs[1].default_value = 0.0
        #From Max
        map_range_005.inputs[2].default_value = 1.0
        #To Min
        map_range_005.inputs[3].default_value = 1.0
        #To Max
        map_range_005.inputs[4].default_value = 2.0

        #node Reroute.043
        reroute_043 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_043.name = "Reroute.043"
        reroute_043.socket_idname = "NodeSocketFloat"
        #node Reroute.051
        reroute_051 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_051.name = "Reroute.051"
        reroute_051.socket_idname = "NodeSocketFloat"
        #node Map Range.001
        map_range_001 = color_variation_ver__3.nodes.new("ShaderNodeMapRange")
        map_range_001.name = "Map Range.001"
        map_range_001.clamp = True
        map_range_001.data_type = 'FLOAT'
        map_range_001.interpolation_type = 'LINEAR'
        map_range_001.inputs[1].hide = True
        map_range_001.inputs[2].hide = True
        map_range_001.inputs[4].hide = True
        map_range_001.inputs[5].hide = True
        map_range_001.inputs[6].hide = True
        map_range_001.inputs[7].hide = True
        map_range_001.inputs[8].hide = True
        map_range_001.inputs[9].hide = True
        map_range_001.inputs[10].hide = True
        map_range_001.inputs[11].hide = True
        map_range_001.outputs[1].hide = True
        #From Min
        map_range_001.inputs[1].default_value = 0.0
        #From Max
        map_range_001.inputs[2].default_value = 1.0
        #To Max
        map_range_001.inputs[4].default_value = 1.0

        #node Reroute.046
        reroute_046 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_046.name = "Reroute.046"
        reroute_046.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.060
        reroute_060 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_060.name = "Reroute.060"
        reroute_060.socket_idname = "NodeSocketFloat"
        #node Reroute.059
        reroute_059 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_059.name = "Reroute.059"
        reroute_059.socket_idname = "NodeSocketFloat"
        #node Reroute.062
        reroute_062 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_062.name = "Reroute.062"
        reroute_062.socket_idname = "NodeSocketFloat"
        #node Reroute.061
        reroute_061 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_061.name = "Reroute.061"
        reroute_061.socket_idname = "NodeSocketFloat"
        #node Separate RGB
        separate_rgb = color_variation_ver__3.nodes.new("ShaderNodeSeparateColor")
        separate_rgb.name = "Separate RGB"
        separate_rgb.mode = 'RGB'
        separate_rgb.outputs[2].hide = True

        #node Map Range.003
        map_range_003 = color_variation_ver__3.nodes.new("ShaderNodeMapRange")
        map_range_003.name = "Map Range.003"
        map_range_003.clamp = True
        map_range_003.data_type = 'FLOAT'
        map_range_003.interpolation_type = 'LINEAR'
        map_range_003.inputs[1].hide = True
        map_range_003.inputs[2].hide = True
        map_range_003.inputs[3].hide = True
        map_range_003.inputs[4].hide = True
        map_range_003.inputs[5].hide = True
        map_range_003.inputs[6].hide = True
        map_range_003.inputs[7].hide = True
        map_range_003.inputs[8].hide = True
        map_range_003.inputs[9].hide = True
        map_range_003.inputs[10].hide = True
        map_range_003.inputs[11].hide = True
        map_range_003.outputs[1].hide = True
        #From Min
        map_range_003.inputs[1].default_value = 0.0
        #From Max
        map_range_003.inputs[2].default_value = 1.0
        #To Min
        map_range_003.inputs[3].default_value = -3.725290298461914e-09
        #To Max
        map_range_003.inputs[4].default_value = 0.15000000596046448

        #node Reroute.074
        reroute_074 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_074.name = "Reroute.074"
        reroute_074.socket_idname = "NodeSocketFloat"
        #node Math
        math_2 = color_variation_ver__3.nodes.new("ShaderNodeMath")
        math_2.label = "Remap Scale"
        math_2.name = "Math"
        math_2.operation = 'MULTIPLY'
        math_2.use_clamp = False
        math_2.inputs[1].hide = True
        math_2.inputs[2].hide = True
        #Value_001
        math_2.inputs[1].default_value = 0.10000000149011612

        #node Reroute.083
        reroute_083 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_083.name = "Reroute.083"
        reroute_083.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.076
        reroute_076 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_076.name = "Reroute.076"
        reroute_076.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.077
        reroute_077 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_077.name = "Reroute.077"
        reroute_077.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.079
        reroute_079 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_079.name = "Reroute.079"
        reroute_079.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.078
        reroute_078 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_078.name = "Reroute.078"
        reroute_078.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.071
        reroute_071 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_071.name = "Reroute.071"
        reroute_071.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.089
        reroute_089 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_089.name = "Reroute.089"
        reroute_089.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.088
        reroute_088 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_088.name = "Reroute.088"
        reroute_088.socket_idname = "NodeSocketFloatFactor"
        #node Noise Texture
        noise_texture = color_variation_ver__3.nodes.new("ShaderNodeTexNoise")
        noise_texture.name = "Noise Texture"
        noise_texture.noise_dimensions = '3D'
        noise_texture.noise_type = 'FBM'
        noise_texture.normalize = True
        noise_texture.inputs[1].hide = True
        noise_texture.inputs[3].hide = True
        noise_texture.outputs[0].hide = True
        #Detail
        noise_texture.inputs[3].default_value = 16.0
        #Lacunarity
        noise_texture.inputs[5].default_value = 2.0

        #node Reroute.073
        reroute_073 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_073.name = "Reroute.073"
        reroute_073.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.070
        reroute_070 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_070.name = "Reroute.070"
        reroute_070.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.072
        reroute_072 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_072.name = "Reroute.072"
        reroute_072.socket_idname = "NodeSocketFloat"
        #node Reroute.069
        reroute_069 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_069.name = "Reroute.069"
        reroute_069.socket_idname = "NodeSocketColor"
        #node Reroute.064
        reroute_064 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_064.name = "Reroute.064"
        reroute_064.socket_idname = "NodeSocketColor"
        #node Reroute.066
        reroute_066 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_066.name = "Reroute.066"
        reroute_066.socket_idname = "NodeSocketFloat"
        #node Texture Coordinate
        texture_coordinate = color_variation_ver__3.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.from_instancer = False
        texture_coordinate.outputs[0].hide = True
        texture_coordinate.outputs[1].hide = True
        texture_coordinate.outputs[2].hide = True
        texture_coordinate.outputs[4].hide = True
        texture_coordinate.outputs[5].hide = True
        texture_coordinate.outputs[6].hide = True

        #node Reroute.082
        reroute_082 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_082.name = "Reroute.082"
        reroute_082.socket_idname = "NodeSocketVector"
        #node Reroute.052
        reroute_052 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_052.name = "Reroute.052"
        reroute_052.socket_idname = "NodeSocketFloat"
        #node Map Range.004
        map_range_004 = color_variation_ver__3.nodes.new("ShaderNodeMapRange")
        map_range_004.name = "Map Range.004"
        map_range_004.clamp = True
        map_range_004.data_type = 'FLOAT'
        map_range_004.interpolation_type = 'LINEAR'
        map_range_004.inputs[1].hide = True
        map_range_004.inputs[2].hide = True
        map_range_004.inputs[3].hide = True
        map_range_004.inputs[4].hide = True
        map_range_004.inputs[5].hide = True
        map_range_004.inputs[6].hide = True
        map_range_004.inputs[7].hide = True
        map_range_004.inputs[8].hide = True
        map_range_004.inputs[9].hide = True
        map_range_004.inputs[10].hide = True
        map_range_004.inputs[11].hide = True
        map_range_004.outputs[1].hide = True
        #From Min
        map_range_004.inputs[1].default_value = 0.0
        #From Max
        map_range_004.inputs[2].default_value = 1.0
        #To Min
        map_range_004.inputs[3].default_value = -3.725290298461914e-09
        #To Max
        map_range_004.inputs[4].default_value = 0.10000000149011612

        #node Reroute.067
        reroute_067 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_067.name = "Reroute.067"
        reroute_067.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.081
        reroute_081 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_081.name = "Reroute.081"
        reroute_081.socket_idname = "NodeSocketVector"
        #node Gamma
        gamma = color_variation_ver__3.nodes.new("ShaderNodeGamma")
        gamma.name = "Gamma"

        #node Bright/Contrast
        bright_contrast = color_variation_ver__3.nodes.new("ShaderNodeBrightContrast")
        bright_contrast.name = "Bright/Contrast"

        #node Reroute.007
        reroute_007_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_007_2.name = "Reroute.007"
        reroute_007_2.socket_idname = "NodeSocketColor"
        #node Reroute.009
        reroute_009_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_009_2.name = "Reroute.009"
        reroute_009_2.socket_idname = "NodeSocketColor"
        #node Reroute.010
        reroute_010_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_010_2.name = "Reroute.010"
        reroute_010_2.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_011_2.name = "Reroute.011"
        reroute_011_2.socket_idname = "NodeSocketFloat"
        #node Reroute.024
        reroute_024_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_024_2.name = "Reroute.024"
        reroute_024_2.socket_idname = "NodeSocketFloat"
        #node Hue Saturation Value.001
        hue_saturation_value_001 = color_variation_ver__3.nodes.new("ShaderNodeHueSaturation")
        hue_saturation_value_001.name = "Hue Saturation Value.001"
        hue_saturation_value_001.inputs[3].hide = True
        #Fac
        hue_saturation_value_001.inputs[3].default_value = 1.0

        #node Reroute.006
        reroute_006_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_006_2.name = "Reroute.006"
        reroute_006_2.socket_idname = "NodeSocketColor"
        #node Glowing Level
        glowing_level = color_variation_ver__3.nodes.new("ShaderNodeMix")
        glowing_level.label = "Glowing Level"
        glowing_level.name = "Glowing Level"
        glowing_level.blend_type = 'MULTIPLY'
        glowing_level.clamp_factor = True
        glowing_level.clamp_result = False
        glowing_level.data_type = 'RGBA'
        glowing_level.factor_mode = 'UNIFORM'
        glowing_level.inputs[0].hide = True
        #Factor_Float
        glowing_level.inputs[0].default_value = 1.0

        #node Reroute.004
        reroute_004_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_004_2.name = "Reroute.004"
        reroute_004_2.socket_idname = "NodeSocketColor"
        #node Unpaint
        unpaint = color_variation_ver__3.nodes.new("ShaderNodeMix")
        unpaint.label = "Unpaint"
        unpaint.name = "Unpaint"
        unpaint.blend_type = 'MIX'
        unpaint.clamp_factor = True
        unpaint.clamp_result = False
        unpaint.data_type = 'RGBA'
        unpaint.factor_mode = 'UNIFORM'

        #node Reroute.013
        reroute_013_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_013_2.name = "Reroute.013"
        reroute_013_2.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.014
        reroute_014_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_014_2.name = "Reroute.014"
        reroute_014_2.socket_idname = "NodeSocketColor"
        #node Reroute.012
        reroute_012_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_012_2.name = "Reroute.012"
        reroute_012_2.socket_idname = "NodeSocketFloat"
        #node Unpaint.001
        unpaint_001 = color_variation_ver__3.nodes.new("ShaderNodeMix")
        unpaint_001.label = "Color Inverter"
        unpaint_001.name = "Unpaint.001"
        unpaint_001.blend_type = 'DIFFERENCE'
        unpaint_001.clamp_factor = True
        unpaint_001.clamp_result = False
        unpaint_001.data_type = 'RGBA'
        unpaint_001.factor_mode = 'UNIFORM'

        #node Reroute
        reroute_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_2.name = "Reroute"
        reroute_2.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.001
        reroute_001_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_001_2.name = "Reroute.001"
        reroute_001_2.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_002_2.name = "Reroute.002"
        reroute_002_2.socket_idname = "NodeSocketColor"
        #node Reroute.003
        reroute_003_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_003_2.name = "Reroute.003"
        reroute_003_2.socket_idname = "NodeSocketColor"
        #node Reroute.021
        reroute_021_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_021_2.name = "Reroute.021"
        reroute_021_2.socket_idname = "NodeSocketColor"
        #node Reroute.005
        reroute_005_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_005_2.name = "Reroute.005"
        reroute_005_2.socket_idname = "NodeSocketColor"
        #node Reroute.018
        reroute_018_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_018_2.name = "Reroute.018"
        reroute_018_2.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_008_2.name = "Reroute.008"
        reroute_008_2.socket_idname = "NodeSocketFloatUnsigned"
        #node Reroute.030
        reroute_030 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_030.name = "Reroute.030"
        reroute_030.socket_idname = "NodeSocketFloat"
        #node Reroute.029
        reroute_029 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_029.name = "Reroute.029"
        reroute_029.socket_idname = "NodeSocketFloatUnsigned"
        #node Reroute.032
        reroute_032 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_032.name = "Reroute.032"
        reroute_032.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.023
        reroute_023_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_023_1.name = "Reroute.023"
        reroute_023_1.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.031
        reroute_031 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_031.name = "Reroute.031"
        reroute_031.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.037
        reroute_037 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_037.name = "Reroute.037"
        reroute_037.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.036
        reroute_036 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_036.name = "Reroute.036"
        reroute_036.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.022
        reroute_022_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_022_2.name = "Reroute.022"
        reroute_022_2.socket_idname = "NodeSocketFloatFactor"
        #node RGB to BW
        rgb_to_bw = color_variation_ver__3.nodes.new("ShaderNodeRGBToBW")
        rgb_to_bw.name = "RGB to BW"

        #node Reroute.019
        reroute_019_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_019_2.name = "Reroute.019"
        reroute_019_2.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_020_2.name = "Reroute.020"
        reroute_020_2.socket_idname = "NodeSocketFloat"
        #node Reroute.038
        reroute_038 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_038.name = "Reroute.038"
        reroute_038.socket_idname = "NodeSocketColor"
        #node Reroute.025
        reroute_025_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_025_2.name = "Reroute.025"
        reroute_025_2.socket_idname = "NodeSocketColor"
        #node Reroute.055
        reroute_055 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_055.name = "Reroute.055"
        reroute_055.socket_idname = "NodeSocketColor"
        #node Group Output
        group_output_2 = color_variation_ver__3.nodes.new("NodeGroupOutput")
        group_output_2.name = "Group Output"
        group_output_2.use_custom_color = True
        group_output_2.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_2.is_active_output = True
        group_output_2.inputs[1].hide = True

        #node Reroute.026
        reroute_026_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_026_1.name = "Reroute.026"
        reroute_026_1.socket_idname = "NodeSocketFloat"
        #node Reroute.028
        reroute_028_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_028_1.name = "Reroute.028"
        reroute_028_1.socket_idname = "NodeSocketFloat"
        #node Reroute.027
        reroute_027_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_027_1.name = "Reroute.027"
        reroute_027_1.socket_idname = "NodeSocketFloat"
        #node Reroute.034
        reroute_034 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_034.name = "Reroute.034"
        reroute_034.socket_idname = "NodeSocketFloat"
        #node Reroute.033
        reroute_033 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_033.name = "Reroute.033"
        reroute_033.socket_idname = "NodeSocketFloat"
        #node Reroute.035
        reroute_035 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_035.name = "Reroute.035"
        reroute_035.socket_idname = "NodeSocketFloat"
        #node Group Input.001
        group_input_001 = color_variation_ver__3.nodes.new("NodeGroupInput")
        group_input_001.name = "Group Input.001"
        group_input_001.use_custom_color = True
        group_input_001.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_001.outputs[1].hide = True
        group_input_001.outputs[2].hide = True
        group_input_001.outputs[3].hide = True
        group_input_001.outputs[4].hide = True
        group_input_001.outputs[5].hide = True
        group_input_001.outputs[13].hide = True
        group_input_001.outputs[16].hide = True
        group_input_001.outputs[17].hide = True
        group_input_001.outputs[18].hide = True
        group_input_001.outputs[19].hide = True
        group_input_001.outputs[20].hide = True

        #node Reroute.017
        reroute_017_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_017_1.name = "Reroute.017"
        reroute_017_1.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_1 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_015_1.name = "Reroute.015"
        reroute_015_1.socket_idname = "NodeSocketColor"
        #node Reroute.016
        reroute_016_2 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_016_2.name = "Reroute.016"
        reroute_016_2.socket_idname = "NodeSocketColor"
        #node Reroute.058
        reroute_058 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_058.name = "Reroute.058"
        reroute_058.socket_idname = "NodeSocketColor"
        #node Clamp
        clamp = color_variation_ver__3.nodes.new("ShaderNodeClamp")
        clamp.name = "Clamp"
        clamp.clamp_type = 'MINMAX'
        clamp.inputs[1].hide = True
        clamp.inputs[2].hide = True
        #Min
        clamp.inputs[1].default_value = 0.0
        #Max
        clamp.inputs[2].default_value = 1.0

        #node Reroute.047
        reroute_047 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_047.name = "Reroute.047"
        reroute_047.socket_idname = "NodeSocketFloat"
        #node Reroute.050
        reroute_050 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_050.name = "Reroute.050"
        reroute_050.socket_idname = "NodeSocketFloat"
        #node Reroute.063
        reroute_063 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_063.name = "Reroute.063"
        reroute_063.socket_idname = "NodeSocketFloat"
        #node Map Range
        map_range = color_variation_ver__3.nodes.new("ShaderNodeMapRange")
        map_range.name = "Map Range"
        map_range.clamp = True
        map_range.data_type = 'FLOAT'
        map_range.interpolation_type = 'LINEAR'
        map_range.inputs[1].hide = True
        map_range.inputs[2].hide = True
        map_range.inputs[4].hide = True
        map_range.inputs[5].hide = True
        map_range.inputs[6].hide = True
        map_range.inputs[7].hide = True
        map_range.inputs[8].hide = True
        map_range.inputs[9].hide = True
        map_range.inputs[10].hide = True
        map_range.inputs[11].hide = True
        map_range.outputs[1].hide = True
        #From Min
        map_range.inputs[1].default_value = 0.0
        #From Max
        map_range.inputs[2].default_value = 1.0
        #To Max
        map_range.inputs[4].default_value = 1.0

        #node Reroute.048
        reroute_048 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_048.name = "Reroute.048"
        reroute_048.socket_idname = "NodeSocketFloat"
        #node Reroute.049
        reroute_049 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_049.name = "Reroute.049"
        reroute_049.socket_idname = "NodeSocketFloat"
        #node Reroute.054
        reroute_054 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_054.name = "Reroute.054"
        reroute_054.socket_idname = "NodeSocketColor"
        #node Reroute.053
        reroute_053 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_053.name = "Reroute.053"
        reroute_053.socket_idname = "NodeSocketColor"
        #node Rainbow Saturation
        rainbow_saturation = color_variation_ver__3.nodes.new("ShaderNodeMix")
        rainbow_saturation.label = "Rainbow Saturation"
        rainbow_saturation.name = "Rainbow Saturation"
        rainbow_saturation.blend_type = 'HUE'
        rainbow_saturation.clamp_factor = True
        rainbow_saturation.clamp_result = False
        rainbow_saturation.data_type = 'RGBA'
        rainbow_saturation.factor_mode = 'UNIFORM'

        #node Reroute.056
        reroute_056 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_056.name = "Reroute.056"
        reroute_056.socket_idname = "NodeSocketFloat"
        #node Reroute.044
        reroute_044 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_044.name = "Reroute.044"
        reroute_044.socket_idname = "NodeSocketFloat"
        #node Reroute.045
        reroute_045 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_045.name = "Reroute.045"
        reroute_045.socket_idname = "NodeSocketColor"
        #node Reroute.039
        reroute_039 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_039.name = "Reroute.039"
        reroute_039.socket_idname = "NodeSocketFloat"
        #node Dark Spots
        dark_spots = color_variation_ver__3.nodes.new("ShaderNodeMix")
        dark_spots.label = "Dark Spots"
        dark_spots.name = "Dark Spots"
        dark_spots.blend_type = 'SUBTRACT'
        dark_spots.clamp_factor = True
        dark_spots.clamp_result = True
        dark_spots.data_type = 'RGBA'
        dark_spots.factor_mode = 'UNIFORM'

        #node Reroute.040
        reroute_040 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_040.name = "Reroute.040"
        reroute_040.socket_idname = "NodeSocketFloat"
        #node Reroute.041
        reroute_041 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_041.name = "Reroute.041"
        reroute_041.socket_idname = "NodeSocketFloat"
        #node Reroute.042
        reroute_042 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_042.name = "Reroute.042"
        reroute_042.socket_idname = "NodeSocketColor"
        #node Reroute.075
        reroute_075 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_075.name = "Reroute.075"
        reroute_075.socket_idname = "NodeSocketColor"
        #node Reroute.057
        reroute_057 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_057.name = "Reroute.057"
        reroute_057.socket_idname = "NodeSocketColor"
        #node Reroute.080
        reroute_080 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_080.name = "Reroute.080"
        reroute_080.socket_idname = "NodeSocketFloat"
        #node Reroute.084
        reroute_084 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_084.name = "Reroute.084"
        reroute_084.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.068
        reroute_068 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_068.name = "Reroute.068"
        reroute_068.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.090
        reroute_090 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_090.name = "Reroute.090"
        reroute_090.socket_idname = "NodeSocketFloat"
        #node Reroute.085
        reroute_085 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_085.name = "Reroute.085"
        reroute_085.socket_idname = "NodeSocketFloat"
        #node Reroute.091
        reroute_091 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_091.name = "Reroute.091"
        reroute_091.socket_idname = "NodeSocketFloatFactor"
        #node Reroute.065
        reroute_065 = color_variation_ver__3.nodes.new("NodeReroute")
        reroute_065.name = "Reroute.065"
        reroute_065.socket_idname = "NodeSocketFloatFactor"
        #node Group Input
        group_input_2 = color_variation_ver__3.nodes.new("NodeGroupInput")
        group_input_2.name = "Group Input"
        group_input_2.use_custom_color = True
        group_input_2.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_2.outputs[1].hide = True
        group_input_2.outputs[5].hide = True
        group_input_2.outputs[6].hide = True
        group_input_2.outputs[7].hide = True
        group_input_2.outputs[8].hide = True
        group_input_2.outputs[9].hide = True
        group_input_2.outputs[10].hide = True
        group_input_2.outputs[11].hide = True
        group_input_2.outputs[12].hide = True
        group_input_2.outputs[13].hide = True
        group_input_2.outputs[14].hide = True
        group_input_2.outputs[15].hide = True
        group_input_2.outputs[20].hide = True

        #node Clamp.001
        clamp_001 = color_variation_ver__3.nodes.new("ShaderNodeClamp")
        clamp_001.name = "Clamp.001"
        clamp_001.hide = True
        clamp_001.clamp_type = 'MINMAX'
        #Min
        clamp_001.inputs[1].default_value = 0.0
        #Max
        clamp_001.inputs[2].default_value = 1.0


        #Set locations
        node_group_description.location = (-1860.0, 140.0)
        author_001.location = (523.0830688476562, -140.00006103515625)
        hue_saturation_value.location = (-840.0, 0.0)
        map_range_005.location = (-1076.0977783203125, 1.10443115234375)
        reroute_043.location = (-860.0, -34.428741455078125)
        reroute_051.location = (-1100.8663330078125, -36.53314208984375)
        map_range_001.location = (-1330.219482421875, -1.864013671875)
        reroute_046.location = (-1159.276123046875, -140.468505859375)
        reroute_060.location = (-1360.6868896484375, -34.707763671875)
        reroute_059.location = (-1379.2760009765625, -57.001708984375)
        reroute_062.location = (-1379.2760009765625, -143.935302734375)
        reroute_061.location = (-1380.6868896484375, -181.83203125)
        separate_rgb.location = (-1564.264404296875, -0.93304443359375)
        map_range_003.location = (-1564.264404296875, -146.94696044921875)
        reroute_074.location = (-1761.4952392578125, -343.2906188964844)
        math_2.location = (-1981.8692626953125, -308.60565185546875)
        reroute_083.location = (-2040.0, -540.0)
        reroute_076.location = (-2000.0, -424.3804626464844)
        reroute_077.location = (-2000.0, -520.0)
        reroute_079.location = (-1780.0, -280.0)
        reroute_078.location = (-2040.0, -280.0)
        reroute_071.location = (-1800.8328857421875, -651.6659545898438)
        reroute_089.location = (-2002.0323486328125, -606.1069946289062)
        reroute_088.location = (-2042.0323486328125, -628.1426391601562)
        noise_texture.location = (-1740.0, 0.0)
        reroute_073.location = (-1779.018310546875, -156.8382110595703)
        reroute_070.location = (-1799.018310546875, -134.9196319580078)
        reroute_072.location = (-1760.764404296875, -113.37844848632812)
        reroute_069.location = (-1580.0, -37.050193786621094)
        reroute_064.location = (-1580.0, -112.24655151367188)
        reroute_066.location = (-1400.0, -164.91635131835938)
        texture_coordinate.location = (-1920.0, 0.0)
        reroute_082.location = (-1760.0, -87.86614990234375)
        reroute_052.location = (-1100.0, -703.9989624023438)
        map_range_004.location = (-1330.219482421875, -670.8629150390625)
        reroute_067.location = (-2040.0, -860.0)
        reroute_081.location = (-1760.804931640625, -35.59559631347656)
        gamma.location = (-442.0794677734375, 0.0)
        bright_contrast.location = (-622.0794677734375, 0.0)
        reroute_007_2.location = (-462.0794677734375, -60.0)
        reroute_009_2.location = (-642.0794677734375, -60.0)
        reroute_010_2.location = (-642.0794677734375, -105.19729614257812)
        reroute_011_2.location = (-661.0404663085938, -82.59866333007812)
        reroute_024_2.location = (-662.0794677734375, -432.3047790527344)
        hue_saturation_value_001.location = (-178.10520935058594, 0.0)
        reroute_006_2.location = (-198.10533142089844, -34.80267333984375)
        glowing_level.location = (40.3108024597168, 0.0)
        reroute_004_2.location = (223.75184631347656, -34.21795654296875)
        unpaint.location = (243.75196838378906, 1.10443115234375)
        reroute_013_2.location = (203.09547424316406, -111.0155029296875)
        reroute_014_2.location = (223.75184631347656, -132.32879638671875)
        reroute_012_2.location = (223.75184631347656, -155.05810546875)
        unpaint_001.location = (447.1927490234375, 1.10443115234375)
        reroute_2.location = (406.58544921875, -110.3916015625)
        reroute_001_2.location = (425.978271484375, -155.8583984375)
        reroute_002_2.location = (427.1927490234375, -133.4287109375)
        reroute_003_2.location = (426.5855712890625, -33.4287109375)
        reroute_021_2.location = (20.330821990966797, -260.86663818359375)
        reroute_005_2.location = (-2.079456329345703, -34.935211181640625)
        reroute_018_2.location = (223.6961212158203, -234.76605224609375)
        reroute_008_2.location = (-462.0794677734375, -84.1578369140625)
        reroute_030.location = (-642.0794677734375, -300.0)
        reroute_029.location = (-462.0794677734375, -320.0)
        reroute_032.location = (-42.0794563293457, -280.0)
        reroute_023_1.location = (205.41297912597656, -299.0630187988281)
        reroute_031.location = (-22.079395294189453, -260.0)
        reroute_037.location = (-42.0794563293457, -320.0)
        reroute_036.location = (-22.079456329345703, -300.0)
        reroute_022_2.location = (407.75433349609375, -318.12603759765625)
        rgb_to_bw.location = (40.3108024597168, -199.99993896484375)
        reroute_019_2.location = (-2.857715606689453, -408.5048828125)
        reroute_020_2.location = (424.99896240234375, -407.40045166015625)
        reroute_038.location = (-462.8271179199219, -35.512451171875)
        reroute_025_2.location = (21.153453826904297, -235.9571533203125)
        reroute_055.location = (-642.7191162109375, -34.880523681640625)
        group_output_2.location = (627.1929931640625, 1.10443115234375)
        reroute_026_1.location = (-262.0794677734375, -105.45648193359375)
        reroute_028_1.location = (-242.07945251464844, -60.0)
        reroute_027_1.location = (-222.07945251464844, -82.82449340820312)
        reroute_034.location = (-222.07945251464844, -389.4149169921875)
        reroute_033.location = (-242.07945251464844, -364.70745849609375)
        reroute_035.location = (-262.0794677734375, -343.7659606933594)
        group_input_001.location = (-880.0, -200.0)
        reroute_017_1.location = (-1.8766655921936035, -135.10122680664062)
        reroute_015_1.location = (-2.9875054359436035, -112.09341430664062)
        reroute_016_2.location = (-198.76158142089844, -125.8525161743164)
        reroute_058.location = (-1576.6893310546875, -574.3060913085938)
        clamp.location = (-1074.403564453125, -206.49981689453125)
        reroute_047.location = (-1098.3057861328125, -296.1246337890625)
        reroute_050.location = (-1118.3057861328125, -243.41519165039062)
        reroute_063.location = (-1358.5595703125, -350.7763671875)
        map_range.location = (-1328.5252685546875, -209.46826171875)
        reroute_048.location = (-1098.3057861328125, -499.8363037109375)
        reroute_049.location = (-1117.87255859375, -455.50274658203125)
        reroute_054.location = (-1139.2493896484375, -454.6087646484375)
        reroute_053.location = (-1139.755615234375, -479.16705322265625)
        rainbow_saturation.location = (-1328.5252685546875, -420.4671325683594)
        reroute_056.location = (-1378.9447021484375, -532.4076538085938)
        reroute_044.location = (-920.0, -240.0)
        reroute_045.location = (-900.0, -380.0)
        reroute_039.location = (-860.0, -60.0)
        dark_spots.location = (-1074.403564453125, -343.4987487792969)
        reroute_040.location = (-860.7769775390625, -81.55644989013672)
        reroute_041.location = (-920.0, -104.66935729980469)
        reroute_042.location = (-900.0, -125.99195098876953)
        reroute_075.location = (-1600.0, -500.0)
        reroute_057.location = (-1600.0, -556.0668334960938)
        reroute_080.location = (-1398.3057861328125, -372.7381591796875)
        reroute_084.location = (-1620.0, -560.0)
        reroute_068.location = (-1620.6915283203125, -288.52130126953125)
        reroute_090.location = (-1760.0, -375.6439208984375)
        reroute_085.location = (-1761.44970703125, -582.904052734375)
        reroute_091.location = (-2000.0, -814.6226196289062)
        reroute_065.location = (-1160.0, -860.0)
        group_input_2.location = (-2261.869140625, -461.0216369628906)
        clamp_001.location = (-1740.0, -300.0)

        #Set dimensions
        node_group_description.width, node_group_description.height = 400.671630859375, 115.2215576171875
        author_001.width, author_001.height = 289.3975830078125, 30.0
        hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
        map_range_005.width, map_range_005.height = 140.0, 100.0
        reroute_043.width, reroute_043.height = 16.0, 100.0
        reroute_051.width, reroute_051.height = 16.0, 100.0
        map_range_001.width, map_range_001.height = 140.0, 100.0
        reroute_046.width, reroute_046.height = 16.0, 100.0
        reroute_060.width, reroute_060.height = 16.0, 100.0
        reroute_059.width, reroute_059.height = 16.0, 100.0
        reroute_062.width, reroute_062.height = 16.0, 100.0
        reroute_061.width, reroute_061.height = 16.0, 100.0
        separate_rgb.width, separate_rgb.height = 140.0, 100.0
        map_range_003.width, map_range_003.height = 140.0, 100.0
        reroute_074.width, reroute_074.height = 16.0, 100.0
        math_2.width, math_2.height = 140.0, 100.0
        reroute_083.width, reroute_083.height = 16.0, 100.0
        reroute_076.width, reroute_076.height = 16.0, 100.0
        reroute_077.width, reroute_077.height = 16.0, 100.0
        reroute_079.width, reroute_079.height = 16.0, 100.0
        reroute_078.width, reroute_078.height = 16.0, 100.0
        reroute_071.width, reroute_071.height = 16.0, 100.0
        reroute_089.width, reroute_089.height = 16.0, 100.0
        reroute_088.width, reroute_088.height = 16.0, 100.0
        noise_texture.width, noise_texture.height = 140.0, 100.0
        reroute_073.width, reroute_073.height = 16.0, 100.0
        reroute_070.width, reroute_070.height = 16.0, 100.0
        reroute_072.width, reroute_072.height = 16.0, 100.0
        reroute_069.width, reroute_069.height = 16.0, 100.0
        reroute_064.width, reroute_064.height = 16.0, 100.0
        reroute_066.width, reroute_066.height = 16.0, 100.0
        texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
        reroute_082.width, reroute_082.height = 16.0, 100.0
        reroute_052.width, reroute_052.height = 16.0, 100.0
        map_range_004.width, map_range_004.height = 140.0, 100.0
        reroute_067.width, reroute_067.height = 16.0, 100.0
        reroute_081.width, reroute_081.height = 16.0, 100.0
        gamma.width, gamma.height = 140.0, 100.0
        bright_contrast.width, bright_contrast.height = 140.0, 100.0
        reroute_007_2.width, reroute_007_2.height = 16.0, 100.0
        reroute_009_2.width, reroute_009_2.height = 16.0, 100.0
        reroute_010_2.width, reroute_010_2.height = 16.0, 100.0
        reroute_011_2.width, reroute_011_2.height = 16.0, 100.0
        reroute_024_2.width, reroute_024_2.height = 16.0, 100.0
        hue_saturation_value_001.width, hue_saturation_value_001.height = 150.0, 100.0
        reroute_006_2.width, reroute_006_2.height = 16.0, 100.0
        glowing_level.width, glowing_level.height = 140.0, 100.0
        reroute_004_2.width, reroute_004_2.height = 16.0, 100.0
        unpaint.width, unpaint.height = 140.0, 100.0
        reroute_013_2.width, reroute_013_2.height = 16.0, 100.0
        reroute_014_2.width, reroute_014_2.height = 16.0, 100.0
        reroute_012_2.width, reroute_012_2.height = 16.0, 100.0
        unpaint_001.width, unpaint_001.height = 140.0, 100.0
        reroute_2.width, reroute_2.height = 16.0, 100.0
        reroute_001_2.width, reroute_001_2.height = 16.0, 100.0
        reroute_002_2.width, reroute_002_2.height = 16.0, 100.0
        reroute_003_2.width, reroute_003_2.height = 16.0, 100.0
        reroute_021_2.width, reroute_021_2.height = 16.0, 100.0
        reroute_005_2.width, reroute_005_2.height = 16.0, 100.0
        reroute_018_2.width, reroute_018_2.height = 16.0, 100.0
        reroute_008_2.width, reroute_008_2.height = 16.0, 100.0
        reroute_030.width, reroute_030.height = 16.0, 100.0
        reroute_029.width, reroute_029.height = 16.0, 100.0
        reroute_032.width, reroute_032.height = 16.0, 100.0
        reroute_023_1.width, reroute_023_1.height = 16.0, 100.0
        reroute_031.width, reroute_031.height = 16.0, 100.0
        reroute_037.width, reroute_037.height = 16.0, 100.0
        reroute_036.width, reroute_036.height = 16.0, 100.0
        reroute_022_2.width, reroute_022_2.height = 16.0, 100.0
        rgb_to_bw.width, rgb_to_bw.height = 140.0, 100.0
        reroute_019_2.width, reroute_019_2.height = 16.0, 100.0
        reroute_020_2.width, reroute_020_2.height = 16.0, 100.0
        reroute_038.width, reroute_038.height = 16.0, 100.0
        reroute_025_2.width, reroute_025_2.height = 16.0, 100.0
        reroute_055.width, reroute_055.height = 16.0, 100.0
        group_output_2.width, group_output_2.height = 140.0, 100.0
        reroute_026_1.width, reroute_026_1.height = 16.0, 100.0
        reroute_028_1.width, reroute_028_1.height = 16.0, 100.0
        reroute_027_1.width, reroute_027_1.height = 16.0, 100.0
        reroute_034.width, reroute_034.height = 16.0, 100.0
        reroute_033.width, reroute_033.height = 16.0, 100.0
        reroute_035.width, reroute_035.height = 16.0, 100.0
        group_input_001.width, group_input_001.height = 188.32958984375, 100.0
        reroute_017_1.width, reroute_017_1.height = 16.0, 100.0
        reroute_015_1.width, reroute_015_1.height = 16.0, 100.0
        reroute_016_2.width, reroute_016_2.height = 16.0, 100.0
        reroute_058.width, reroute_058.height = 16.0, 100.0
        clamp.width, clamp.height = 140.0, 100.0
        reroute_047.width, reroute_047.height = 16.0, 100.0
        reroute_050.width, reroute_050.height = 16.0, 100.0
        reroute_063.width, reroute_063.height = 16.0, 100.0
        map_range.width, map_range.height = 140.0, 100.0
        reroute_048.width, reroute_048.height = 16.0, 100.0
        reroute_049.width, reroute_049.height = 16.0, 100.0
        reroute_054.width, reroute_054.height = 16.0, 100.0
        reroute_053.width, reroute_053.height = 16.0, 100.0
        rainbow_saturation.width, rainbow_saturation.height = 140.0, 100.0
        reroute_056.width, reroute_056.height = 16.0, 100.0
        reroute_044.width, reroute_044.height = 16.0, 100.0
        reroute_045.width, reroute_045.height = 16.0, 100.0
        reroute_039.width, reroute_039.height = 16.0, 100.0
        dark_spots.width, dark_spots.height = 140.0, 100.0
        reroute_040.width, reroute_040.height = 16.0, 100.0
        reroute_041.width, reroute_041.height = 16.0, 100.0
        reroute_042.width, reroute_042.height = 16.0, 100.0
        reroute_075.width, reroute_075.height = 16.0, 100.0
        reroute_057.width, reroute_057.height = 16.0, 100.0
        reroute_080.width, reroute_080.height = 16.0, 100.0
        reroute_084.width, reroute_084.height = 16.0, 100.0
        reroute_068.width, reroute_068.height = 16.0, 100.0
        reroute_090.width, reroute_090.height = 16.0, 100.0
        reroute_085.width, reroute_085.height = 16.0, 100.0
        reroute_091.width, reroute_091.height = 16.0, 100.0
        reroute_065.width, reroute_065.height = 16.0, 100.0
        group_input_2.width, group_input_2.height = 188.32958984375, 100.0
        clamp_001.width, clamp_001.height = 140.0, 100.0

        #initialize color_variation_ver__3 links
        #reroute_064.Output -> separate_rgb.Color
        color_variation_ver__3.links.new(reroute_064.outputs[0], separate_rgb.inputs[0])
        #reroute_058.Output -> rainbow_saturation.B
        color_variation_ver__3.links.new(reroute_058.outputs[0], rainbow_saturation.inputs[7])
        #reroute_057.Output -> rainbow_saturation.A
        color_variation_ver__3.links.new(reroute_057.outputs[0], rainbow_saturation.inputs[6])
        #reroute_053.Output -> dark_spots.A
        color_variation_ver__3.links.new(reroute_053.outputs[0], dark_spots.inputs[6])
        #reroute_049.Output -> dark_spots.Factor
        color_variation_ver__3.links.new(reroute_049.outputs[0], dark_spots.inputs[0])
        #reroute_063.Output -> map_range.Value
        color_variation_ver__3.links.new(reroute_063.outputs[0], map_range.inputs[0])
        #reroute_072.Output -> noise_texture.Scale
        color_variation_ver__3.links.new(reroute_072.outputs[0], noise_texture.inputs[2])
        #reroute_082.Output -> noise_texture.Vector
        color_variation_ver__3.links.new(reroute_082.outputs[0], noise_texture.inputs[0])
        #reroute_076.Output -> math_2.Value
        color_variation_ver__3.links.new(reroute_076.outputs[0], math_2.inputs[0])
        #reroute_068.Output -> map_range_003.Value
        color_variation_ver__3.links.new(reroute_068.outputs[0], map_range_003.inputs[0])
        #reroute_048.Output -> dark_spots.B
        color_variation_ver__3.links.new(reroute_048.outputs[0], dark_spots.inputs[7])
        #reroute_042.Output -> hue_saturation_value.Color
        color_variation_ver__3.links.new(reroute_042.outputs[0], hue_saturation_value.inputs[4])
        #reroute_047.Output -> clamp.Value
        color_variation_ver__3.links.new(reroute_047.outputs[0], clamp.inputs[0])
        #reroute_040.Output -> hue_saturation_value.Value
        color_variation_ver__3.links.new(reroute_040.outputs[0], hue_saturation_value.inputs[2])
        #reroute_062.Output -> map_range_001.Value
        color_variation_ver__3.links.new(reroute_062.outputs[0], map_range_001.inputs[0])
        #reroute_041.Output -> hue_saturation_value.Fac
        color_variation_ver__3.links.new(reroute_041.outputs[0], hue_saturation_value.inputs[3])
        #reroute_066.Output -> map_range_001.To Min
        color_variation_ver__3.links.new(reroute_066.outputs[0], map_range_001.inputs[3])
        #reroute_039.Output -> hue_saturation_value.Saturation
        color_variation_ver__3.links.new(reroute_039.outputs[0], hue_saturation_value.inputs[1])
        #reroute_073.Output -> noise_texture.Distortion
        color_variation_ver__3.links.new(reroute_073.outputs[0], noise_texture.inputs[8])
        #reroute_056.Output -> rainbow_saturation.Factor
        color_variation_ver__3.links.new(reroute_056.outputs[0], rainbow_saturation.inputs[0])
        #reroute_091.Output -> map_range_004.Value
        color_variation_ver__3.links.new(reroute_091.outputs[0], map_range_004.inputs[0])
        #reroute_046.Output -> map_range_005.Value
        color_variation_ver__3.links.new(reroute_046.outputs[0], map_range_005.inputs[0])
        #reroute_009_2.Output -> bright_contrast.Color
        color_variation_ver__3.links.new(reroute_009_2.outputs[0], bright_contrast.inputs[0])
        #reroute_011_2.Output -> bright_contrast.Bright
        color_variation_ver__3.links.new(reroute_011_2.outputs[0], bright_contrast.inputs[1])
        #reroute_010_2.Output -> bright_contrast.Contrast
        color_variation_ver__3.links.new(reroute_010_2.outputs[0], bright_contrast.inputs[2])
        #reroute_007_2.Output -> gamma.Color
        color_variation_ver__3.links.new(reroute_007_2.outputs[0], gamma.inputs[0])
        #reroute_008_2.Output -> gamma.Gamma
        color_variation_ver__3.links.new(reroute_008_2.outputs[0], gamma.inputs[1])
        #reroute_016_2.Output -> hue_saturation_value_001.Color
        color_variation_ver__3.links.new(reroute_016_2.outputs[0], hue_saturation_value_001.inputs[4])
        #reroute_028_1.Output -> hue_saturation_value_001.Hue
        color_variation_ver__3.links.new(reroute_028_1.outputs[0], hue_saturation_value_001.inputs[0])
        #reroute_027_1.Output -> hue_saturation_value_001.Saturation
        color_variation_ver__3.links.new(reroute_027_1.outputs[0], hue_saturation_value_001.inputs[1])
        #reroute_026_1.Output -> hue_saturation_value_001.Value
        color_variation_ver__3.links.new(reroute_026_1.outputs[0], hue_saturation_value_001.inputs[2])
        #reroute_015_1.Output -> glowing_level.A
        color_variation_ver__3.links.new(reroute_015_1.outputs[0], glowing_level.inputs[6])
        #reroute_017_1.Output -> glowing_level.B
        color_variation_ver__3.links.new(reroute_017_1.outputs[0], glowing_level.inputs[7])
        #reroute_012_2.Output -> unpaint.B
        color_variation_ver__3.links.new(reroute_012_2.outputs[0], unpaint.inputs[7])
        #reroute_014_2.Output -> unpaint.A
        color_variation_ver__3.links.new(reroute_014_2.outputs[0], unpaint.inputs[6])
        #reroute_021_2.Output -> rgb_to_bw.Color
        color_variation_ver__3.links.new(reroute_021_2.outputs[0], rgb_to_bw.inputs[0])
        #reroute_013_2.Output -> unpaint.Factor
        color_variation_ver__3.links.new(reroute_013_2.outputs[0], unpaint.inputs[0])
        #unpaint_001.Result -> group_output_2.Color
        color_variation_ver__3.links.new(unpaint_001.outputs[2], group_output_2.inputs[0])
        #reroute_002_2.Output -> unpaint_001.A
        color_variation_ver__3.links.new(reroute_002_2.outputs[0], unpaint_001.inputs[6])
        #reroute_001_2.Output -> unpaint_001.B
        color_variation_ver__3.links.new(reroute_001_2.outputs[0], unpaint_001.inputs[7])
        #reroute_2.Output -> unpaint_001.Factor
        color_variation_ver__3.links.new(reroute_2.outputs[0], unpaint_001.inputs[0])
        #reroute_022_2.Output -> reroute_2.Input
        color_variation_ver__3.links.new(reroute_022_2.outputs[0], reroute_2.inputs[0])
        #reroute_020_2.Output -> reroute_001_2.Input
        color_variation_ver__3.links.new(reroute_020_2.outputs[0], reroute_001_2.inputs[0])
        #reroute_003_2.Output -> reroute_002_2.Input
        color_variation_ver__3.links.new(reroute_003_2.outputs[0], reroute_002_2.inputs[0])
        #unpaint.Result -> reroute_003_2.Input
        color_variation_ver__3.links.new(unpaint.outputs[2], reroute_003_2.inputs[0])
        #glowing_level.Result -> reroute_004_2.Input
        color_variation_ver__3.links.new(glowing_level.outputs[2], reroute_004_2.inputs[0])
        #hue_saturation_value_001.Color -> reroute_005_2.Input
        color_variation_ver__3.links.new(hue_saturation_value_001.outputs[0], reroute_005_2.inputs[0])
        #gamma.Color -> reroute_006_2.Input
        color_variation_ver__3.links.new(gamma.outputs[0], reroute_006_2.inputs[0])
        #reroute_038.Output -> reroute_007_2.Input
        color_variation_ver__3.links.new(reroute_038.outputs[0], reroute_007_2.inputs[0])
        #reroute_029.Output -> reroute_008_2.Input
        color_variation_ver__3.links.new(reroute_029.outputs[0], reroute_008_2.inputs[0])
        #reroute_055.Output -> reroute_009_2.Input
        color_variation_ver__3.links.new(reroute_055.outputs[0], reroute_009_2.inputs[0])
        #reroute_030.Output -> reroute_010_2.Input
        color_variation_ver__3.links.new(reroute_030.outputs[0], reroute_010_2.inputs[0])
        #reroute_024_2.Output -> reroute_011_2.Input
        color_variation_ver__3.links.new(reroute_024_2.outputs[0], reroute_011_2.inputs[0])
        #reroute_018_2.Output -> reroute_012_2.Input
        color_variation_ver__3.links.new(reroute_018_2.outputs[0], reroute_012_2.inputs[0])
        #reroute_023_1.Output -> reroute_013_2.Input
        color_variation_ver__3.links.new(reroute_023_1.outputs[0], reroute_013_2.inputs[0])
        #reroute_004_2.Output -> reroute_014_2.Input
        color_variation_ver__3.links.new(reroute_004_2.outputs[0], reroute_014_2.inputs[0])
        #reroute_005_2.Output -> reroute_015_1.Input
        color_variation_ver__3.links.new(reroute_005_2.outputs[0], reroute_015_1.inputs[0])
        #reroute_006_2.Output -> reroute_016_2.Input
        color_variation_ver__3.links.new(reroute_006_2.outputs[0], reroute_016_2.inputs[0])
        #reroute_019_2.Output -> reroute_017_1.Input
        color_variation_ver__3.links.new(reroute_019_2.outputs[0], reroute_017_1.inputs[0])
        #rgb_to_bw.Val -> reroute_018_2.Input
        color_variation_ver__3.links.new(rgb_to_bw.outputs[0], reroute_018_2.inputs[0])
        #group_input_001.  Glowing Level -> reroute_019_2.Input
        color_variation_ver__3.links.new(group_input_001.outputs[14], reroute_019_2.inputs[0])
        #reroute_019_2.Output -> reroute_020_2.Input
        color_variation_ver__3.links.new(reroute_019_2.outputs[0], reroute_020_2.inputs[0])
        #reroute_025_2.Output -> reroute_021_2.Input
        color_variation_ver__3.links.new(reroute_025_2.outputs[0], reroute_021_2.inputs[0])
        #reroute_037.Output -> reroute_022_2.Input
        color_variation_ver__3.links.new(reroute_037.outputs[0], reroute_022_2.inputs[0])
        #reroute_036.Output -> reroute_023_1.Input
        color_variation_ver__3.links.new(reroute_036.outputs[0], reroute_023_1.inputs[0])
        #group_input_001.  Brightness -> reroute_024_2.Input
        color_variation_ver__3.links.new(group_input_001.outputs[15], reroute_024_2.inputs[0])
        #group_input_001.Input Color -> reroute_025_2.Input
        color_variation_ver__3.links.new(group_input_001.outputs[0], reroute_025_2.inputs[0])
        #reroute_035.Output -> reroute_026_1.Input
        color_variation_ver__3.links.new(reroute_035.outputs[0], reroute_026_1.inputs[0])
        #reroute_034.Output -> reroute_027_1.Input
        color_variation_ver__3.links.new(reroute_034.outputs[0], reroute_027_1.inputs[0])
        #reroute_033.Output -> reroute_028_1.Input
        color_variation_ver__3.links.new(reroute_033.outputs[0], reroute_028_1.inputs[0])
        #group_input_001.    Hue -> reroute_033.Input
        color_variation_ver__3.links.new(group_input_001.outputs[11], reroute_033.inputs[0])
        #group_input_001.    Saturation -> reroute_034.Input
        color_variation_ver__3.links.new(group_input_001.outputs[12], reroute_034.inputs[0])
        #group_input_001.  Hue / Sat Value -> reroute_035.Input
        color_variation_ver__3.links.new(group_input_001.outputs[10], reroute_035.inputs[0])
        #group_input_001.  Gamma -> reroute_029.Input
        color_variation_ver__3.links.new(group_input_001.outputs[9], reroute_029.inputs[0])
        #group_input_001.  Contrast -> reroute_030.Input
        color_variation_ver__3.links.new(group_input_001.outputs[8], reroute_030.inputs[0])
        #group_input_001.  Unpaint -> reroute_031.Input
        color_variation_ver__3.links.new(group_input_001.outputs[6], reroute_031.inputs[0])
        #group_input_001.  Color Inverter -> reroute_032.Input
        color_variation_ver__3.links.new(group_input_001.outputs[7], reroute_032.inputs[0])
        #reroute_031.Output -> reroute_036.Input
        color_variation_ver__3.links.new(reroute_031.outputs[0], reroute_036.inputs[0])
        #reroute_032.Output -> reroute_037.Input
        color_variation_ver__3.links.new(reroute_032.outputs[0], reroute_037.inputs[0])
        #bright_contrast.Color -> reroute_038.Input
        color_variation_ver__3.links.new(bright_contrast.outputs[0], reroute_038.inputs[0])
        #reroute_043.Output -> reroute_039.Input
        color_variation_ver__3.links.new(reroute_043.outputs[0], reroute_039.inputs[0])
        #reroute_039.Output -> reroute_040.Input
        color_variation_ver__3.links.new(reroute_039.outputs[0], reroute_040.inputs[0])
        #reroute_044.Output -> reroute_041.Input
        color_variation_ver__3.links.new(reroute_044.outputs[0], reroute_041.inputs[0])
        #reroute_045.Output -> reroute_042.Input
        color_variation_ver__3.links.new(reroute_045.outputs[0], reroute_042.inputs[0])
        #map_range_005.Result -> reroute_043.Input
        color_variation_ver__3.links.new(map_range_005.outputs[0], reroute_043.inputs[0])
        #clamp.Result -> reroute_044.Input
        color_variation_ver__3.links.new(clamp.outputs[0], reroute_044.inputs[0])
        #dark_spots.Result -> reroute_045.Input
        color_variation_ver__3.links.new(dark_spots.outputs[2], reroute_045.inputs[0])
        #reroute_065.Output -> reroute_046.Input
        color_variation_ver__3.links.new(reroute_065.outputs[0], reroute_046.inputs[0])
        #reroute_051.Output -> reroute_047.Input
        color_variation_ver__3.links.new(reroute_051.outputs[0], reroute_047.inputs[0])
        #reroute_052.Output -> reroute_048.Input
        color_variation_ver__3.links.new(reroute_052.outputs[0], reroute_048.inputs[0])
        #reroute_050.Output -> reroute_049.Input
        color_variation_ver__3.links.new(reroute_050.outputs[0], reroute_049.inputs[0])
        #map_range_001.Result -> reroute_051.Input
        color_variation_ver__3.links.new(map_range_001.outputs[0], reroute_051.inputs[0])
        #map_range_004.Result -> reroute_052.Input
        color_variation_ver__3.links.new(map_range_004.outputs[0], reroute_052.inputs[0])
        #reroute_054.Output -> reroute_053.Input
        color_variation_ver__3.links.new(reroute_054.outputs[0], reroute_053.inputs[0])
        #rainbow_saturation.Result -> reroute_054.Input
        color_variation_ver__3.links.new(rainbow_saturation.outputs[2], reroute_054.inputs[0])
        #map_range.Result -> reroute_050.Input
        color_variation_ver__3.links.new(map_range.outputs[0], reroute_050.inputs[0])
        #reroute_061.Output -> reroute_056.Input
        color_variation_ver__3.links.new(reroute_061.outputs[0], reroute_056.inputs[0])
        #reroute_075.Output -> reroute_057.Input
        color_variation_ver__3.links.new(reroute_075.outputs[0], reroute_057.inputs[0])
        #reroute_064.Output -> reroute_058.Input
        color_variation_ver__3.links.new(reroute_064.outputs[0], reroute_058.inputs[0])
        #separate_rgb.Green -> reroute_059.Input
        color_variation_ver__3.links.new(separate_rgb.outputs[1], reroute_059.inputs[0])
        #separate_rgb.Red -> reroute_060.Input
        color_variation_ver__3.links.new(separate_rgb.outputs[0], reroute_060.inputs[0])
        #map_range_003.Result -> reroute_061.Input
        color_variation_ver__3.links.new(map_range_003.outputs[0], reroute_061.inputs[0])
        #reroute_059.Output -> reroute_062.Input
        color_variation_ver__3.links.new(reroute_059.outputs[0], reroute_062.inputs[0])
        #reroute_060.Output -> reroute_063.Input
        color_variation_ver__3.links.new(reroute_060.outputs[0], reroute_063.inputs[0])
        #reroute_067.Output -> reroute_065.Input
        color_variation_ver__3.links.new(reroute_067.outputs[0], reroute_065.inputs[0])
        #reroute_080.Output -> reroute_066.Input
        color_variation_ver__3.links.new(reroute_080.outputs[0], reroute_066.inputs[0])
        #reroute_069.Output -> reroute_064.Input
        color_variation_ver__3.links.new(reroute_069.outputs[0], reroute_064.inputs[0])
        #reroute_084.Output -> reroute_068.Input
        color_variation_ver__3.links.new(reroute_084.outputs[0], reroute_068.inputs[0])
        #noise_texture.Color -> reroute_069.Input
        color_variation_ver__3.links.new(noise_texture.outputs[1], reroute_069.inputs[0])
        #reroute_074.Output -> reroute_072.Input
        color_variation_ver__3.links.new(reroute_074.outputs[0], reroute_072.inputs[0])
        #reroute_079.Output -> reroute_073.Input
        color_variation_ver__3.links.new(reroute_079.outputs[0], reroute_073.inputs[0])
        #math_2.Value -> reroute_074.Input
        color_variation_ver__3.links.new(math_2.outputs[0], reroute_074.inputs[0])
        #group_input_2.Input Color -> reroute_075.Input
        color_variation_ver__3.links.new(group_input_2.outputs[0], reroute_075.inputs[0])
        #reroute_077.Output -> reroute_076.Input
        color_variation_ver__3.links.new(reroute_077.outputs[0], reroute_076.inputs[0])
        #group_input_2.  Color Variation Scale -> reroute_077.Input
        color_variation_ver__3.links.new(group_input_2.outputs[2], reroute_077.inputs[0])
        #reroute_083.Output -> reroute_078.Input
        color_variation_ver__3.links.new(reroute_083.outputs[0], reroute_078.inputs[0])
        #reroute_078.Output -> reroute_079.Input
        color_variation_ver__3.links.new(reroute_078.outputs[0], reroute_079.inputs[0])
        #group_input_2.  Color Variation Distortion -> reroute_083.Input
        color_variation_ver__3.links.new(group_input_2.outputs[3], reroute_083.inputs[0])
        #group_input_2.  Random Color Var -> reroute_084.Input
        color_variation_ver__3.links.new(group_input_2.outputs[4], reroute_084.inputs[0])
        #group_input_2.    Bright Spot Intensity -> reroute_088.Input
        color_variation_ver__3.links.new(group_input_2.outputs[18], reroute_088.inputs[0])
        #group_input_2.    Dark Spot Intensity -> reroute_089.Input
        color_variation_ver__3.links.new(group_input_2.outputs[17], reroute_089.inputs[0])
        #reroute_085.Output -> reroute_090.Input
        color_variation_ver__3.links.new(reroute_085.outputs[0], reroute_090.inputs[0])
        #reroute_088.Output -> reroute_067.Input
        color_variation_ver__3.links.new(reroute_088.outputs[0], reroute_067.inputs[0])
        #reroute_089.Output -> reroute_091.Input
        color_variation_ver__3.links.new(reroute_089.outputs[0], reroute_091.inputs[0])
        #hue_saturation_value.Color -> reroute_055.Input
        color_variation_ver__3.links.new(hue_saturation_value.outputs[0], reroute_055.inputs[0])
        #reroute_071.Output -> reroute_070.Input
        color_variation_ver__3.links.new(reroute_071.outputs[0], reroute_070.inputs[0])
        #group_input_2.  Roughness -> reroute_071.Input
        color_variation_ver__3.links.new(group_input_2.outputs[19], reroute_071.inputs[0])
        #reroute_090.Output -> reroute_080.Input
        color_variation_ver__3.links.new(reroute_090.outputs[0], reroute_080.inputs[0])
        #reroute_080.Output -> map_range.To Min
        color_variation_ver__3.links.new(reroute_080.outputs[0], map_range.inputs[3])
        #texture_coordinate.Object -> reroute_081.Input
        color_variation_ver__3.links.new(texture_coordinate.outputs[3], reroute_081.inputs[0])
        #reroute_081.Output -> reroute_082.Input
        color_variation_ver__3.links.new(reroute_081.outputs[0], reroute_082.inputs[0])
        #group_input_2.  Dark / Bright Threshold -> reroute_085.Input
        color_variation_ver__3.links.new(group_input_2.outputs[16], reroute_085.inputs[0])
        #reroute_070.Output -> clamp_001.Value
        color_variation_ver__3.links.new(reroute_070.outputs[0], clamp_001.inputs[0])
        #clamp_001.Result -> noise_texture.Roughness
        color_variation_ver__3.links.new(clamp_001.outputs[0], noise_texture.inputs[4])
        return color_variation_ver__3

    color_variation_ver__3 = color_variation_ver__3_node_group()

    #initialize Micro Roughness node group
    def micro_roughness_node_group():

        micro_roughness = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Micro Roughness")

        micro_roughness.color_tag = 'NONE'
        micro_roughness.description = ""
        micro_roughness.default_group_node_width = 140
        

        #micro_roughness interface
        #Socket Roughness
        roughness_socket_2 = micro_roughness.interface.new_socket(name = "Roughness", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        roughness_socket_2.default_value = 0.5
        roughness_socket_2.min_value = -3.4028234663852886e+38
        roughness_socket_2.max_value = 3.4028234663852886e+38
        roughness_socket_2.subtype = 'NONE'
        roughness_socket_2.attribute_domain = 'POINT'

        #Socket Roughness
        roughness_socket_3 = micro_roughness.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        roughness_socket_3.default_value = 0.5
        roughness_socket_3.min_value = -10000.0
        roughness_socket_3.max_value = 10000.0
        roughness_socket_3.subtype = 'NONE'
        roughness_socket_3.attribute_domain = 'POINT'

        #Socket Falloff Strength
        falloff_strength_socket = micro_roughness.interface.new_socket(name = "Falloff Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        falloff_strength_socket.default_value = 0.5
        falloff_strength_socket.min_value = -10000.0
        falloff_strength_socket.max_value = 10000.0
        falloff_strength_socket.subtype = 'NONE'
        falloff_strength_socket.attribute_domain = 'POINT'

        #Socket Normal
        normal_socket_2 = micro_roughness.interface.new_socket(name = "Normal", in_out='INPUT', socket_type = 'NodeSocketVector')
        normal_socket_2.default_value = (0.0, 0.0, 0.0)
        normal_socket_2.min_value = -1.0
        normal_socket_2.max_value = 1.0
        normal_socket_2.subtype = 'NONE'
        normal_socket_2.attribute_domain = 'POINT'
        normal_socket_2.hide_value = True


        #initialize micro_roughness nodes
        #node Author
        author_2 = micro_roughness.nodes.new("NodeFrame")
        author_2.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_2.name = "Author"
        author_2.use_custom_color = True
        author_2.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_2.label_size = 16
        author_2.shrink = True

        #node MICRO ROUGHNESS NODE
        micro_roughness_node = micro_roughness.nodes.new("NodeFrame")
        micro_roughness_node.label = "MICRO ROUGHNESS NODE"
        micro_roughness_node.name = "MICRO ROUGHNESS NODE"
        micro_roughness_node.use_custom_color = True
        micro_roughness_node.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        micro_roughness_node.label_size = 15
        micro_roughness_node.shrink = True

        #node Mix
        mix_1 = micro_roughness.nodes.new("ShaderNodeMix")
        mix_1.name = "Mix"
        mix_1.blend_type = 'MIX'
        mix_1.clamp_factor = True
        mix_1.clamp_result = False
        mix_1.data_type = 'RGBA'
        mix_1.factor_mode = 'UNIFORM'

        #node Reroute.010
        reroute_010_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_010_3.name = "Reroute.010"
        reroute_010_3.socket_idname = "NodeSocketFloat"
        #node Math
        math_3 = micro_roughness.nodes.new("ShaderNodeMath")
        math_3.name = "Math"
        math_3.operation = 'MULTIPLY'
        math_3.use_clamp = False
        math_3.inputs[2].hide = True

        #node Math.001
        math_001_2 = micro_roughness.nodes.new("ShaderNodeMath")
        math_001_2.label = "invert"
        math_001_2.name = "Math.001"
        math_001_2.operation = 'SUBTRACT'
        math_001_2.use_clamp = False
        math_001_2.inputs[0].hide = True
        math_001_2.inputs[2].hide = True
        #Value
        math_001_2.inputs[0].default_value = 1.0

        #node Reroute.005
        reroute_005_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_005_3.name = "Reroute.005"
        reroute_005_3.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_004_3.name = "Reroute.004"
        reroute_004_3.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_002_3.name = "Reroute.002"
        reroute_002_3.socket_idname = "NodeSocketFloat"
        #node Reroute.009
        reroute_009_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_009_3.name = "Reroute.009"
        reroute_009_3.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_3.name = "Reroute"
        reroute_3.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_006_3.name = "Reroute.006"
        reroute_006_3.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_003_3.name = "Reroute.003"
        reroute_003_3.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_008_3.name = "Reroute.008"
        reroute_008_3.socket_idname = "NodeSocketFloat"
        #node Group Output
        group_output_3 = micro_roughness.nodes.new("NodeGroupOutput")
        group_output_3.name = "Group Output"
        group_output_3.use_custom_color = True
        group_output_3.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_3.is_active_output = True
        group_output_3.inputs[1].hide = True

        #node Group Input
        group_input_3 = micro_roughness.nodes.new("NodeGroupInput")
        group_input_3.name = "Group Input"
        group_input_3.use_custom_color = True
        group_input_3.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_3.outputs[3].hide = True

        #node Reroute.011
        reroute_011_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_011_3.name = "Reroute.011"
        reroute_011_3.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_3 = micro_roughness.nodes.new("NodeReroute")
        reroute_001_3.name = "Reroute.001"
        reroute_001_3.socket_idname = "NodeSocketFloat"
        #node Fresnel
        fresnel_2 = micro_roughness.nodes.new("ShaderNodeFresnel")
        fresnel_2.name = "Fresnel"
        fresnel_2.inputs[0].hide = True
        #IOR
        fresnel_2.inputs[0].default_value = 1.4500000476837158


        #Set locations
        author_2.location = (-243.2254638671875, -135.482177734375)
        micro_roughness_node.location = (-880.0, 120.0)
        mix_1.location = (-321.61639404296875, 1.617156982421875)
        reroute_010_3.location = (-818.2860717773438, -57.707794189453125)
        math_3.location = (-600.0, -158.74188232421875)
        math_001_2.location = (-800.0, -158.74188232421875)
        reroute_005_3.location = (-643.9569091796875, -194.56954956054688)
        reroute_004_3.location = (-618.0244140625, -274.1084289550781)
        reroute_002_3.location = (-617.9749145507812, -36.5751953125)
        reroute_009_3.location = (-617.6937255859375, -130.76959228515625)
        reroute_3.location = (-438.98358154296875, -193.79837036132812)
        reroute_006_3.location = (-644.81201171875, -295.7078552246094)
        reroute_003_3.location = (-346.58489990234375, -109.98297119140625)
        reroute_008_3.location = (-439.195068359375, -152.83502197265625)
        group_output_3.location = (-158.11016845703125, 1.89166259765625)
        group_input_3.location = (-978.731201171875, 0.468505859375)
        reroute_011_3.location = (-821.3579711914062, -273.18634033203125)
        reroute_001_3.location = (-345.7567138671875, -55.207122802734375)
        fresnel_2.location = (-506.56756591796875, -19.686674118041992)

        #Set dimensions
        author_2.width, author_2.height = 279.0760498046875, 30.0
        micro_roughness_node.width, micro_roughness_node.height = 337.6953125, 100.46127319335938
        mix_1.width, mix_1.height = 140.0, 100.0
        reroute_010_3.width, reroute_010_3.height = 16.0, 100.0
        math_3.width, math_3.height = 140.0, 100.0
        math_001_2.width, math_001_2.height = 140.0, 100.0
        reroute_005_3.width, reroute_005_3.height = 16.0, 100.0
        reroute_004_3.width, reroute_004_3.height = 16.0, 100.0
        reroute_002_3.width, reroute_002_3.height = 16.0, 100.0
        reroute_009_3.width, reroute_009_3.height = 16.0, 100.0
        reroute_3.width, reroute_3.height = 16.0, 100.0
        reroute_006_3.width, reroute_006_3.height = 16.0, 100.0
        reroute_003_3.width, reroute_003_3.height = 16.0, 100.0
        reroute_008_3.width, reroute_008_3.height = 16.0, 100.0
        group_output_3.width, group_output_3.height = 140.0, 100.0
        group_input_3.width, group_input_3.height = 140.0, 100.0
        reroute_011_3.width, reroute_011_3.height = 16.0, 100.0
        reroute_001_3.width, reroute_001_3.height = 16.0, 100.0
        fresnel_2.width, fresnel_2.height = 140.0, 100.0

        #initialize micro_roughness links
        #reroute_008_3.Output -> mix_1.B
        micro_roughness.links.new(reroute_008_3.outputs[0], mix_1.inputs[7])
        #reroute_003_3.Output -> mix_1.Factor
        micro_roughness.links.new(reroute_003_3.outputs[0], mix_1.inputs[0])
        #reroute_006_3.Output -> math_3.Value
        micro_roughness.links.new(reroute_006_3.outputs[0], math_3.inputs[1])
        #reroute_004_3.Output -> math_3.Value
        micro_roughness.links.new(reroute_004_3.outputs[0], math_3.inputs[0])
        #group_input_3.Normal -> fresnel_2.Normal
        micro_roughness.links.new(group_input_3.outputs[2], fresnel_2.inputs[1])
        #reroute_011_3.Output -> math_001_2.Value
        micro_roughness.links.new(reroute_011_3.outputs[0], math_001_2.inputs[1])
        #reroute_009_3.Output -> mix_1.A
        micro_roughness.links.new(reroute_009_3.outputs[0], mix_1.inputs[6])
        #mix_1.Result -> group_output_3.Roughness
        micro_roughness.links.new(mix_1.outputs[2], group_output_3.inputs[0])
        #fresnel_2.Fac -> reroute_001_3.Input
        micro_roughness.links.new(fresnel_2.outputs[0], reroute_001_3.inputs[0])
        #reroute_001_3.Output -> reroute_003_3.Input
        micro_roughness.links.new(reroute_001_3.outputs[0], reroute_003_3.inputs[0])
        #group_input_3.Roughness -> reroute_002_3.Input
        micro_roughness.links.new(group_input_3.outputs[0], reroute_002_3.inputs[0])
        #reroute_009_3.Output -> reroute_004_3.Input
        micro_roughness.links.new(reroute_009_3.outputs[0], reroute_004_3.inputs[0])
        #math_001_2.Value -> reroute_005_3.Input
        micro_roughness.links.new(math_001_2.outputs[0], reroute_005_3.inputs[0])
        #reroute_005_3.Output -> reroute_006_3.Input
        micro_roughness.links.new(reroute_005_3.outputs[0], reroute_006_3.inputs[0])
        #reroute_002_3.Output -> reroute_009_3.Input
        micro_roughness.links.new(reroute_002_3.outputs[0], reroute_009_3.inputs[0])
        #group_input_3.Falloff Strength -> reroute_010_3.Input
        micro_roughness.links.new(group_input_3.outputs[1], reroute_010_3.inputs[0])
        #reroute_010_3.Output -> reroute_011_3.Input
        micro_roughness.links.new(reroute_010_3.outputs[0], reroute_011_3.inputs[0])
        #math_3.Value -> reroute_3.Input
        micro_roughness.links.new(math_3.outputs[0], reroute_3.inputs[0])
        #reroute_3.Output -> reroute_008_3.Input
        micro_roughness.links.new(reroute_3.outputs[0], reroute_008_3.inputs[0])
        return micro_roughness

    micro_roughness = micro_roughness_node_group()

    #initialize Grid View node group
    def grid_view_node_group():

        grid_view = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Grid View")

        grid_view.color_tag = 'NONE'
        grid_view.description = ""
        grid_view.default_group_node_width = 140
        

        #grid_view interface
        #Socket Color
        color_socket_2 = grid_view.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
        color_socket_2.default_value = (0.0, 0.0, 0.0, 0.0)
        color_socket_2.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket = grid_view.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket.default_value = (0.0, 0.0, 0.0)
        vector_socket.min_value = 0.0
        vector_socket.max_value = 1.0
        vector_socket.subtype = 'NONE'
        vector_socket.attribute_domain = 'POINT'
        vector_socket.hide_value = True


        #initialize grid_view nodes
        #node Author
        author_3 = grid_view.nodes.new("NodeFrame")
        author_3.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_3.name = "Author"
        author_3.use_custom_color = True
        author_3.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_3.label_size = 16
        author_3.shrink = True

        #node Mix.001
        mix_001 = grid_view.nodes.new("ShaderNodeMix")
        mix_001.name = "Mix.001"
        mix_001.blend_type = 'DIFFERENCE'
        mix_001.clamp_factor = True
        mix_001.clamp_result = False
        mix_001.data_type = 'RGBA'
        mix_001.factor_mode = 'UNIFORM'
        mix_001.inputs[0].hide = True
        #Factor_Float
        mix_001.inputs[0].default_value = 1.0

        #node Group Output
        group_output_4 = grid_view.nodes.new("NodeGroupOutput")
        group_output_4.name = "Group Output"
        group_output_4.use_custom_color = True
        group_output_4.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_4.is_active_output = True
        group_output_4.inputs[1].hide = True

        #node Group Input
        group_input_4 = grid_view.nodes.new("NodeGroupInput")
        group_input_4.name = "Group Input"
        group_input_4.use_custom_color = True
        group_input_4.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_4.outputs[1].hide = True

        #node Reroute
        reroute_4 = grid_view.nodes.new("NodeReroute")
        reroute_4.name = "Reroute"
        reroute_4.socket_idname = "NodeSocketColor"
        #node Checker Texture.002
        checker_texture_002 = grid_view.nodes.new("ShaderNodeTexChecker")
        checker_texture_002.name = "Checker Texture.002"
        checker_texture_002.inputs[1].hide = True
        checker_texture_002.inputs[2].hide = True
        checker_texture_002.inputs[3].hide = True
        checker_texture_002.outputs[1].hide = True
        #Color1
        checker_texture_002.inputs[1].default_value = (0.010022825561463833, 0.010022825561463833, 0.010022825561463833, 1.0)
        #Color2
        checker_texture_002.inputs[2].default_value = (0.7874122262001038, 0.7874122262001038, 0.7874122262001038, 1.0)
        #Scale
        checker_texture_002.inputs[3].default_value = 4.0

        #node Checker Texture.001
        checker_texture_001 = grid_view.nodes.new("ShaderNodeTexChecker")
        checker_texture_001.name = "Checker Texture.001"
        checker_texture_001.inputs[1].hide = True
        checker_texture_001.inputs[2].hide = True
        checker_texture_001.inputs[3].hide = True
        checker_texture_001.outputs[1].hide = True
        #Color1
        checker_texture_001.inputs[1].default_value = (0.0, 0.0, 0.0, 1.0)
        #Color2
        checker_texture_001.inputs[2].default_value = (1.0, 1.0, 1.0, 1.0)
        #Scale
        checker_texture_001.inputs[3].default_value = 1.0

        #node Reroute.002
        reroute_002_4 = grid_view.nodes.new("NodeReroute")
        reroute_002_4.name = "Reroute.002"
        reroute_002_4.socket_idname = "NodeSocketVector"
        #node Reroute.004
        reroute_004_4 = grid_view.nodes.new("NodeReroute")
        reroute_004_4.name = "Reroute.004"
        reroute_004_4.socket_idname = "NodeSocketVector"
        #node Reroute.003
        reroute_003_4 = grid_view.nodes.new("NodeReroute")
        reroute_003_4.name = "Reroute.003"
        reroute_003_4.socket_idname = "NodeSocketVector"
        #node Reroute.001
        reroute_001_4 = grid_view.nodes.new("NodeReroute")
        reroute_001_4.name = "Reroute.001"
        reroute_001_4.socket_idname = "NodeSocketColor"

        #Set locations
        author_3.location = (220.0, -80.0)
        mix_001.location = (120.0, 40.0)
        group_output_4.location = (300.0, 40.0)
        group_input_4.location = (-240.0, 40.0)
        reroute_4.location = (103.56179809570312, -72.27922058105469)
        checker_texture_002.location = (-60.0, -59.40609359741211)
        checker_texture_001.location = (-60.0, 40.0)
        reroute_002_4.location = (-80.0, 3.5634381771087646)
        reroute_004_4.location = (-80.0, -22.375625610351562)
        reroute_003_4.location = (-80.0, -120.59390258789062)
        reroute_001_4.location = (104.15544128417969, 4.157344341278076)

        #Set dimensions
        author_3.width, author_3.height = 269.55352783203125, 30.0
        mix_001.width, mix_001.height = 140.0, 100.0
        group_output_4.width, group_output_4.height = 140.0, 100.0
        group_input_4.width, group_input_4.height = 140.0, 100.0
        reroute_4.width, reroute_4.height = 16.0, 100.0
        checker_texture_002.width, checker_texture_002.height = 140.0, 100.0
        checker_texture_001.width, checker_texture_001.height = 140.0, 100.0
        reroute_002_4.width, reroute_002_4.height = 16.0, 100.0
        reroute_004_4.width, reroute_004_4.height = 16.0, 100.0
        reroute_003_4.width, reroute_003_4.height = 16.0, 100.0
        reroute_001_4.width, reroute_001_4.height = 16.0, 100.0

        #initialize grid_view links
        #mix_001.Result -> group_output_4.Color
        grid_view.links.new(mix_001.outputs[2], group_output_4.inputs[0])
        #reroute_004_4.Output -> checker_texture_001.Vector
        grid_view.links.new(reroute_004_4.outputs[0], checker_texture_001.inputs[0])
        #reroute_4.Output -> mix_001.A
        grid_view.links.new(reroute_4.outputs[0], mix_001.inputs[6])
        #checker_texture_002.Color -> mix_001.B
        grid_view.links.new(checker_texture_002.outputs[0], mix_001.inputs[7])
        #reroute_001_4.Output -> reroute_4.Input
        grid_view.links.new(reroute_001_4.outputs[0], reroute_4.inputs[0])
        #reroute_003_4.Output -> checker_texture_002.Vector
        grid_view.links.new(reroute_003_4.outputs[0], checker_texture_002.inputs[0])
        #checker_texture_001.Color -> reroute_001_4.Input
        grid_view.links.new(checker_texture_001.outputs[0], reroute_001_4.inputs[0])
        #group_input_4.Vector -> reroute_002_4.Input
        grid_view.links.new(group_input_4.outputs[0], reroute_002_4.inputs[0])
        #reroute_004_4.Output -> reroute_003_4.Input
        grid_view.links.new(reroute_004_4.outputs[0], reroute_003_4.inputs[0])
        #reroute_002_4.Output -> reroute_004_4.Input
        grid_view.links.new(reroute_002_4.outputs[0], reroute_004_4.inputs[0])
        return grid_view

    grid_view = grid_view_node_group()

    #initialize Y Rotation node group
    def y_rotation_node_group():

        y_rotation = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Y Rotation")

        y_rotation.color_tag = 'NONE'
        y_rotation.description = ""
        y_rotation.default_group_node_width = 140
        

        #y_rotation interface
        #Socket Vector
        vector_socket_1 = y_rotation.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_1.default_value = (0.0, 0.0, 0.0)
        vector_socket_1.min_value = 0.0
        vector_socket_1.max_value = 0.0
        vector_socket_1.subtype = 'NONE'
        vector_socket_1.attribute_domain = 'POINT'

        #Socket Angle
        angle_socket = y_rotation.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
        angle_socket.default_value = 0.0
        angle_socket.min_value = -3.4028234663852886e+38
        angle_socket.max_value = 3.4028234663852886e+38
        angle_socket.subtype = 'NONE'
        angle_socket.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_2 = y_rotation.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_2.default_value = (0.0, 0.0, 0.0)
        vector_socket_2.min_value = -3.4028234663852886e+38
        vector_socket_2.max_value = 3.4028234663852886e+38
        vector_socket_2.subtype = 'NONE'
        vector_socket_2.attribute_domain = 'POINT'


        #initialize y_rotation nodes
        #node Author.001
        author_001_1 = y_rotation.nodes.new("NodeFrame")
        author_001_1.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_001_1.name = "Author.001"
        author_001_1.use_custom_color = True
        author_001_1.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_001_1.label_size = 16
        author_001_1.shrink = True

        #node Reroute.038
        reroute_038_1 = y_rotation.nodes.new("NodeReroute")
        reroute_038_1.name = "Reroute.038"
        reroute_038_1.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_3 = y_rotation.nodes.new("NodeReroute")
        reroute_012_3.name = "Reroute.012"
        reroute_012_3.socket_idname = "NodeSocketFloat"
        #node Multiply 3.001
        multiply_3_001 = y_rotation.nodes.new("ShaderNodeMath")
        multiply_3_001.name = "Multiply 3.001"
        multiply_3_001.operation = 'MULTIPLY'
        multiply_3_001.use_clamp = False

        #node Reroute.015
        reroute_015_2 = y_rotation.nodes.new("NodeReroute")
        reroute_015_2.name = "Reroute.015"
        reroute_015_2.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_5 = y_rotation.nodes.new("NodeReroute")
        reroute_003_5.name = "Reroute.003"
        reroute_003_5.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_3 = y_rotation.nodes.new("NodeReroute")
        reroute_007_3.name = "Reroute.007"
        reroute_007_3.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_3 = y_rotation.nodes.new("NodeReroute")
        reroute_013_3.name = "Reroute.013"
        reroute_013_3.socket_idname = "NodeSocketFloat"
        #node Multiply 4.001
        multiply_4_001 = y_rotation.nodes.new("ShaderNodeMath")
        multiply_4_001.name = "Multiply 4.001"
        multiply_4_001.operation = 'MULTIPLY'
        multiply_4_001.use_clamp = False

        #node Reroute.035
        reroute_035_1 = y_rotation.nodes.new("NodeReroute")
        reroute_035_1.name = "Reroute.035"
        reroute_035_1.socket_idname = "NodeSocketFloat"
        #node Reroute.019
        reroute_019_3 = y_rotation.nodes.new("NodeReroute")
        reroute_019_3.name = "Reroute.019"
        reroute_019_3.socket_idname = "NodeSocketFloat"
        #node Cosine.002
        cosine_002 = y_rotation.nodes.new("ShaderNodeMath")
        cosine_002.name = "Cosine.002"
        cosine_002.operation = 'COSINE'
        cosine_002.use_clamp = False
        cosine_002.inputs[1].hide = True

        #node Reroute.031
        reroute_031_1 = y_rotation.nodes.new("NodeReroute")
        reroute_031_1.name = "Reroute.031"
        reroute_031_1.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_4 = y_rotation.nodes.new("NodeReroute")
        reroute_008_4.name = "Reroute.008"
        reroute_008_4.socket_idname = "NodeSocketFloat"
        #node Reroute.036
        reroute_036_1 = y_rotation.nodes.new("NodeReroute")
        reroute_036_1.name = "Reroute.036"
        reroute_036_1.socket_idname = "NodeSocketVector"
        #node Reroute.034
        reroute_034_1 = y_rotation.nodes.new("NodeReroute")
        reroute_034_1.name = "Reroute.034"
        reroute_034_1.socket_idname = "NodeSocketFloat"
        #node Add.001
        add_001 = y_rotation.nodes.new("ShaderNodeMath")
        add_001.name = "Add.001"
        add_001.operation = 'ADD'
        add_001.use_clamp = False

        #node Reroute.027
        reroute_027_2 = y_rotation.nodes.new("NodeReroute")
        reroute_027_2.name = "Reroute.027"
        reroute_027_2.socket_idname = "NodeSocketFloat"
        #node Reroute.026
        reroute_026_2 = y_rotation.nodes.new("NodeReroute")
        reroute_026_2.name = "Reroute.026"
        reroute_026_2.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_4 = y_rotation.nodes.new("NodeReroute")
        reroute_010_4.name = "Reroute.010"
        reroute_010_4.socket_idname = "NodeSocketFloat"
        #node Sine.002
        sine_002 = y_rotation.nodes.new("ShaderNodeMath")
        sine_002.name = "Sine.002"
        sine_002.operation = 'SINE'
        sine_002.use_clamp = False
        sine_002.inputs[1].hide = True

        #node Reroute.032
        reroute_032_1 = y_rotation.nodes.new("NodeReroute")
        reroute_032_1.name = "Reroute.032"
        reroute_032_1.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021_3 = y_rotation.nodes.new("NodeReroute")
        reroute_021_3.name = "Reroute.021"
        reroute_021_3.socket_idname = "NodeSocketFloat"
        #node Math.002
        math_002 = y_rotation.nodes.new("ShaderNodeMath")
        math_002.name = "Math.002"
        math_002.operation = 'DIVIDE'
        math_002.use_clamp = False
        #Value_001
        math_002.inputs[1].default_value = 180.0

        #node Reroute.039
        reroute_039_1 = y_rotation.nodes.new("NodeReroute")
        reroute_039_1.name = "Reroute.039"
        reroute_039_1.socket_idname = "NodeSocketVector"
        #node Reroute.011
        reroute_011_4 = y_rotation.nodes.new("NodeReroute")
        reroute_011_4.name = "Reroute.011"
        reroute_011_4.socket_idname = "NodeSocketFloat"
        #node Sine.003
        sine_003 = y_rotation.nodes.new("ShaderNodeMath")
        sine_003.name = "Sine.003"
        sine_003.operation = 'SINE'
        sine_003.use_clamp = False
        sine_003.inputs[1].hide = True

        #node Reroute.030
        reroute_030_1 = y_rotation.nodes.new("NodeReroute")
        reroute_030_1.name = "Reroute.030"
        reroute_030_1.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_3 = y_rotation.nodes.new("NodeReroute")
        reroute_016_3.name = "Reroute.016"
        reroute_016_3.socket_idname = "NodeSocketFloat"
        #node Reroute.009
        reroute_009_4 = y_rotation.nodes.new("NodeReroute")
        reroute_009_4.name = "Reroute.009"
        reroute_009_4.socket_idname = "NodeSocketFloat"
        #node Multiply 2.001
        multiply_2_001 = y_rotation.nodes.new("ShaderNodeMath")
        multiply_2_001.name = "Multiply 2.001"
        multiply_2_001.operation = 'MULTIPLY'
        multiply_2_001.use_clamp = False

        #node Reroute.037
        reroute_037_1 = y_rotation.nodes.new("NodeReroute")
        reroute_037_1.name = "Reroute.037"
        reroute_037_1.socket_idname = "NodeSocketFloat"
        #node Group Input
        group_input_5 = y_rotation.nodes.new("NodeGroupInput")
        group_input_5.name = "Group Input"
        group_input_5.use_custom_color = True
        group_input_5.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)

        #node Reroute.022
        reroute_022_3 = y_rotation.nodes.new("NodeReroute")
        reroute_022_3.name = "Reroute.022"
        reroute_022_3.socket_idname = "NodeSocketFloat"
        #node Math.003
        math_003 = y_rotation.nodes.new("ShaderNodeMath")
        math_003.name = "Math.003"
        math_003.operation = 'MULTIPLY'
        math_003.use_clamp = False
        #Value_001
        math_003.inputs[1].default_value = -3.1419999599456787

        #node Reroute.005
        reroute_005_4 = y_rotation.nodes.new("NodeReroute")
        reroute_005_4.name = "Reroute.005"
        reroute_005_4.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_4 = y_rotation.nodes.new("NodeReroute")
        reroute_006_4.name = "Reroute.006"
        reroute_006_4.socket_idname = "NodeSocketFloat"
        #node Reroute.028
        reroute_028_2 = y_rotation.nodes.new("NodeReroute")
        reroute_028_2.name = "Reroute.028"
        reroute_028_2.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_5 = y_rotation.nodes.new("NodeReroute")
        reroute_002_5.name = "Reroute.002"
        reroute_002_5.socket_idname = "NodeSocketFloat"
        #node Cosine.003
        cosine_003 = y_rotation.nodes.new("ShaderNodeMath")
        cosine_003.name = "Cosine.003"
        cosine_003.operation = 'COSINE'
        cosine_003.use_clamp = False
        cosine_003.inputs[1].hide = True

        #node Subtract.001
        subtract_001 = y_rotation.nodes.new("ShaderNodeMath")
        subtract_001.name = "Subtract.001"
        subtract_001.operation = 'SUBTRACT'
        subtract_001.use_clamp = False

        #node Reroute.023
        reroute_023_2 = y_rotation.nodes.new("NodeReroute")
        reroute_023_2.name = "Reroute.023"
        reroute_023_2.socket_idname = "NodeSocketFloat"
        #node Multiply 1.001
        multiply_1_001 = y_rotation.nodes.new("ShaderNodeMath")
        multiply_1_001.name = "Multiply 1.001"
        multiply_1_001.operation = 'MULTIPLY'
        multiply_1_001.use_clamp = False

        #node Reroute.020
        reroute_020_3 = y_rotation.nodes.new("NodeReroute")
        reroute_020_3.name = "Reroute.020"
        reroute_020_3.socket_idname = "NodeSocketFloat"
        #node Reroute.040
        reroute_040_1 = y_rotation.nodes.new("NodeReroute")
        reroute_040_1.name = "Reroute.040"
        reroute_040_1.socket_idname = "NodeSocketVector"
        #node Group Output
        group_output_5 = y_rotation.nodes.new("NodeGroupOutput")
        group_output_5.name = "Group Output"
        group_output_5.use_custom_color = True
        group_output_5.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_5.is_active_output = True

        #node Reroute.029
        reroute_029_1 = y_rotation.nodes.new("NodeReroute")
        reroute_029_1.name = "Reroute.029"
        reroute_029_1.socket_idname = "NodeSocketVector"
        #node Combine XYZ.001
        combine_xyz_001 = y_rotation.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_001.name = "Combine XYZ.001"

        #node Reroute.014
        reroute_014_3 = y_rotation.nodes.new("NodeReroute")
        reroute_014_3.name = "Reroute.014"
        reroute_014_3.socket_idname = "NodeSocketFloat"
        #node Reroute.024
        reroute_024_3 = y_rotation.nodes.new("NodeReroute")
        reroute_024_3.name = "Reroute.024"
        reroute_024_3.socket_idname = "NodeSocketFloat"
        #node Reroute.033
        reroute_033_1 = y_rotation.nodes.new("NodeReroute")
        reroute_033_1.name = "Reroute.033"
        reroute_033_1.socket_idname = "NodeSocketFloat"
        #node Reroute.018
        reroute_018_3 = y_rotation.nodes.new("NodeReroute")
        reroute_018_3.name = "Reroute.018"
        reroute_018_3.socket_idname = "NodeSocketFloat"
        #node Separate XYZ.001
        separate_xyz_001 = y_rotation.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_001.name = "Separate XYZ.001"

        #node Reroute.025
        reroute_025_3 = y_rotation.nodes.new("NodeReroute")
        reroute_025_3.name = "Reroute.025"
        reroute_025_3.socket_idname = "NodeSocketFloat"
        #node Reroute.017
        reroute_017_2 = y_rotation.nodes.new("NodeReroute")
        reroute_017_2.name = "Reroute.017"
        reroute_017_2.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_5 = y_rotation.nodes.new("NodeReroute")
        reroute_001_5.name = "Reroute.001"
        reroute_001_5.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_5 = y_rotation.nodes.new("NodeReroute")
        reroute_5.name = "Reroute"
        reroute_5.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_5 = y_rotation.nodes.new("NodeReroute")
        reroute_004_5.name = "Reroute.004"
        reroute_004_5.socket_idname = "NodeSocketFloat"

        #Set locations
        author_001_1.location = (-120.57717895507812, -78.8060073852539)
        reroute_038_1.location = (-1240.0, -114.8805160522461)
        reroute_012_3.location = (-461.0945739746094, -395.0721130371094)
        multiply_3_001.location = (-620.0, -360.0)
        reroute_015_2.location = (-640.4331665039062, -115.23307800292969)
        reroute_003_5.location = (-240.57717895507812, -34.31150436401367)
        reroute_007_3.location = (-440.8663024902344, -316.9665222167969)
        reroute_013_3.location = (-440.9365539550781, -576.7205810546875)
        multiply_4_001.location = (-620.0, -540.0)
        reroute_035_1.location = (-1060.0, -114.8805160522461)
        reroute_019_3.location = (-680.6915283203125, -294.5692138671875)
        cosine_002.location = (-860.0, 0.0)
        reroute_031_1.location = (-880.0, -414.5282287597656)
        reroute_008_4.location = (-460.0, -295.0721130371094)
        reroute_036_1.location = (-1258.42333984375, -55.520450592041016)
        reroute_034_1.location = (-1060.0, -34.880516052246094)
        add_001.location = (-420.0, -180.0)
        reroute_027_2.location = (-680.0202026367188, -494.8603515625)
        reroute_026_2.location = (-680.6396484375, -334.69573974609375)
        reroute_010_4.location = (-440.0, -115.23310089111328)
        sine_002.location = (-860.0, -460.0)
        reroute_032_1.location = (-879.3084716796875, -574.4654541015625)
        reroute_021_3.location = (-640.4331665039062, -34.36639404296875)
        math_002.location = (-1040.0, 0.0)
        reroute_039_1.location = (-900.0, -180.0)
        reroute_011_4.location = (-441.0945739746094, -214.52456665039062)
        sine_003.location = (-860.0, -300.0)
        reroute_030_1.location = (-880.0, -115.15725708007812)
        reroute_016_3.location = (-680.0, -475.9983825683594)
        reroute_009_4.location = (-440.0, -136.53317260742188)
        multiply_2_001.location = (-620.0, -180.0)
        reroute_037_1.location = (-1239.531494140625, -33.600643157958984)
        group_input_5.location = (-1418.42333984375, 1.9198070764541626)
        reroute_022_3.location = (-640.0, -496.4483642578125)
        math_003.location = (-1220.0, 0.0)
        reroute_005_4.location = (-440.0, -33.977020263671875)
        reroute_006_4.location = (-260.5771789550781, -718.8060302734375)
        reroute_028_2.location = (-880.6396484375, -34.94972229003906)
        reroute_002_5.location = (-240.57717895507812, -58.80600357055664)
        cosine_003.location = (-860.0, -620.0)
        subtract_001.location = (-420.0, 0.0)
        reroute_023_2.location = (-640.0, -194.79974365234375)
        multiply_1_001.location = (-620.0, 0.0)
        reroute_020_3.location = (-640.0, -136.5331573486328)
        reroute_040_1.location = (-900.0, -264.396240234375)
        group_output_5.location = (-40.57718276977539, 1.1939947605133057)
        reroute_029_1.location = (-1260.0, -180.0)
        combine_xyz_001.location = (-220.57717895507812, 1.1939947605133057)
        reroute_014_3.location = (-700.0, -720.0)
        reroute_024_3.location = (-660.0, -676.5408935546875)
        reroute_033_1.location = (-880.6915283203125, -735.1572265625)
        reroute_018_3.location = (-659.5668334960938, -316.5331726074219)
        separate_xyz_001.location = (-860.0, -160.0)
        reroute_025_3.location = (-660.0, -237.86825561523438)
        reroute_017_2.location = (-700.0, -216.4470977783203)
        reroute_001_5.location = (-240.0, -103.03995513916016)
        reroute_5.location = (-260.0, -82.43196105957031)
        reroute_004_5.location = (-240.57717895507812, -215.54827880859375)

        #Set dimensions
        author_001_1.width, author_001_1.height = 269.55352783203125, 30.0
        reroute_038_1.width, reroute_038_1.height = 16.0, 100.0
        reroute_012_3.width, reroute_012_3.height = 16.0, 100.0
        multiply_3_001.width, multiply_3_001.height = 140.0, 100.0
        reroute_015_2.width, reroute_015_2.height = 16.0, 100.0
        reroute_003_5.width, reroute_003_5.height = 16.0, 100.0
        reroute_007_3.width, reroute_007_3.height = 16.0, 100.0
        reroute_013_3.width, reroute_013_3.height = 16.0, 100.0
        multiply_4_001.width, multiply_4_001.height = 140.0, 100.0
        reroute_035_1.width, reroute_035_1.height = 16.0, 100.0
        reroute_019_3.width, reroute_019_3.height = 16.0, 100.0
        cosine_002.width, cosine_002.height = 140.0, 100.0
        reroute_031_1.width, reroute_031_1.height = 16.0, 100.0
        reroute_008_4.width, reroute_008_4.height = 16.0, 100.0
        reroute_036_1.width, reroute_036_1.height = 16.0, 100.0
        reroute_034_1.width, reroute_034_1.height = 16.0, 100.0
        add_001.width, add_001.height = 140.0, 100.0
        reroute_027_2.width, reroute_027_2.height = 16.0, 100.0
        reroute_026_2.width, reroute_026_2.height = 16.0, 100.0
        reroute_010_4.width, reroute_010_4.height = 16.0, 100.0
        sine_002.width, sine_002.height = 140.0, 100.0
        reroute_032_1.width, reroute_032_1.height = 16.0, 100.0
        reroute_021_3.width, reroute_021_3.height = 16.0, 100.0
        math_002.width, math_002.height = 140.0, 100.0
        reroute_039_1.width, reroute_039_1.height = 16.0, 100.0
        reroute_011_4.width, reroute_011_4.height = 16.0, 100.0
        sine_003.width, sine_003.height = 140.0, 100.0
        reroute_030_1.width, reroute_030_1.height = 16.0, 100.0
        reroute_016_3.width, reroute_016_3.height = 16.0, 100.0
        reroute_009_4.width, reroute_009_4.height = 16.0, 100.0
        multiply_2_001.width, multiply_2_001.height = 140.0, 100.0
        reroute_037_1.width, reroute_037_1.height = 16.0, 100.0
        group_input_5.width, group_input_5.height = 140.0, 100.0
        reroute_022_3.width, reroute_022_3.height = 16.0, 100.0
        math_003.width, math_003.height = 140.0, 100.0
        reroute_005_4.width, reroute_005_4.height = 16.0, 100.0
        reroute_006_4.width, reroute_006_4.height = 16.0, 100.0
        reroute_028_2.width, reroute_028_2.height = 16.0, 100.0
        reroute_002_5.width, reroute_002_5.height = 16.0, 100.0
        cosine_003.width, cosine_003.height = 140.0, 100.0
        subtract_001.width, subtract_001.height = 140.0, 100.0
        reroute_023_2.width, reroute_023_2.height = 16.0, 100.0
        multiply_1_001.width, multiply_1_001.height = 140.0, 100.0
        reroute_020_3.width, reroute_020_3.height = 16.0, 100.0
        reroute_040_1.width, reroute_040_1.height = 16.0, 100.0
        group_output_5.width, group_output_5.height = 140.0, 100.0
        reroute_029_1.width, reroute_029_1.height = 16.0, 100.0
        combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
        reroute_014_3.width, reroute_014_3.height = 16.0, 100.0
        reroute_024_3.width, reroute_024_3.height = 16.0, 100.0
        reroute_033_1.width, reroute_033_1.height = 16.0, 100.0
        reroute_018_3.width, reroute_018_3.height = 16.0, 100.0
        separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
        reroute_025_3.width, reroute_025_3.height = 16.0, 100.0
        reroute_017_2.width, reroute_017_2.height = 16.0, 100.0
        reroute_001_5.width, reroute_001_5.height = 16.0, 100.0
        reroute_5.width, reroute_5.height = 16.0, 100.0
        reroute_004_5.width, reroute_004_5.height = 16.0, 100.0

        #initialize y_rotation links
        #reroute_040_1.Output -> separate_xyz_001.Vector
        y_rotation.links.new(reroute_040_1.outputs[0], separate_xyz_001.inputs[0])
        #reroute_031_1.Output -> sine_003.Value
        y_rotation.links.new(reroute_031_1.outputs[0], sine_003.inputs[0])
        #reroute_033_1.Output -> cosine_003.Value
        y_rotation.links.new(reroute_033_1.outputs[0], cosine_003.inputs[0])
        #reroute_020_3.Output -> multiply_1_001.Value
        y_rotation.links.new(reroute_020_3.outputs[0], multiply_1_001.inputs[1])
        #reroute_019_3.Output -> multiply_2_001.Value
        y_rotation.links.new(reroute_019_3.outputs[0], multiply_2_001.inputs[0])
        #reroute_018_3.Output -> multiply_2_001.Value
        y_rotation.links.new(reroute_018_3.outputs[0], multiply_2_001.inputs[1])
        #reroute_010_4.Output -> subtract_001.Value
        y_rotation.links.new(reroute_010_4.outputs[0], subtract_001.inputs[0])
        #reroute_009_4.Output -> subtract_001.Value
        y_rotation.links.new(reroute_009_4.outputs[0], subtract_001.inputs[1])
        #reroute_002_5.Output -> combine_xyz_001.X
        y_rotation.links.new(reroute_002_5.outputs[0], combine_xyz_001.inputs[0])
        #reroute_022_3.Output -> multiply_3_001.Value
        y_rotation.links.new(reroute_022_3.outputs[0], multiply_3_001.inputs[1])
        #cosine_003.Value -> multiply_4_001.Value
        y_rotation.links.new(cosine_003.outputs[0], multiply_4_001.inputs[0])
        #reroute_024_3.Output -> multiply_4_001.Value
        y_rotation.links.new(reroute_024_3.outputs[0], multiply_4_001.inputs[1])
        #reroute_008_4.Output -> add_001.Value
        y_rotation.links.new(reroute_008_4.outputs[0], add_001.inputs[0])
        #reroute_007_3.Output -> add_001.Value
        y_rotation.links.new(reroute_007_3.outputs[0], add_001.inputs[1])
        #combine_xyz_001.Vector -> group_output_5.Vector
        y_rotation.links.new(combine_xyz_001.outputs[0], group_output_5.inputs[0])
        #reroute_035_1.Output -> math_002.Value
        y_rotation.links.new(reroute_035_1.outputs[0], math_002.inputs[0])
        #reroute_038_1.Output -> math_003.Value
        y_rotation.links.new(reroute_038_1.outputs[0], math_003.inputs[0])
        #reroute_032_1.Output -> sine_002.Value
        y_rotation.links.new(reroute_032_1.outputs[0], sine_002.inputs[0])
        #reroute_016_3.Output -> multiply_3_001.Value
        y_rotation.links.new(reroute_016_3.outputs[0], multiply_3_001.inputs[0])
        #reroute_030_1.Output -> cosine_002.Value
        y_rotation.links.new(reroute_030_1.outputs[0], cosine_002.inputs[0])
        #reroute_015_2.Output -> multiply_1_001.Value
        y_rotation.links.new(reroute_015_2.outputs[0], multiply_1_001.inputs[0])
        #reroute_006_4.Output -> reroute_5.Input
        y_rotation.links.new(reroute_006_4.outputs[0], reroute_5.inputs[0])
        #reroute_004_5.Output -> reroute_001_5.Input
        y_rotation.links.new(reroute_004_5.outputs[0], reroute_001_5.inputs[0])
        #reroute_003_5.Output -> reroute_002_5.Input
        y_rotation.links.new(reroute_003_5.outputs[0], reroute_002_5.inputs[0])
        #subtract_001.Value -> reroute_003_5.Input
        y_rotation.links.new(subtract_001.outputs[0], reroute_003_5.inputs[0])
        #add_001.Value -> reroute_004_5.Input
        y_rotation.links.new(add_001.outputs[0], reroute_004_5.inputs[0])
        #reroute_014_3.Output -> reroute_006_4.Input
        y_rotation.links.new(reroute_014_3.outputs[0], reroute_006_4.inputs[0])
        #reroute_013_3.Output -> reroute_007_3.Input
        y_rotation.links.new(reroute_013_3.outputs[0], reroute_007_3.inputs[0])
        #reroute_012_3.Output -> reroute_008_4.Input
        y_rotation.links.new(reroute_012_3.outputs[0], reroute_008_4.inputs[0])
        #reroute_011_4.Output -> reroute_009_4.Input
        y_rotation.links.new(reroute_011_4.outputs[0], reroute_009_4.inputs[0])
        #reroute_005_4.Output -> reroute_010_4.Input
        y_rotation.links.new(reroute_005_4.outputs[0], reroute_010_4.inputs[0])
        #multiply_1_001.Value -> reroute_005_4.Input
        y_rotation.links.new(multiply_1_001.outputs[0], reroute_005_4.inputs[0])
        #multiply_2_001.Value -> reroute_011_4.Input
        y_rotation.links.new(multiply_2_001.outputs[0], reroute_011_4.inputs[0])
        #multiply_3_001.Value -> reroute_012_3.Input
        y_rotation.links.new(multiply_3_001.outputs[0], reroute_012_3.inputs[0])
        #multiply_4_001.Value -> reroute_013_3.Input
        y_rotation.links.new(multiply_4_001.outputs[0], reroute_013_3.inputs[0])
        #reroute_017_2.Output -> reroute_014_3.Input
        y_rotation.links.new(reroute_017_2.outputs[0], reroute_014_3.inputs[0])
        #reroute_021_3.Output -> reroute_015_2.Input
        y_rotation.links.new(reroute_021_3.outputs[0], reroute_015_2.inputs[0])
        #reroute_027_2.Output -> reroute_016_3.Input
        y_rotation.links.new(reroute_027_2.outputs[0], reroute_016_3.inputs[0])
        #reroute_025_3.Output -> reroute_018_3.Input
        y_rotation.links.new(reroute_025_3.outputs[0], reroute_018_3.inputs[0])
        #reroute_026_2.Output -> reroute_019_3.Input
        y_rotation.links.new(reroute_026_2.outputs[0], reroute_019_3.inputs[0])
        #cosine_002.Value -> reroute_021_3.Input
        y_rotation.links.new(cosine_002.outputs[0], reroute_021_3.inputs[0])
        #reroute_023_2.Output -> reroute_022_3.Input
        y_rotation.links.new(reroute_023_2.outputs[0], reroute_022_3.inputs[0])
        #separate_xyz_001.X -> reroute_023_2.Input
        y_rotation.links.new(separate_xyz_001.outputs[0], reroute_023_2.inputs[0])
        #reroute_023_2.Output -> reroute_020_3.Input
        y_rotation.links.new(reroute_023_2.outputs[0], reroute_020_3.inputs[0])
        #reroute_018_3.Output -> reroute_024_3.Input
        y_rotation.links.new(reroute_018_3.outputs[0], reroute_024_3.inputs[0])
        #sine_003.Value -> reroute_026_2.Input
        y_rotation.links.new(sine_003.outputs[0], reroute_026_2.inputs[0])
        #sine_002.Value -> reroute_027_2.Input
        y_rotation.links.new(sine_002.outputs[0], reroute_027_2.inputs[0])
        #math_002.Value -> reroute_028_2.Input
        y_rotation.links.new(math_002.outputs[0], reroute_028_2.inputs[0])
        #reroute_028_2.Output -> reroute_030_1.Input
        y_rotation.links.new(reroute_028_2.outputs[0], reroute_030_1.inputs[0])
        #reroute_030_1.Output -> reroute_031_1.Input
        y_rotation.links.new(reroute_030_1.outputs[0], reroute_031_1.inputs[0])
        #reroute_031_1.Output -> reroute_032_1.Input
        y_rotation.links.new(reroute_031_1.outputs[0], reroute_032_1.inputs[0])
        #reroute_032_1.Output -> reroute_033_1.Input
        y_rotation.links.new(reroute_032_1.outputs[0], reroute_033_1.inputs[0])
        #math_003.Value -> reroute_034_1.Input
        y_rotation.links.new(math_003.outputs[0], reroute_034_1.inputs[0])
        #reroute_034_1.Output -> reroute_035_1.Input
        y_rotation.links.new(reroute_034_1.outputs[0], reroute_035_1.inputs[0])
        #group_input_5.Vector -> reroute_036_1.Input
        y_rotation.links.new(group_input_5.outputs[1], reroute_036_1.inputs[0])
        #group_input_5.Angle -> reroute_037_1.Input
        y_rotation.links.new(group_input_5.outputs[0], reroute_037_1.inputs[0])
        #reroute_037_1.Output -> reroute_038_1.Input
        y_rotation.links.new(reroute_037_1.outputs[0], reroute_038_1.inputs[0])
        #reroute_029_1.Output -> reroute_039_1.Input
        y_rotation.links.new(reroute_029_1.outputs[0], reroute_039_1.inputs[0])
        #reroute_036_1.Output -> reroute_029_1.Input
        y_rotation.links.new(reroute_036_1.outputs[0], reroute_029_1.inputs[0])
        #reroute_039_1.Output -> reroute_040_1.Input
        y_rotation.links.new(reroute_039_1.outputs[0], reroute_040_1.inputs[0])
        #reroute_5.Output -> combine_xyz_001.Y
        y_rotation.links.new(reroute_5.outputs[0], combine_xyz_001.inputs[1])
        #reroute_001_5.Output -> combine_xyz_001.Z
        y_rotation.links.new(reroute_001_5.outputs[0], combine_xyz_001.inputs[2])
        #separate_xyz_001.Y -> reroute_017_2.Input
        y_rotation.links.new(separate_xyz_001.outputs[1], reroute_017_2.inputs[0])
        #separate_xyz_001.Z -> reroute_025_3.Input
        y_rotation.links.new(separate_xyz_001.outputs[2], reroute_025_3.inputs[0])
        return y_rotation

    y_rotation = y_rotation_node_group()

    #initialize X Rotation node group
    def x_rotation_node_group():

        x_rotation = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "X Rotation")

        x_rotation.color_tag = 'NONE'
        x_rotation.description = ""
        x_rotation.default_group_node_width = 140
        

        #x_rotation interface
        #Socket Vector
        vector_socket_3 = x_rotation.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_3.default_value = (0.0, 0.0, 0.0)
        vector_socket_3.min_value = 0.0
        vector_socket_3.max_value = 0.0
        vector_socket_3.subtype = 'NONE'
        vector_socket_3.attribute_domain = 'POINT'

        #Socket Angle
        angle_socket_1 = x_rotation.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
        angle_socket_1.default_value = 0.0
        angle_socket_1.min_value = -3.4028234663852886e+38
        angle_socket_1.max_value = 3.4028234663852886e+38
        angle_socket_1.subtype = 'NONE'
        angle_socket_1.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_4 = x_rotation.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_4.default_value = (0.0, 0.0, 0.0)
        vector_socket_4.min_value = -3.4028234663852886e+38
        vector_socket_4.max_value = 3.4028234663852886e+38
        vector_socket_4.subtype = 'NONE'
        vector_socket_4.attribute_domain = 'POINT'


        #initialize x_rotation nodes
        #node Author.001
        author_001_2 = x_rotation.nodes.new("NodeFrame")
        author_001_2.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_001_2.name = "Author.001"
        author_001_2.use_custom_color = True
        author_001_2.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_001_2.label_size = 16
        author_001_2.shrink = True

        #node Author
        author_4 = x_rotation.nodes.new("NodeFrame")
        author_4.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_4.name = "Author"
        author_4.use_custom_color = True
        author_4.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_4.label_size = 16
        author_4.shrink = True

        #node Add
        add = x_rotation.nodes.new("ShaderNodeMath")
        add.name = "Add"
        add.operation = 'ADD'
        add.use_clamp = False

        #node Multiply 4
        multiply_4 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_4.name = "Multiply 4"
        multiply_4.operation = 'MULTIPLY'
        multiply_4.use_clamp = False

        #node Multiply 3
        multiply_3 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_3.name = "Multiply 3"
        multiply_3.operation = 'MULTIPLY'
        multiply_3.use_clamp = False

        #node Multiply 1
        multiply_1 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_1.name = "Multiply 1"
        multiply_1.operation = 'MULTIPLY'
        multiply_1.use_clamp = False

        #node Sine.001
        sine_001 = x_rotation.nodes.new("ShaderNodeMath")
        sine_001.name = "Sine.001"
        sine_001.operation = 'SINE'
        sine_001.use_clamp = False
        sine_001.inputs[1].hide = True

        #node Cosine
        cosine = x_rotation.nodes.new("ShaderNodeMath")
        cosine.name = "Cosine"
        cosine.operation = 'COSINE'
        cosine.use_clamp = False
        cosine.inputs[1].hide = True

        #node Cosine.001
        cosine_001 = x_rotation.nodes.new("ShaderNodeMath")
        cosine_001.name = "Cosine.001"
        cosine_001.operation = 'COSINE'
        cosine_001.use_clamp = False
        cosine_001.inputs[1].hide = True

        #node Math.001
        math_001_3 = x_rotation.nodes.new("ShaderNodeMath")
        math_001_3.name = "Math.001"
        math_001_3.operation = 'DIVIDE'
        math_001_3.use_clamp = False
        #Value_001
        math_001_3.inputs[1].default_value = 180.0

        #node Separate XYZ
        separate_xyz = x_rotation.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"
        #Vector
        separate_xyz.inputs[0].default_value = (0.0, 0.0, 0.0)

        #node Subtract
        subtract = x_rotation.nodes.new("ShaderNodeMath")
        subtract.name = "Subtract"
        subtract.operation = 'SUBTRACT'
        subtract.use_clamp = False

        #node Multiply 2
        multiply_2 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_2.name = "Multiply 2"
        multiply_2.operation = 'MULTIPLY'
        multiply_2.use_clamp = False

        #node Sine
        sine = x_rotation.nodes.new("ShaderNodeMath")
        sine.name = "Sine"
        sine.operation = 'SINE'
        sine.use_clamp = False
        sine.inputs[1].hide = True

        #node Combine XYZ
        combine_xyz = x_rotation.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz.name = "Combine XYZ"

        #node Math
        math_4 = x_rotation.nodes.new("ShaderNodeMath")
        math_4.name = "Math"
        math_4.operation = 'MULTIPLY'
        math_4.use_clamp = False
        #Value
        math_4.inputs[0].default_value = 0.5
        #Value_001
        math_4.inputs[1].default_value = -3.1419999599456787

        #node Add.001
        add_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        add_001_1.name = "Add.001"
        add_001_1.operation = 'ADD'
        add_001_1.use_clamp = False

        #node Reroute.033
        reroute_033_2 = x_rotation.nodes.new("NodeReroute")
        reroute_033_2.name = "Reroute.033"
        reroute_033_2.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_4 = x_rotation.nodes.new("NodeReroute")
        reroute_016_4.name = "Reroute.016"
        reroute_016_4.socket_idname = "NodeSocketFloat"
        #node Group Output
        group_output_6 = x_rotation.nodes.new("NodeGroupOutput")
        group_output_6.name = "Group Output"
        group_output_6.use_custom_color = True
        group_output_6.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_6.is_active_output = True

        #node Reroute.005
        reroute_005_5 = x_rotation.nodes.new("NodeReroute")
        reroute_005_5.name = "Reroute.005"
        reroute_005_5.socket_idname = "NodeSocketFloat"
        #node Multiply 3.001
        multiply_3_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_3_001_1.name = "Multiply 3.001"
        multiply_3_001_1.operation = 'MULTIPLY'
        multiply_3_001_1.use_clamp = False

        #node Cosine.002
        cosine_002_1 = x_rotation.nodes.new("ShaderNodeMath")
        cosine_002_1.name = "Cosine.002"
        cosine_002_1.operation = 'COSINE'
        cosine_002_1.use_clamp = False
        cosine_002_1.inputs[1].hide = True

        #node Sine.002
        sine_002_1 = x_rotation.nodes.new("ShaderNodeMath")
        sine_002_1.name = "Sine.002"
        sine_002_1.operation = 'SINE'
        sine_002_1.use_clamp = False
        sine_002_1.inputs[1].hide = True

        #node Multiply 1.001
        multiply_1_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_1_001_1.name = "Multiply 1.001"
        multiply_1_001_1.operation = 'MULTIPLY'
        multiply_1_001_1.use_clamp = False

        #node Math.003
        math_003_1 = x_rotation.nodes.new("ShaderNodeMath")
        math_003_1.name = "Math.003"
        math_003_1.operation = 'MULTIPLY'
        math_003_1.use_clamp = False
        #Value_001
        math_003_1.inputs[1].default_value = -3.1419999599456787

        #node Reroute.037
        reroute_037_2 = x_rotation.nodes.new("NodeReroute")
        reroute_037_2.name = "Reroute.037"
        reroute_037_2.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_4 = x_rotation.nodes.new("NodeReroute")
        reroute_007_4.name = "Reroute.007"
        reroute_007_4.socket_idname = "NodeSocketFloat"
        #node Reroute.034
        reroute_034_2 = x_rotation.nodes.new("NodeReroute")
        reroute_034_2.name = "Reroute.034"
        reroute_034_2.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_6 = x_rotation.nodes.new("NodeReroute")
        reroute_001_6.name = "Reroute.001"
        reroute_001_6.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_4 = x_rotation.nodes.new("NodeReroute")
        reroute_020_4.name = "Reroute.020"
        reroute_020_4.socket_idname = "NodeSocketFloat"
        #node Reroute.030
        reroute_030_2 = x_rotation.nodes.new("NodeReroute")
        reroute_030_2.name = "Reroute.030"
        reroute_030_2.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_4 = x_rotation.nodes.new("NodeReroute")
        reroute_012_4.name = "Reroute.012"
        reroute_012_4.socket_idname = "NodeSocketFloat"
        #node Reroute.014
        reroute_014_4 = x_rotation.nodes.new("NodeReroute")
        reroute_014_4.name = "Reroute.014"
        reroute_014_4.socket_idname = "NodeSocketFloat"
        #node Separate XYZ.001
        separate_xyz_001_1 = x_rotation.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_001_1.name = "Separate XYZ.001"

        #node Reroute.029
        reroute_029_2 = x_rotation.nodes.new("NodeReroute")
        reroute_029_2.name = "Reroute.029"
        reroute_029_2.socket_idname = "NodeSocketVector"
        #node Reroute.019
        reroute_019_4 = x_rotation.nodes.new("NodeReroute")
        reroute_019_4.name = "Reroute.019"
        reroute_019_4.socket_idname = "NodeSocketFloat"
        #node Reroute.040
        reroute_040_2 = x_rotation.nodes.new("NodeReroute")
        reroute_040_2.name = "Reroute.040"
        reroute_040_2.socket_idname = "NodeSocketVector"
        #node Reroute.026
        reroute_026_3 = x_rotation.nodes.new("NodeReroute")
        reroute_026_3.name = "Reroute.026"
        reroute_026_3.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_5 = x_rotation.nodes.new("NodeReroute")
        reroute_010_5.name = "Reroute.010"
        reroute_010_5.socket_idname = "NodeSocketFloat"
        #node Math.002
        math_002_1 = x_rotation.nodes.new("ShaderNodeMath")
        math_002_1.name = "Math.002"
        math_002_1.operation = 'DIVIDE'
        math_002_1.use_clamp = False
        #Value_001
        math_002_1.inputs[1].default_value = 180.0

        #node Multiply 2.001
        multiply_2_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_2_001_1.name = "Multiply 2.001"
        multiply_2_001_1.operation = 'MULTIPLY'
        multiply_2_001_1.use_clamp = False

        #node Cosine.003
        cosine_003_1 = x_rotation.nodes.new("ShaderNodeMath")
        cosine_003_1.name = "Cosine.003"
        cosine_003_1.operation = 'COSINE'
        cosine_003_1.use_clamp = False
        cosine_003_1.inputs[1].hide = True

        #node Reroute.027
        reroute_027_3 = x_rotation.nodes.new("NodeReroute")
        reroute_027_3.name = "Reroute.027"
        reroute_027_3.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021_4 = x_rotation.nodes.new("NodeReroute")
        reroute_021_4.name = "Reroute.021"
        reroute_021_4.socket_idname = "NodeSocketFloat"
        #node Sine.003
        sine_003_1 = x_rotation.nodes.new("ShaderNodeMath")
        sine_003_1.name = "Sine.003"
        sine_003_1.operation = 'SINE'
        sine_003_1.use_clamp = False
        sine_003_1.inputs[1].hide = True

        #node Reroute.018
        reroute_018_4 = x_rotation.nodes.new("NodeReroute")
        reroute_018_4.name = "Reroute.018"
        reroute_018_4.socket_idname = "NodeSocketFloat"
        #node Reroute.038
        reroute_038_2 = x_rotation.nodes.new("NodeReroute")
        reroute_038_2.name = "Reroute.038"
        reroute_038_2.socket_idname = "NodeSocketFloat"
        #node Reroute.035
        reroute_035_2 = x_rotation.nodes.new("NodeReroute")
        reroute_035_2.name = "Reroute.035"
        reroute_035_2.socket_idname = "NodeSocketFloat"
        #node Subtract.001
        subtract_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        subtract_001_1.name = "Subtract.001"
        subtract_001_1.operation = 'SUBTRACT'
        subtract_001_1.use_clamp = False

        #node Reroute.032
        reroute_032_2 = x_rotation.nodes.new("NodeReroute")
        reroute_032_2.name = "Reroute.032"
        reroute_032_2.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_6 = x_rotation.nodes.new("NodeReroute")
        reroute_003_6.name = "Reroute.003"
        reroute_003_6.socket_idname = "NodeSocketFloat"
        #node Reroute.024
        reroute_024_4 = x_rotation.nodes.new("NodeReroute")
        reroute_024_4.name = "Reroute.024"
        reroute_024_4.socket_idname = "NodeSocketFloat"
        #node Reroute.025
        reroute_025_4 = x_rotation.nodes.new("NodeReroute")
        reroute_025_4.name = "Reroute.025"
        reroute_025_4.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_5 = x_rotation.nodes.new("NodeReroute")
        reroute_008_5.name = "Reroute.008"
        reroute_008_5.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_5 = x_rotation.nodes.new("NodeReroute")
        reroute_011_5.name = "Reroute.011"
        reroute_011_5.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022_4 = x_rotation.nodes.new("NodeReroute")
        reroute_022_4.name = "Reroute.022"
        reroute_022_4.socket_idname = "NodeSocketFloat"
        #node Reroute.036
        reroute_036_2 = x_rotation.nodes.new("NodeReroute")
        reroute_036_2.name = "Reroute.036"
        reroute_036_2.socket_idname = "NodeSocketVector"
        #node Multiply 4.001
        multiply_4_001_1 = x_rotation.nodes.new("ShaderNodeMath")
        multiply_4_001_1.name = "Multiply 4.001"
        multiply_4_001_1.operation = 'MULTIPLY'
        multiply_4_001_1.use_clamp = False

        #node Combine XYZ.001
        combine_xyz_001_1 = x_rotation.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_001_1.name = "Combine XYZ.001"

        #node Reroute.009
        reroute_009_5 = x_rotation.nodes.new("NodeReroute")
        reroute_009_5.name = "Reroute.009"
        reroute_009_5.socket_idname = "NodeSocketFloat"
        #node Reroute.028
        reroute_028_3 = x_rotation.nodes.new("NodeReroute")
        reroute_028_3.name = "Reroute.028"
        reroute_028_3.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_3 = x_rotation.nodes.new("NodeReroute")
        reroute_015_3.name = "Reroute.015"
        reroute_015_3.socket_idname = "NodeSocketFloat"
        #node Reroute.031
        reroute_031_2 = x_rotation.nodes.new("NodeReroute")
        reroute_031_2.name = "Reroute.031"
        reroute_031_2.socket_idname = "NodeSocketFloat"
        #node Reroute.039
        reroute_039_2 = x_rotation.nodes.new("NodeReroute")
        reroute_039_2.name = "Reroute.039"
        reroute_039_2.socket_idname = "NodeSocketVector"
        #node Group Input
        group_input_6 = x_rotation.nodes.new("NodeGroupInput")
        group_input_6.name = "Group Input"
        group_input_6.use_custom_color = True
        group_input_6.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)

        #node Reroute.006
        reroute_006_5 = x_rotation.nodes.new("NodeReroute")
        reroute_006_5.name = "Reroute.006"
        reroute_006_5.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_4 = x_rotation.nodes.new("NodeReroute")
        reroute_013_4.name = "Reroute.013"
        reroute_013_4.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_6 = x_rotation.nodes.new("NodeReroute")
        reroute_004_6.name = "Reroute.004"
        reroute_004_6.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_6 = x_rotation.nodes.new("NodeReroute")
        reroute_002_6.name = "Reroute.002"
        reroute_002_6.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_6 = x_rotation.nodes.new("NodeReroute")
        reroute_6.name = "Reroute"
        reroute_6.socket_idname = "NodeSocketFloat"
        #node Reroute.023
        reroute_023_3 = x_rotation.nodes.new("NodeReroute")
        reroute_023_3.name = "Reroute.023"
        reroute_023_3.socket_idname = "NodeSocketFloat"
        #node Reroute.017
        reroute_017_3 = x_rotation.nodes.new("NodeReroute")
        reroute_017_3.name = "Reroute.017"
        reroute_017_3.socket_idname = "NodeSocketFloat"

        #Set locations
        author_001_2.location = (-120.57717895507812, -78.8060073852539)
        author_4.location = (20.0, -1390.607177734375)
        add.location = (-260.0, -1470.607177734375)
        multiply_4.location = (-440.0, -1810.607177734375)
        multiply_3.location = (-440.0, -1630.607177734375)
        multiply_1.location = (-440.0, -1310.607177734375)
        sine_001.location = (-620.0, -1730.607177734375)
        cosine.location = (-620.0, -1870.607177734375)
        cosine_001.location = (-620.0, -1310.607177734375)
        math_001_3.location = (-800.0, -1310.607177734375)
        separate_xyz.location = (-620.0, -1450.607177734375)
        subtract.location = (-260.0, -1310.607177734375)
        multiply_2.location = (-440.0, -1470.607177734375)
        sine.location = (-620.0, -1590.607177734375)
        combine_xyz.location = (-80.0, -1310.607177734375)
        math_4.location = (-980.0, -1310.607177734375)
        add_001_1.location = (-420.0, -180.0)
        reroute_033_2.location = (-880.6915283203125, -735.1572265625)
        reroute_016_4.location = (-680.0, -475.9983825683594)
        group_output_6.location = (-40.57718276977539, 1.1939947605133057)
        reroute_005_5.location = (-440.0, -33.977020263671875)
        multiply_3_001_1.location = (-620.0, -360.0)
        cosine_002_1.location = (-860.0, 0.0)
        sine_002_1.location = (-860.0, -460.0)
        multiply_1_001_1.location = (-620.0, 0.0)
        math_003_1.location = (-1220.0, 0.0)
        reroute_037_2.location = (-1239.531494140625, -33.600643157958984)
        reroute_007_4.location = (-440.8663024902344, -316.9665222167969)
        reroute_034_2.location = (-1060.0, -34.880516052246094)
        reroute_001_6.location = (-240.0, -103.03995513916016)
        reroute_020_4.location = (-640.0, -136.5331573486328)
        reroute_030_2.location = (-880.0, -115.15725708007812)
        reroute_012_4.location = (-461.0945739746094, -395.0721130371094)
        reroute_014_4.location = (-700.0, -720.0)
        separate_xyz_001_1.location = (-860.0, -160.0)
        reroute_029_2.location = (-1260.0, -180.0)
        reroute_019_4.location = (-680.6915283203125, -294.5692138671875)
        reroute_040_2.location = (-900.0, -264.396240234375)
        reroute_026_3.location = (-680.6396484375, -334.69573974609375)
        reroute_010_5.location = (-440.0, -115.23310089111328)
        math_002_1.location = (-1040.0, 0.0)
        multiply_2_001_1.location = (-620.0, -180.0)
        cosine_003_1.location = (-860.0, -620.0)
        reroute_027_3.location = (-680.0202026367188, -494.8603515625)
        reroute_021_4.location = (-640.4331665039062, -34.36639404296875)
        sine_003_1.location = (-860.0, -300.0)
        reroute_018_4.location = (-659.5668334960938, -316.5331726074219)
        reroute_038_2.location = (-1240.0, -114.8805160522461)
        reroute_035_2.location = (-1060.0, -114.8805160522461)
        subtract_001_1.location = (-420.0, 0.0)
        reroute_032_2.location = (-879.3084716796875, -574.4654541015625)
        reroute_003_6.location = (-240.57717895507812, -34.31150436401367)
        reroute_024_4.location = (-660.0, -676.5408935546875)
        reroute_025_4.location = (-660.0, -237.86825561523438)
        reroute_008_5.location = (-460.0, -295.0721130371094)
        reroute_011_5.location = (-441.0945739746094, -214.52456665039062)
        reroute_022_4.location = (-640.0, -496.4483642578125)
        reroute_036_2.location = (-1258.42333984375, -55.520450592041016)
        multiply_4_001_1.location = (-620.0, -540.0)
        combine_xyz_001_1.location = (-220.57717895507812, 1.1939947605133057)
        reroute_009_5.location = (-440.0, -136.53317260742188)
        reroute_028_3.location = (-880.6396484375, -34.94972229003906)
        reroute_015_3.location = (-640.4331665039062, -115.23307800292969)
        reroute_031_2.location = (-880.0, -414.5282287597656)
        reroute_039_2.location = (-900.0, -180.0)
        group_input_6.location = (-1418.42333984375, 1.9198070764541626)
        reroute_006_5.location = (-260.5771789550781, -718.8060302734375)
        reroute_013_4.location = (-440.9365539550781, -576.7205810546875)
        reroute_004_6.location = (-240.57717895507812, -215.54827880859375)
        reroute_002_6.location = (-240.0, -81.30006408691406)
        reroute_6.location = (-260.0, -60.0)
        reroute_023_3.location = (-640.0, -217.04031372070312)
        reroute_017_3.location = (-700.0, -194.6725616455078)

        #Set dimensions
        author_001_2.width, author_001_2.height = 269.55352783203125, 30.0
        author_4.width, author_4.height = 269.55352783203125, 30.0
        add.width, add.height = 140.0, 100.0
        multiply_4.width, multiply_4.height = 140.0, 100.0
        multiply_3.width, multiply_3.height = 140.0, 100.0
        multiply_1.width, multiply_1.height = 140.0, 100.0
        sine_001.width, sine_001.height = 140.0, 100.0
        cosine.width, cosine.height = 140.0, 100.0
        cosine_001.width, cosine_001.height = 140.0, 100.0
        math_001_3.width, math_001_3.height = 140.0, 100.0
        separate_xyz.width, separate_xyz.height = 140.0, 100.0
        subtract.width, subtract.height = 140.0, 100.0
        multiply_2.width, multiply_2.height = 140.0, 100.0
        sine.width, sine.height = 140.0, 100.0
        combine_xyz.width, combine_xyz.height = 140.0, 100.0
        math_4.width, math_4.height = 140.0, 100.0
        add_001_1.width, add_001_1.height = 140.0, 100.0
        reroute_033_2.width, reroute_033_2.height = 16.0, 100.0
        reroute_016_4.width, reroute_016_4.height = 16.0, 100.0
        group_output_6.width, group_output_6.height = 140.0, 100.0
        reroute_005_5.width, reroute_005_5.height = 16.0, 100.0
        multiply_3_001_1.width, multiply_3_001_1.height = 140.0, 100.0
        cosine_002_1.width, cosine_002_1.height = 140.0, 100.0
        sine_002_1.width, sine_002_1.height = 140.0, 100.0
        multiply_1_001_1.width, multiply_1_001_1.height = 140.0, 100.0
        math_003_1.width, math_003_1.height = 140.0, 100.0
        reroute_037_2.width, reroute_037_2.height = 16.0, 100.0
        reroute_007_4.width, reroute_007_4.height = 16.0, 100.0
        reroute_034_2.width, reroute_034_2.height = 16.0, 100.0
        reroute_001_6.width, reroute_001_6.height = 16.0, 100.0
        reroute_020_4.width, reroute_020_4.height = 16.0, 100.0
        reroute_030_2.width, reroute_030_2.height = 16.0, 100.0
        reroute_012_4.width, reroute_012_4.height = 16.0, 100.0
        reroute_014_4.width, reroute_014_4.height = 16.0, 100.0
        separate_xyz_001_1.width, separate_xyz_001_1.height = 140.0, 100.0
        reroute_029_2.width, reroute_029_2.height = 16.0, 100.0
        reroute_019_4.width, reroute_019_4.height = 16.0, 100.0
        reroute_040_2.width, reroute_040_2.height = 16.0, 100.0
        reroute_026_3.width, reroute_026_3.height = 16.0, 100.0
        reroute_010_5.width, reroute_010_5.height = 16.0, 100.0
        math_002_1.width, math_002_1.height = 140.0, 100.0
        multiply_2_001_1.width, multiply_2_001_1.height = 140.0, 100.0
        cosine_003_1.width, cosine_003_1.height = 140.0, 100.0
        reroute_027_3.width, reroute_027_3.height = 16.0, 100.0
        reroute_021_4.width, reroute_021_4.height = 16.0, 100.0
        sine_003_1.width, sine_003_1.height = 140.0, 100.0
        reroute_018_4.width, reroute_018_4.height = 16.0, 100.0
        reroute_038_2.width, reroute_038_2.height = 16.0, 100.0
        reroute_035_2.width, reroute_035_2.height = 16.0, 100.0
        subtract_001_1.width, subtract_001_1.height = 140.0, 100.0
        reroute_032_2.width, reroute_032_2.height = 16.0, 100.0
        reroute_003_6.width, reroute_003_6.height = 16.0, 100.0
        reroute_024_4.width, reroute_024_4.height = 16.0, 100.0
        reroute_025_4.width, reroute_025_4.height = 16.0, 100.0
        reroute_008_5.width, reroute_008_5.height = 16.0, 100.0
        reroute_011_5.width, reroute_011_5.height = 16.0, 100.0
        reroute_022_4.width, reroute_022_4.height = 16.0, 100.0
        reroute_036_2.width, reroute_036_2.height = 16.0, 100.0
        multiply_4_001_1.width, multiply_4_001_1.height = 140.0, 100.0
        combine_xyz_001_1.width, combine_xyz_001_1.height = 140.0, 100.0
        reroute_009_5.width, reroute_009_5.height = 16.0, 100.0
        reroute_028_3.width, reroute_028_3.height = 16.0, 100.0
        reroute_015_3.width, reroute_015_3.height = 16.0, 100.0
        reroute_031_2.width, reroute_031_2.height = 16.0, 100.0
        reroute_039_2.width, reroute_039_2.height = 16.0, 100.0
        group_input_6.width, group_input_6.height = 140.0, 100.0
        reroute_006_5.width, reroute_006_5.height = 16.0, 100.0
        reroute_013_4.width, reroute_013_4.height = 16.0, 100.0
        reroute_004_6.width, reroute_004_6.height = 16.0, 100.0
        reroute_002_6.width, reroute_002_6.height = 16.0, 100.0
        reroute_6.width, reroute_6.height = 16.0, 100.0
        reroute_023_3.width, reroute_023_3.height = 16.0, 100.0
        reroute_017_3.width, reroute_017_3.height = 16.0, 100.0

        #initialize x_rotation links
        #math_001_3.Value -> sine.Value
        x_rotation.links.new(math_001_3.outputs[0], sine.inputs[0])
        #math_001_3.Value -> cosine.Value
        x_rotation.links.new(math_001_3.outputs[0], cosine.inputs[0])
        #separate_xyz.Y -> multiply_1.Value
        x_rotation.links.new(separate_xyz.outputs[1], multiply_1.inputs[1])
        #sine.Value -> multiply_2.Value
        x_rotation.links.new(sine.outputs[0], multiply_2.inputs[0])
        #separate_xyz.Z -> multiply_2.Value
        x_rotation.links.new(separate_xyz.outputs[2], multiply_2.inputs[1])
        #multiply_1.Value -> subtract.Value
        x_rotation.links.new(multiply_1.outputs[0], subtract.inputs[0])
        #multiply_2.Value -> subtract.Value
        x_rotation.links.new(multiply_2.outputs[0], subtract.inputs[1])
        #separate_xyz.Y -> multiply_3.Value
        x_rotation.links.new(separate_xyz.outputs[1], multiply_3.inputs[1])
        #cosine.Value -> multiply_4.Value
        x_rotation.links.new(cosine.outputs[0], multiply_4.inputs[0])
        #separate_xyz.Z -> multiply_4.Value
        x_rotation.links.new(separate_xyz.outputs[2], multiply_4.inputs[1])
        #multiply_3.Value -> add.Value
        x_rotation.links.new(multiply_3.outputs[0], add.inputs[0])
        #multiply_4.Value -> add.Value
        x_rotation.links.new(multiply_4.outputs[0], add.inputs[1])
        #math_4.Value -> math_001_3.Value
        x_rotation.links.new(math_4.outputs[0], math_001_3.inputs[0])
        #math_001_3.Value -> sine_001.Value
        x_rotation.links.new(math_001_3.outputs[0], sine_001.inputs[0])
        #sine_001.Value -> multiply_3.Value
        x_rotation.links.new(sine_001.outputs[0], multiply_3.inputs[0])
        #math_001_3.Value -> cosine_001.Value
        x_rotation.links.new(math_001_3.outputs[0], cosine_001.inputs[0])
        #cosine_001.Value -> multiply_1.Value
        x_rotation.links.new(cosine_001.outputs[0], multiply_1.inputs[0])
        #add.Value -> combine_xyz.Z
        x_rotation.links.new(add.outputs[0], combine_xyz.inputs[2])
        #separate_xyz.X -> combine_xyz.X
        x_rotation.links.new(separate_xyz.outputs[0], combine_xyz.inputs[0])
        #subtract.Value -> combine_xyz.Y
        x_rotation.links.new(subtract.outputs[0], combine_xyz.inputs[1])
        #reroute_040_2.Output -> separate_xyz_001_1.Vector
        x_rotation.links.new(reroute_040_2.outputs[0], separate_xyz_001_1.inputs[0])
        #reroute_031_2.Output -> sine_003_1.Value
        x_rotation.links.new(reroute_031_2.outputs[0], sine_003_1.inputs[0])
        #reroute_033_2.Output -> cosine_003_1.Value
        x_rotation.links.new(reroute_033_2.outputs[0], cosine_003_1.inputs[0])
        #reroute_020_4.Output -> multiply_1_001_1.Value
        x_rotation.links.new(reroute_020_4.outputs[0], multiply_1_001_1.inputs[1])
        #reroute_019_4.Output -> multiply_2_001_1.Value
        x_rotation.links.new(reroute_019_4.outputs[0], multiply_2_001_1.inputs[0])
        #reroute_018_4.Output -> multiply_2_001_1.Value
        x_rotation.links.new(reroute_018_4.outputs[0], multiply_2_001_1.inputs[1])
        #reroute_010_5.Output -> subtract_001_1.Value
        x_rotation.links.new(reroute_010_5.outputs[0], subtract_001_1.inputs[0])
        #reroute_009_5.Output -> subtract_001_1.Value
        x_rotation.links.new(reroute_009_5.outputs[0], subtract_001_1.inputs[1])
        #reroute_022_4.Output -> multiply_3_001_1.Value
        x_rotation.links.new(reroute_022_4.outputs[0], multiply_3_001_1.inputs[1])
        #cosine_003_1.Value -> multiply_4_001_1.Value
        x_rotation.links.new(cosine_003_1.outputs[0], multiply_4_001_1.inputs[0])
        #reroute_024_4.Output -> multiply_4_001_1.Value
        x_rotation.links.new(reroute_024_4.outputs[0], multiply_4_001_1.inputs[1])
        #reroute_008_5.Output -> add_001_1.Value
        x_rotation.links.new(reroute_008_5.outputs[0], add_001_1.inputs[0])
        #reroute_007_4.Output -> add_001_1.Value
        x_rotation.links.new(reroute_007_4.outputs[0], add_001_1.inputs[1])
        #combine_xyz_001_1.Vector -> group_output_6.Vector
        x_rotation.links.new(combine_xyz_001_1.outputs[0], group_output_6.inputs[0])
        #reroute_035_2.Output -> math_002_1.Value
        x_rotation.links.new(reroute_035_2.outputs[0], math_002_1.inputs[0])
        #reroute_038_2.Output -> math_003_1.Value
        x_rotation.links.new(reroute_038_2.outputs[0], math_003_1.inputs[0])
        #reroute_032_2.Output -> sine_002_1.Value
        x_rotation.links.new(reroute_032_2.outputs[0], sine_002_1.inputs[0])
        #reroute_016_4.Output -> multiply_3_001_1.Value
        x_rotation.links.new(reroute_016_4.outputs[0], multiply_3_001_1.inputs[0])
        #reroute_030_2.Output -> cosine_002_1.Value
        x_rotation.links.new(reroute_030_2.outputs[0], cosine_002_1.inputs[0])
        #reroute_015_3.Output -> multiply_1_001_1.Value
        x_rotation.links.new(reroute_015_3.outputs[0], multiply_1_001_1.inputs[0])
        #reroute_006_5.Output -> reroute_6.Input
        x_rotation.links.new(reroute_006_5.outputs[0], reroute_6.inputs[0])
        #reroute_004_6.Output -> reroute_001_6.Input
        x_rotation.links.new(reroute_004_6.outputs[0], reroute_001_6.inputs[0])
        #reroute_003_6.Output -> reroute_002_6.Input
        x_rotation.links.new(reroute_003_6.outputs[0], reroute_002_6.inputs[0])
        #subtract_001_1.Value -> reroute_003_6.Input
        x_rotation.links.new(subtract_001_1.outputs[0], reroute_003_6.inputs[0])
        #add_001_1.Value -> reroute_004_6.Input
        x_rotation.links.new(add_001_1.outputs[0], reroute_004_6.inputs[0])
        #reroute_014_4.Output -> reroute_006_5.Input
        x_rotation.links.new(reroute_014_4.outputs[0], reroute_006_5.inputs[0])
        #reroute_013_4.Output -> reroute_007_4.Input
        x_rotation.links.new(reroute_013_4.outputs[0], reroute_007_4.inputs[0])
        #reroute_012_4.Output -> reroute_008_5.Input
        x_rotation.links.new(reroute_012_4.outputs[0], reroute_008_5.inputs[0])
        #reroute_011_5.Output -> reroute_009_5.Input
        x_rotation.links.new(reroute_011_5.outputs[0], reroute_009_5.inputs[0])
        #reroute_005_5.Output -> reroute_010_5.Input
        x_rotation.links.new(reroute_005_5.outputs[0], reroute_010_5.inputs[0])
        #multiply_1_001_1.Value -> reroute_005_5.Input
        x_rotation.links.new(multiply_1_001_1.outputs[0], reroute_005_5.inputs[0])
        #multiply_2_001_1.Value -> reroute_011_5.Input
        x_rotation.links.new(multiply_2_001_1.outputs[0], reroute_011_5.inputs[0])
        #multiply_3_001_1.Value -> reroute_012_4.Input
        x_rotation.links.new(multiply_3_001_1.outputs[0], reroute_012_4.inputs[0])
        #multiply_4_001_1.Value -> reroute_013_4.Input
        x_rotation.links.new(multiply_4_001_1.outputs[0], reroute_013_4.inputs[0])
        #reroute_017_3.Output -> reroute_014_4.Input
        x_rotation.links.new(reroute_017_3.outputs[0], reroute_014_4.inputs[0])
        #reroute_021_4.Output -> reroute_015_3.Input
        x_rotation.links.new(reroute_021_4.outputs[0], reroute_015_3.inputs[0])
        #reroute_027_3.Output -> reroute_016_4.Input
        x_rotation.links.new(reroute_027_3.outputs[0], reroute_016_4.inputs[0])
        #reroute_025_4.Output -> reroute_018_4.Input
        x_rotation.links.new(reroute_025_4.outputs[0], reroute_018_4.inputs[0])
        #reroute_026_3.Output -> reroute_019_4.Input
        x_rotation.links.new(reroute_026_3.outputs[0], reroute_019_4.inputs[0])
        #cosine_002_1.Value -> reroute_021_4.Input
        x_rotation.links.new(cosine_002_1.outputs[0], reroute_021_4.inputs[0])
        #reroute_023_3.Output -> reroute_022_4.Input
        x_rotation.links.new(reroute_023_3.outputs[0], reroute_022_4.inputs[0])
        #reroute_023_3.Output -> reroute_020_4.Input
        x_rotation.links.new(reroute_023_3.outputs[0], reroute_020_4.inputs[0])
        #reroute_018_4.Output -> reroute_024_4.Input
        x_rotation.links.new(reroute_018_4.outputs[0], reroute_024_4.inputs[0])
        #sine_003_1.Value -> reroute_026_3.Input
        x_rotation.links.new(sine_003_1.outputs[0], reroute_026_3.inputs[0])
        #sine_002_1.Value -> reroute_027_3.Input
        x_rotation.links.new(sine_002_1.outputs[0], reroute_027_3.inputs[0])
        #math_002_1.Value -> reroute_028_3.Input
        x_rotation.links.new(math_002_1.outputs[0], reroute_028_3.inputs[0])
        #reroute_028_3.Output -> reroute_030_2.Input
        x_rotation.links.new(reroute_028_3.outputs[0], reroute_030_2.inputs[0])
        #reroute_030_2.Output -> reroute_031_2.Input
        x_rotation.links.new(reroute_030_2.outputs[0], reroute_031_2.inputs[0])
        #reroute_031_2.Output -> reroute_032_2.Input
        x_rotation.links.new(reroute_031_2.outputs[0], reroute_032_2.inputs[0])
        #reroute_032_2.Output -> reroute_033_2.Input
        x_rotation.links.new(reroute_032_2.outputs[0], reroute_033_2.inputs[0])
        #math_003_1.Value -> reroute_034_2.Input
        x_rotation.links.new(math_003_1.outputs[0], reroute_034_2.inputs[0])
        #reroute_034_2.Output -> reroute_035_2.Input
        x_rotation.links.new(reroute_034_2.outputs[0], reroute_035_2.inputs[0])
        #group_input_6.Vector -> reroute_036_2.Input
        x_rotation.links.new(group_input_6.outputs[1], reroute_036_2.inputs[0])
        #group_input_6.Angle -> reroute_037_2.Input
        x_rotation.links.new(group_input_6.outputs[0], reroute_037_2.inputs[0])
        #reroute_037_2.Output -> reroute_038_2.Input
        x_rotation.links.new(reroute_037_2.outputs[0], reroute_038_2.inputs[0])
        #reroute_029_2.Output -> reroute_039_2.Input
        x_rotation.links.new(reroute_029_2.outputs[0], reroute_039_2.inputs[0])
        #reroute_036_2.Output -> reroute_029_2.Input
        x_rotation.links.new(reroute_036_2.outputs[0], reroute_029_2.inputs[0])
        #reroute_039_2.Output -> reroute_040_2.Input
        x_rotation.links.new(reroute_039_2.outputs[0], reroute_040_2.inputs[0])
        #reroute_001_6.Output -> combine_xyz_001_1.Z
        x_rotation.links.new(reroute_001_6.outputs[0], combine_xyz_001_1.inputs[2])
        #separate_xyz_001_1.Z -> reroute_025_4.Input
        x_rotation.links.new(separate_xyz_001_1.outputs[2], reroute_025_4.inputs[0])
        #separate_xyz_001_1.X -> reroute_017_3.Input
        x_rotation.links.new(separate_xyz_001_1.outputs[0], reroute_017_3.inputs[0])
        #separate_xyz_001_1.Y -> reroute_023_3.Input
        x_rotation.links.new(separate_xyz_001_1.outputs[1], reroute_023_3.inputs[0])
        #reroute_6.Output -> combine_xyz_001_1.X
        x_rotation.links.new(reroute_6.outputs[0], combine_xyz_001_1.inputs[0])
        #reroute_002_6.Output -> combine_xyz_001_1.Y
        x_rotation.links.new(reroute_002_6.outputs[0], combine_xyz_001_1.inputs[1])
        return x_rotation

    x_rotation = x_rotation_node_group()

    #initialize Translate.001 node group
    def translate_001_node_group():

        translate_001 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Translate.001")

        translate_001.color_tag = 'NONE'
        translate_001.description = ""
        translate_001.default_group_node_width = 140
        

        #translate_001 interface
        #Socket Vector
        vector_socket_5 = translate_001.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_5.default_value = (0.0, 0.0, 0.0)
        vector_socket_5.min_value = 0.0
        vector_socket_5.max_value = 0.0
        vector_socket_5.subtype = 'NONE'
        vector_socket_5.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_6 = translate_001.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_6.default_value = (0.0, 0.0, 0.0)
        vector_socket_6.min_value = -10000.0
        vector_socket_6.max_value = 10000.0
        vector_socket_6.subtype = 'NONE'
        vector_socket_6.attribute_domain = 'POINT'

        #Socket X
        x_socket = translate_001.interface.new_socket(name = "X", in_out='INPUT', socket_type = 'NodeSocketFloat')
        x_socket.default_value = 0.0
        x_socket.min_value = -10000.0
        x_socket.max_value = 10000.0
        x_socket.subtype = 'NONE'
        x_socket.attribute_domain = 'POINT'

        #Socket Y
        y_socket = translate_001.interface.new_socket(name = "Y", in_out='INPUT', socket_type = 'NodeSocketFloat')
        y_socket.default_value = 0.0
        y_socket.min_value = -10000.0
        y_socket.max_value = 10000.0
        y_socket.subtype = 'NONE'
        y_socket.attribute_domain = 'POINT'

        #Socket Z
        z_socket = translate_001.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
        z_socket.default_value = 0.0
        z_socket.min_value = -10000.0
        z_socket.max_value = 10000.0
        z_socket.subtype = 'NONE'
        z_socket.attribute_domain = 'POINT'


        #initialize translate_001 nodes
        #node Author
        author_5 = translate_001.nodes.new("NodeFrame")
        author_5.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_5.name = "Author"
        author_5.use_custom_color = True
        author_5.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_5.label_size = 16
        author_5.shrink = True

        #node Group Output
        group_output_7 = translate_001.nodes.new("NodeGroupOutput")
        group_output_7.name = "Group Output"
        group_output_7.use_custom_color = True
        group_output_7.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_7.is_active_output = True

        #node Combine XYZ.001
        combine_xyz_001_2 = translate_001.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_001_2.name = "Combine XYZ.001"

        #node Reroute.002
        reroute_002_7 = translate_001.nodes.new("NodeReroute")
        reroute_002_7.name = "Reroute.002"
        reroute_002_7.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_7 = translate_001.nodes.new("NodeReroute")
        reroute_001_7.name = "Reroute.001"
        reroute_001_7.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_7 = translate_001.nodes.new("NodeReroute")
        reroute_7.name = "Reroute"
        reroute_7.socket_idname = "NodeSocketFloat"
        #node Reroute.005
        reroute_005_6 = translate_001.nodes.new("NodeReroute")
        reroute_005_6.name = "Reroute.005"
        reroute_005_6.socket_idname = "NodeSocketFloat"
        #node Math.019
        math_019 = translate_001.nodes.new("ShaderNodeMath")
        math_019.name = "Math.019"
        math_019.operation = 'ADD'
        math_019.use_clamp = False

        #node Math.021
        math_021 = translate_001.nodes.new("ShaderNodeMath")
        math_021.name = "Math.021"
        math_021.operation = 'ADD'
        math_021.use_clamp = False

        #node Math.022
        math_022 = translate_001.nodes.new("ShaderNodeMath")
        math_022.name = "Math.022"
        math_022.operation = 'ADD'
        math_022.use_clamp = False

        #node Reroute.003
        reroute_003_7 = translate_001.nodes.new("NodeReroute")
        reroute_003_7.name = "Reroute.003"
        reroute_003_7.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_7 = translate_001.nodes.new("NodeReroute")
        reroute_004_7.name = "Reroute.004"
        reroute_004_7.socket_idname = "NodeSocketFloat"
        #node Separate XYZ
        separate_xyz_1 = translate_001.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_1.name = "Separate XYZ"

        #node Reroute.010
        reroute_010_6 = translate_001.nodes.new("NodeReroute")
        reroute_010_6.name = "Reroute.010"
        reroute_010_6.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_5 = translate_001.nodes.new("NodeReroute")
        reroute_012_5.name = "Reroute.012"
        reroute_012_5.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_5 = translate_001.nodes.new("NodeReroute")
        reroute_007_5.name = "Reroute.007"
        reroute_007_5.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_5 = translate_001.nodes.new("NodeReroute")
        reroute_013_5.name = "Reroute.013"
        reroute_013_5.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_6 = translate_001.nodes.new("NodeReroute")
        reroute_011_6.name = "Reroute.011"
        reroute_011_6.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_4 = translate_001.nodes.new("NodeReroute")
        reroute_015_4.name = "Reroute.015"
        reroute_015_4.socket_idname = "NodeSocketVector"
        #node Reroute.014
        reroute_014_5 = translate_001.nodes.new("NodeReroute")
        reroute_014_5.name = "Reroute.014"
        reroute_014_5.socket_idname = "NodeSocketFloat"
        #node Reroute.009
        reroute_009_6 = translate_001.nodes.new("NodeReroute")
        reroute_009_6.name = "Reroute.009"
        reroute_009_6.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_5 = translate_001.nodes.new("NodeReroute")
        reroute_020_5.name = "Reroute.020"
        reroute_020_5.socket_idname = "NodeSocketVector"
        #node Reroute.021
        reroute_021_5 = translate_001.nodes.new("NodeReroute")
        reroute_021_5.name = "Reroute.021"
        reroute_021_5.socket_idname = "NodeSocketFloat"
        #node Reroute.023
        reroute_023_4 = translate_001.nodes.new("NodeReroute")
        reroute_023_4.name = "Reroute.023"
        reroute_023_4.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_5 = translate_001.nodes.new("NodeReroute")
        reroute_016_5.name = "Reroute.016"
        reroute_016_5.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022_5 = translate_001.nodes.new("NodeReroute")
        reroute_022_5.name = "Reroute.022"
        reroute_022_5.socket_idname = "NodeSocketFloat"
        #node Reroute.017
        reroute_017_4 = translate_001.nodes.new("NodeReroute")
        reroute_017_4.name = "Reroute.017"
        reroute_017_4.socket_idname = "NodeSocketFloat"
        #node Reroute.018
        reroute_018_5 = translate_001.nodes.new("NodeReroute")
        reroute_018_5.name = "Reroute.018"
        reroute_018_5.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_6 = translate_001.nodes.new("NodeReroute")
        reroute_008_6.name = "Reroute.008"
        reroute_008_6.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_6 = translate_001.nodes.new("NodeReroute")
        reroute_006_6.name = "Reroute.006"
        reroute_006_6.socket_idname = "NodeSocketFloat"
        #node Group Input
        group_input_7 = translate_001.nodes.new("NodeGroupInput")
        group_input_7.name = "Group Input"
        group_input_7.use_custom_color = True
        group_input_7.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)

        #node Reroute.019
        reroute_019_5 = translate_001.nodes.new("NodeReroute")
        reroute_019_5.name = "Reroute.019"
        reroute_019_5.socket_idname = "NodeSocketFloat"

        #Set locations
        author_5.location = (-100.0, -80.0)
        group_output_7.location = (0.0, 0.0)
        combine_xyz_001_2.location = (-180.0, 0.0)
        reroute_002_7.location = (-200.0, -60.0)
        reroute_001_7.location = (-220.50624084472656, -82.53238677978516)
        reroute_7.location = (-200.0, -105.06477355957031)
        reroute_005_6.location = (-200.0, -394.4287414550781)
        math_019.location = (-380.0, 0.0)
        math_021.location = (-380.0, -180.0)
        math_022.location = (-380.0, -360.0)
        reroute_003_7.location = (-199.49375915527344, -35.44170379638672)
        reroute_004_7.location = (-221.01248168945312, -215.44171142578125)
        separate_xyz_1.location = (-600.0, 0.0)
        reroute_010_6.location = (-418.816650390625, -294.67254638671875)
        reroute_012_5.location = (-419.9576416015625, -57.040306091308594)
        reroute_007_5.location = (-399.4083251953125, -34.67254638671875)
        reroute_013_5.location = (-440.0, -80.0)
        reroute_011_6.location = (-400.0, -114.97219848632812)
        reroute_015_4.location = (-620.0, -104.15092468261719)
        reroute_014_5.location = (-640.0, -136.5408935546875)
        reroute_009_6.location = (-440.0, -474.5490417480469)
        reroute_020_5.location = (-620.0, -34.21036911010742)
        reroute_021_5.location = (-640.5916748046875, -57.288333892822266)
        reroute_023_4.location = (-660.0, -160.0)
        reroute_016_5.location = (-460.0, -160.0)
        reroute_022_5.location = (-460.0, -316.4483642578125)
        reroute_017_4.location = (-480.0, -497.6322326660156)
        reroute_018_5.location = (-480.0, -180.0)
        reroute_008_6.location = (-680.0, -180.0)
        reroute_006_6.location = (-680.0, -100.0)
        group_input_7.location = (-840.0, 0.0)
        reroute_019_5.location = (-660.0, -78.22418212890625)

        #Set dimensions
        author_5.width, author_5.height = 269.55352783203125, 30.0
        group_output_7.width, group_output_7.height = 140.0, 100.0
        combine_xyz_001_2.width, combine_xyz_001_2.height = 140.0, 100.0
        reroute_002_7.width, reroute_002_7.height = 16.0, 100.0
        reroute_001_7.width, reroute_001_7.height = 16.0, 100.0
        reroute_7.width, reroute_7.height = 16.0, 100.0
        reroute_005_6.width, reroute_005_6.height = 16.0, 100.0
        math_019.width, math_019.height = 140.0, 100.0
        math_021.width, math_021.height = 140.0, 100.0
        math_022.width, math_022.height = 140.0, 100.0
        reroute_003_7.width, reroute_003_7.height = 16.0, 100.0
        reroute_004_7.width, reroute_004_7.height = 16.0, 100.0
        separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
        reroute_010_6.width, reroute_010_6.height = 16.0, 100.0
        reroute_012_5.width, reroute_012_5.height = 16.0, 100.0
        reroute_007_5.width, reroute_007_5.height = 16.0, 100.0
        reroute_013_5.width, reroute_013_5.height = 16.0, 100.0
        reroute_011_6.width, reroute_011_6.height = 16.0, 100.0
        reroute_015_4.width, reroute_015_4.height = 16.0, 100.0
        reroute_014_5.width, reroute_014_5.height = 16.0, 100.0
        reroute_009_6.width, reroute_009_6.height = 16.0, 100.0
        reroute_020_5.width, reroute_020_5.height = 16.0, 100.0
        reroute_021_5.width, reroute_021_5.height = 16.0, 100.0
        reroute_023_4.width, reroute_023_4.height = 16.0, 100.0
        reroute_016_5.width, reroute_016_5.height = 16.0, 100.0
        reroute_022_5.width, reroute_022_5.height = 16.0, 100.0
        reroute_017_4.width, reroute_017_4.height = 16.0, 100.0
        reroute_018_5.width, reroute_018_5.height = 16.0, 100.0
        reroute_008_6.width, reroute_008_6.height = 16.0, 100.0
        reroute_006_6.width, reroute_006_6.height = 16.0, 100.0
        group_input_7.width, group_input_7.height = 140.0, 100.0
        reroute_019_5.width, reroute_019_5.height = 16.0, 100.0

        #initialize translate_001 links
        #reroute_011_6.Output -> math_019.Value
        translate_001.links.new(reroute_011_6.outputs[0], math_019.inputs[0])
        #reroute_010_6.Output -> math_021.Value
        translate_001.links.new(reroute_010_6.outputs[0], math_021.inputs[0])
        #reroute_009_6.Output -> math_022.Value
        translate_001.links.new(reroute_009_6.outputs[0], math_022.inputs[0])
        #reroute_002_7.Output -> combine_xyz_001_2.X
        translate_001.links.new(reroute_002_7.outputs[0], combine_xyz_001_2.inputs[0])
        #reroute_001_7.Output -> combine_xyz_001_2.Y
        translate_001.links.new(reroute_001_7.outputs[0], combine_xyz_001_2.inputs[1])
        #reroute_7.Output -> combine_xyz_001_2.Z
        translate_001.links.new(reroute_7.outputs[0], combine_xyz_001_2.inputs[2])
        #reroute_015_4.Output -> separate_xyz_1.Vector
        translate_001.links.new(reroute_015_4.outputs[0], separate_xyz_1.inputs[0])
        #combine_xyz_001_2.Vector -> group_output_7.Vector
        translate_001.links.new(combine_xyz_001_2.outputs[0], group_output_7.inputs[0])
        #reroute_022_5.Output -> math_021.Value
        translate_001.links.new(reroute_022_5.outputs[0], math_021.inputs[1])
        #reroute_014_5.Output -> math_019.Value
        translate_001.links.new(reroute_014_5.outputs[0], math_019.inputs[1])
        #reroute_017_4.Output -> math_022.Value
        translate_001.links.new(reroute_017_4.outputs[0], math_022.inputs[1])
        #reroute_005_6.Output -> reroute_7.Input
        translate_001.links.new(reroute_005_6.outputs[0], reroute_7.inputs[0])
        #reroute_004_7.Output -> reroute_001_7.Input
        translate_001.links.new(reroute_004_7.outputs[0], reroute_001_7.inputs[0])
        #reroute_003_7.Output -> reroute_002_7.Input
        translate_001.links.new(reroute_003_7.outputs[0], reroute_002_7.inputs[0])
        #math_019.Value -> reroute_003_7.Input
        translate_001.links.new(math_019.outputs[0], reroute_003_7.inputs[0])
        #math_021.Value -> reroute_004_7.Input
        translate_001.links.new(math_021.outputs[0], reroute_004_7.inputs[0])
        #math_022.Value -> reroute_005_6.Input
        translate_001.links.new(math_022.outputs[0], reroute_005_6.inputs[0])
        #reroute_013_5.Output -> reroute_009_6.Input
        translate_001.links.new(reroute_013_5.outputs[0], reroute_009_6.inputs[0])
        #reroute_012_5.Output -> reroute_010_6.Input
        translate_001.links.new(reroute_012_5.outputs[0], reroute_010_6.inputs[0])
        #reroute_007_5.Output -> reroute_011_6.Input
        translate_001.links.new(reroute_007_5.outputs[0], reroute_011_6.inputs[0])
        #separate_xyz_1.X -> reroute_007_5.Input
        translate_001.links.new(separate_xyz_1.outputs[0], reroute_007_5.inputs[0])
        #separate_xyz_1.Y -> reroute_012_5.Input
        translate_001.links.new(separate_xyz_1.outputs[1], reroute_012_5.inputs[0])
        #separate_xyz_1.Z -> reroute_013_5.Input
        translate_001.links.new(separate_xyz_1.outputs[2], reroute_013_5.inputs[0])
        #reroute_021_5.Output -> reroute_014_5.Input
        translate_001.links.new(reroute_021_5.outputs[0], reroute_014_5.inputs[0])
        #reroute_020_5.Output -> reroute_015_4.Input
        translate_001.links.new(reroute_020_5.outputs[0], reroute_015_4.inputs[0])
        #reroute_023_4.Output -> reroute_016_5.Input
        translate_001.links.new(reroute_023_4.outputs[0], reroute_016_5.inputs[0])
        #reroute_018_5.Output -> reroute_017_4.Input
        translate_001.links.new(reroute_018_5.outputs[0], reroute_017_4.inputs[0])
        #reroute_008_6.Output -> reroute_018_5.Input
        translate_001.links.new(reroute_008_6.outputs[0], reroute_018_5.inputs[0])
        #reroute_006_6.Output -> reroute_008_6.Input
        translate_001.links.new(reroute_006_6.outputs[0], reroute_008_6.inputs[0])
        #group_input_7.Y -> reroute_019_5.Input
        translate_001.links.new(group_input_7.outputs[2], reroute_019_5.inputs[0])
        #group_input_7.Vector -> reroute_020_5.Input
        translate_001.links.new(group_input_7.outputs[0], reroute_020_5.inputs[0])
        #group_input_7.X -> reroute_021_5.Input
        translate_001.links.new(group_input_7.outputs[1], reroute_021_5.inputs[0])
        #reroute_016_5.Output -> reroute_022_5.Input
        translate_001.links.new(reroute_016_5.outputs[0], reroute_022_5.inputs[0])
        #reroute_019_5.Output -> reroute_023_4.Input
        translate_001.links.new(reroute_019_5.outputs[0], reroute_023_4.inputs[0])
        #group_input_7.Z -> reroute_006_6.Input
        translate_001.links.new(group_input_7.outputs[3], reroute_006_6.inputs[0])
        return translate_001

    translate_001 = translate_001_node_group()

    #initialize Z Rotation node group
    def z_rotation_node_group():

        z_rotation = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Z Rotation")

        z_rotation.color_tag = 'NONE'
        z_rotation.description = ""
        z_rotation.default_group_node_width = 140
        

        #z_rotation interface
        #Socket Vector
        vector_socket_7 = z_rotation.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_7.default_value = (0.0, 0.0, 0.0)
        vector_socket_7.min_value = 0.0
        vector_socket_7.max_value = 0.0
        vector_socket_7.subtype = 'NONE'
        vector_socket_7.attribute_domain = 'POINT'

        #Socket Angle
        angle_socket_2 = z_rotation.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
        angle_socket_2.default_value = 0.0
        angle_socket_2.min_value = -3.4028234663852886e+38
        angle_socket_2.max_value = 3.4028234663852886e+38
        angle_socket_2.subtype = 'NONE'
        angle_socket_2.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_8 = z_rotation.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_8.default_value = (0.0, 0.0, 0.0)
        vector_socket_8.min_value = -3.4028234663852886e+38
        vector_socket_8.max_value = 3.4028234663852886e+38
        vector_socket_8.subtype = 'NONE'
        vector_socket_8.attribute_domain = 'POINT'


        #initialize z_rotation nodes
        #node Author
        author_6 = z_rotation.nodes.new("NodeFrame")
        author_6.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_6.name = "Author"
        author_6.use_custom_color = True
        author_6.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_6.label_size = 16
        author_6.shrink = True

        #node Subtract
        subtract_1 = z_rotation.nodes.new("ShaderNodeMath")
        subtract_1.name = "Subtract"
        subtract_1.operation = 'SUBTRACT'
        subtract_1.use_clamp = False

        #node Add
        add_1 = z_rotation.nodes.new("ShaderNodeMath")
        add_1.name = "Add"
        add_1.operation = 'ADD'
        add_1.use_clamp = False

        #node Reroute.009
        reroute_009_7 = z_rotation.nodes.new("NodeReroute")
        reroute_009_7.name = "Reroute.009"
        reroute_009_7.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_7 = z_rotation.nodes.new("NodeReroute")
        reroute_010_7.name = "Reroute.010"
        reroute_010_7.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_6 = z_rotation.nodes.new("NodeReroute")
        reroute_007_6.name = "Reroute.007"
        reroute_007_6.socket_idname = "NodeSocketFloat"
        #node Reroute.005
        reroute_005_7 = z_rotation.nodes.new("NodeReroute")
        reroute_005_7.name = "Reroute.005"
        reroute_005_7.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_7 = z_rotation.nodes.new("NodeReroute")
        reroute_011_7.name = "Reroute.011"
        reroute_011_7.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_7 = z_rotation.nodes.new("NodeReroute")
        reroute_008_7.name = "Reroute.008"
        reroute_008_7.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_6 = z_rotation.nodes.new("NodeReroute")
        reroute_012_6.name = "Reroute.012"
        reroute_012_6.socket_idname = "NodeSocketFloat"
        #node Multiply 1
        multiply_1_1 = z_rotation.nodes.new("ShaderNodeMath")
        multiply_1_1.name = "Multiply 1"
        multiply_1_1.operation = 'MULTIPLY'
        multiply_1_1.use_clamp = False

        #node Multiply 2
        multiply_2_1 = z_rotation.nodes.new("ShaderNodeMath")
        multiply_2_1.name = "Multiply 2"
        multiply_2_1.operation = 'MULTIPLY'
        multiply_2_1.use_clamp = False

        #node Multiply 3
        multiply_3_1 = z_rotation.nodes.new("ShaderNodeMath")
        multiply_3_1.name = "Multiply 3"
        multiply_3_1.operation = 'MULTIPLY'
        multiply_3_1.use_clamp = False

        #node Multiply 4
        multiply_4_1 = z_rotation.nodes.new("ShaderNodeMath")
        multiply_4_1.name = "Multiply 4"
        multiply_4_1.operation = 'MULTIPLY'
        multiply_4_1.use_clamp = False

        #node Reroute.013
        reroute_013_6 = z_rotation.nodes.new("NodeReroute")
        reroute_013_6.name = "Reroute.013"
        reroute_013_6.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_5 = z_rotation.nodes.new("NodeReroute")
        reroute_015_5.name = "Reroute.015"
        reroute_015_5.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_6 = z_rotation.nodes.new("NodeReroute")
        reroute_020_6.name = "Reroute.020"
        reroute_020_6.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022_6 = z_rotation.nodes.new("NodeReroute")
        reroute_022_6.name = "Reroute.022"
        reroute_022_6.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021_6 = z_rotation.nodes.new("NodeReroute")
        reroute_021_6.name = "Reroute.021"
        reroute_021_6.socket_idname = "NodeSocketFloat"
        #node Reroute.023
        reroute_023_5 = z_rotation.nodes.new("NodeReroute")
        reroute_023_5.name = "Reroute.023"
        reroute_023_5.socket_idname = "NodeSocketFloat"
        #node Reroute.024
        reroute_024_5 = z_rotation.nodes.new("NodeReroute")
        reroute_024_5.name = "Reroute.024"
        reroute_024_5.socket_idname = "NodeSocketFloat"
        #node Reroute.025
        reroute_025_5 = z_rotation.nodes.new("NodeReroute")
        reroute_025_5.name = "Reroute.025"
        reroute_025_5.socket_idname = "NodeSocketFloat"
        #node Reroute.018
        reroute_018_6 = z_rotation.nodes.new("NodeReroute")
        reroute_018_6.name = "Reroute.018"
        reroute_018_6.socket_idname = "NodeSocketFloat"
        #node Reroute.019
        reroute_019_6 = z_rotation.nodes.new("NodeReroute")
        reroute_019_6.name = "Reroute.019"
        reroute_019_6.socket_idname = "NodeSocketFloat"
        #node Reroute.027
        reroute_027_4 = z_rotation.nodes.new("NodeReroute")
        reroute_027_4.name = "Reroute.027"
        reroute_027_4.socket_idname = "NodeSocketFloat"
        #node Reroute.017
        reroute_017_5 = z_rotation.nodes.new("NodeReroute")
        reroute_017_5.name = "Reroute.017"
        reroute_017_5.socket_idname = "NodeSocketFloat"
        #node Separate XYZ
        separate_xyz_2 = z_rotation.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_2.name = "Separate XYZ"

        #node Sine
        sine_1 = z_rotation.nodes.new("ShaderNodeMath")
        sine_1.name = "Sine"
        sine_1.operation = 'SINE'
        sine_1.use_clamp = False
        sine_1.inputs[1].hide = True

        #node Sine.001
        sine_001_1 = z_rotation.nodes.new("ShaderNodeMath")
        sine_001_1.name = "Sine.001"
        sine_001_1.operation = 'SINE'
        sine_001_1.use_clamp = False
        sine_001_1.inputs[1].hide = True

        #node Cosine
        cosine_1 = z_rotation.nodes.new("ShaderNodeMath")
        cosine_1.name = "Cosine"
        cosine_1.operation = 'COSINE'
        cosine_1.use_clamp = False
        cosine_1.inputs[1].hide = True

        #node Reroute.014
        reroute_014_6 = z_rotation.nodes.new("NodeReroute")
        reroute_014_6.name = "Reroute.014"
        reroute_014_6.socket_idname = "NodeSocketFloat"
        #node Reroute.026
        reroute_026_4 = z_rotation.nodes.new("NodeReroute")
        reroute_026_4.name = "Reroute.026"
        reroute_026_4.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_6 = z_rotation.nodes.new("NodeReroute")
        reroute_016_6.name = "Reroute.016"
        reroute_016_6.socket_idname = "NodeSocketFloat"
        #node Cosine.001
        cosine_001_1 = z_rotation.nodes.new("ShaderNodeMath")
        cosine_001_1.name = "Cosine.001"
        cosine_001_1.operation = 'COSINE'
        cosine_001_1.use_clamp = False
        cosine_001_1.inputs[1].hide = True

        #node Reroute.030
        reroute_030_3 = z_rotation.nodes.new("NodeReroute")
        reroute_030_3.name = "Reroute.030"
        reroute_030_3.socket_idname = "NodeSocketFloat"
        #node Reroute.031
        reroute_031_3 = z_rotation.nodes.new("NodeReroute")
        reroute_031_3.name = "Reroute.031"
        reroute_031_3.socket_idname = "NodeSocketFloat"
        #node Reroute.032
        reroute_032_3 = z_rotation.nodes.new("NodeReroute")
        reroute_032_3.name = "Reroute.032"
        reroute_032_3.socket_idname = "NodeSocketFloat"
        #node Reroute.033
        reroute_033_3 = z_rotation.nodes.new("NodeReroute")
        reroute_033_3.name = "Reroute.033"
        reroute_033_3.socket_idname = "NodeSocketFloat"
        #node Combine XYZ
        combine_xyz_1 = z_rotation.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_1.name = "Combine XYZ"

        #node Group Output
        group_output_8 = z_rotation.nodes.new("NodeGroupOutput")
        group_output_8.name = "Group Output"
        group_output_8.use_custom_color = True
        group_output_8.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_8.is_active_output = True

        #node Reroute.002
        reroute_002_8 = z_rotation.nodes.new("NodeReroute")
        reroute_002_8.name = "Reroute.002"
        reroute_002_8.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_8 = z_rotation.nodes.new("NodeReroute")
        reroute_001_8.name = "Reroute.001"
        reroute_001_8.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_8 = z_rotation.nodes.new("NodeReroute")
        reroute_8.name = "Reroute"
        reroute_8.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_8 = z_rotation.nodes.new("NodeReroute")
        reroute_004_8.name = "Reroute.004"
        reroute_004_8.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_8 = z_rotation.nodes.new("NodeReroute")
        reroute_003_8.name = "Reroute.003"
        reroute_003_8.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_7 = z_rotation.nodes.new("NodeReroute")
        reroute_006_7.name = "Reroute.006"
        reroute_006_7.socket_idname = "NodeSocketFloat"
        #node Reroute.028
        reroute_028_4 = z_rotation.nodes.new("NodeReroute")
        reroute_028_4.name = "Reroute.028"
        reroute_028_4.socket_idname = "NodeSocketFloat"
        #node Math.001
        math_001_4 = z_rotation.nodes.new("ShaderNodeMath")
        math_001_4.name = "Math.001"
        math_001_4.operation = 'DIVIDE'
        math_001_4.use_clamp = False
        #Value_001
        math_001_4.inputs[1].default_value = 180.0

        #node Reroute.035
        reroute_035_3 = z_rotation.nodes.new("NodeReroute")
        reroute_035_3.name = "Reroute.035"
        reroute_035_3.socket_idname = "NodeSocketFloat"
        #node Math
        math_5 = z_rotation.nodes.new("ShaderNodeMath")
        math_5.name = "Math"
        math_5.operation = 'MULTIPLY'
        math_5.use_clamp = False
        #Value_001
        math_5.inputs[1].default_value = -3.1419999599456787

        #node Reroute.034
        reroute_034_3 = z_rotation.nodes.new("NodeReroute")
        reroute_034_3.name = "Reroute.034"
        reroute_034_3.socket_idname = "NodeSocketFloat"
        #node Reroute.038
        reroute_038_3 = z_rotation.nodes.new("NodeReroute")
        reroute_038_3.name = "Reroute.038"
        reroute_038_3.socket_idname = "NodeSocketFloat"
        #node Group Input
        group_input_8 = z_rotation.nodes.new("NodeGroupInput")
        group_input_8.name = "Group Input"
        group_input_8.use_custom_color = True
        group_input_8.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)

        #node Reroute.036
        reroute_036_3 = z_rotation.nodes.new("NodeReroute")
        reroute_036_3.name = "Reroute.036"
        reroute_036_3.socket_idname = "NodeSocketVector"
        #node Reroute.037
        reroute_037_3 = z_rotation.nodes.new("NodeReroute")
        reroute_037_3.name = "Reroute.037"
        reroute_037_3.socket_idname = "NodeSocketFloat"
        #node Reroute.029
        reroute_029_3 = z_rotation.nodes.new("NodeReroute")
        reroute_029_3.name = "Reroute.029"
        reroute_029_3.socket_idname = "NodeSocketVector"
        #node Reroute.040
        reroute_040_3 = z_rotation.nodes.new("NodeReroute")
        reroute_040_3.name = "Reroute.040"
        reroute_040_3.socket_idname = "NodeSocketVector"
        #node Reroute.039
        reroute_039_3 = z_rotation.nodes.new("NodeReroute")
        reroute_039_3.name = "Reroute.039"
        reroute_039_3.socket_idname = "NodeSocketVector"

        #Set locations
        author_6.location = (-120.57717895507812, -78.8060073852539)
        subtract_1.location = (-420.0, 0.0)
        add_1.location = (-420.0, -180.0)
        reroute_009_7.location = (-440.0, -136.53317260742188)
        reroute_010_7.location = (-440.0, -115.23310089111328)
        reroute_007_6.location = (-440.8663024902344, -316.9665222167969)
        reroute_005_7.location = (-440.0, -33.977020263671875)
        reroute_011_7.location = (-441.0945739746094, -214.52456665039062)
        reroute_008_7.location = (-460.0, -295.0721130371094)
        reroute_012_6.location = (-461.0945739746094, -395.0721130371094)
        multiply_1_1.location = (-620.0, 0.0)
        multiply_2_1.location = (-620.0, -180.0)
        multiply_3_1.location = (-620.0, -360.0)
        multiply_4_1.location = (-620.0, -540.0)
        reroute_013_6.location = (-440.9365539550781, -576.7205810546875)
        reroute_015_5.location = (-640.4331665039062, -115.23307800292969)
        reroute_020_6.location = (-640.0, -136.5331573486328)
        reroute_022_6.location = (-640.0, -496.4483642578125)
        reroute_021_6.location = (-640.4331665039062, -34.36639404296875)
        reroute_023_5.location = (-640.0, -194.79974365234375)
        reroute_024_5.location = (-660.0, -676.5408935546875)
        reroute_025_5.location = (-660.0, -216.80032348632812)
        reroute_018_6.location = (-659.5668334960938, -316.5331726074219)
        reroute_019_6.location = (-680.6915283203125, -294.5692138671875)
        reroute_027_4.location = (-680.0202026367188, -494.8603515625)
        reroute_017_5.location = (-700.0, -239.40806579589844)
        separate_xyz_2.location = (-860.0, -160.0)
        sine_1.location = (-860.0, -300.0)
        sine_001_1.location = (-860.0, -460.0)
        cosine_1.location = (-860.0, -620.0)
        reroute_014_6.location = (-700.0, -720.0)
        reroute_026_4.location = (-680.6396484375, -334.69573974609375)
        reroute_016_6.location = (-680.0, -475.9983825683594)
        cosine_001_1.location = (-860.0, 0.0)
        reroute_030_3.location = (-880.0, -115.15725708007812)
        reroute_031_3.location = (-880.0, -414.5282287597656)
        reroute_032_3.location = (-879.3084716796875, -574.4654541015625)
        reroute_033_3.location = (-880.6915283203125, -735.1572265625)
        combine_xyz_1.location = (-220.57717895507812, 1.1939947605133057)
        group_output_8.location = (-40.57718276977539, 1.1939947605133057)
        reroute_002_8.location = (-240.57717895507812, -58.80600357055664)
        reroute_001_8.location = (-240.57717895507812, -80.83868408203125)
        reroute_8.location = (-261.0851135253906, -103.37953186035156)
        reroute_004_8.location = (-240.57717895507812, -213.72430419921875)
        reroute_003_8.location = (-240.57717895507812, -34.31150436401367)
        reroute_006_7.location = (-260.5771789550781, -718.8060302734375)
        reroute_028_4.location = (-880.6396484375, -34.94972229003906)
        math_001_4.location = (-1040.0, 0.0)
        reroute_035_3.location = (-1060.0, -114.8805160522461)
        math_5.location = (-1220.0, 0.0)
        reroute_034_3.location = (-1060.0, -34.880516052246094)
        reroute_038_3.location = (-1240.0, -114.8805160522461)
        group_input_8.location = (-1418.42333984375, 1.9198070764541626)
        reroute_036_3.location = (-1258.42333984375, -55.520450592041016)
        reroute_037_3.location = (-1239.531494140625, -33.600643157958984)
        reroute_029_3.location = (-1260.0, -180.0)
        reroute_040_3.location = (-900.0, -264.396240234375)
        reroute_039_3.location = (-900.0, -180.0)

        #Set dimensions
        author_6.width, author_6.height = 269.55352783203125, 30.0
        subtract_1.width, subtract_1.height = 140.0, 100.0
        add_1.width, add_1.height = 140.0, 100.0
        reroute_009_7.width, reroute_009_7.height = 16.0, 100.0
        reroute_010_7.width, reroute_010_7.height = 16.0, 100.0
        reroute_007_6.width, reroute_007_6.height = 16.0, 100.0
        reroute_005_7.width, reroute_005_7.height = 16.0, 100.0
        reroute_011_7.width, reroute_011_7.height = 16.0, 100.0
        reroute_008_7.width, reroute_008_7.height = 16.0, 100.0
        reroute_012_6.width, reroute_012_6.height = 16.0, 100.0
        multiply_1_1.width, multiply_1_1.height = 140.0, 100.0
        multiply_2_1.width, multiply_2_1.height = 140.0, 100.0
        multiply_3_1.width, multiply_3_1.height = 140.0, 100.0
        multiply_4_1.width, multiply_4_1.height = 140.0, 100.0
        reroute_013_6.width, reroute_013_6.height = 16.0, 100.0
        reroute_015_5.width, reroute_015_5.height = 16.0, 100.0
        reroute_020_6.width, reroute_020_6.height = 16.0, 100.0
        reroute_022_6.width, reroute_022_6.height = 16.0, 100.0
        reroute_021_6.width, reroute_021_6.height = 16.0, 100.0
        reroute_023_5.width, reroute_023_5.height = 16.0, 100.0
        reroute_024_5.width, reroute_024_5.height = 16.0, 100.0
        reroute_025_5.width, reroute_025_5.height = 16.0, 100.0
        reroute_018_6.width, reroute_018_6.height = 16.0, 100.0
        reroute_019_6.width, reroute_019_6.height = 16.0, 100.0
        reroute_027_4.width, reroute_027_4.height = 16.0, 100.0
        reroute_017_5.width, reroute_017_5.height = 16.0, 100.0
        separate_xyz_2.width, separate_xyz_2.height = 140.0, 100.0
        sine_1.width, sine_1.height = 140.0, 100.0
        sine_001_1.width, sine_001_1.height = 140.0, 100.0
        cosine_1.width, cosine_1.height = 140.0, 100.0
        reroute_014_6.width, reroute_014_6.height = 16.0, 100.0
        reroute_026_4.width, reroute_026_4.height = 16.0, 100.0
        reroute_016_6.width, reroute_016_6.height = 16.0, 100.0
        cosine_001_1.width, cosine_001_1.height = 140.0, 100.0
        reroute_030_3.width, reroute_030_3.height = 16.0, 100.0
        reroute_031_3.width, reroute_031_3.height = 16.0, 100.0
        reroute_032_3.width, reroute_032_3.height = 16.0, 100.0
        reroute_033_3.width, reroute_033_3.height = 16.0, 100.0
        combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
        group_output_8.width, group_output_8.height = 140.0, 100.0
        reroute_002_8.width, reroute_002_8.height = 16.0, 100.0
        reroute_001_8.width, reroute_001_8.height = 16.0, 100.0
        reroute_8.width, reroute_8.height = 16.0, 100.0
        reroute_004_8.width, reroute_004_8.height = 16.0, 100.0
        reroute_003_8.width, reroute_003_8.height = 16.0, 100.0
        reroute_006_7.width, reroute_006_7.height = 16.0, 100.0
        reroute_028_4.width, reroute_028_4.height = 16.0, 100.0
        math_001_4.width, math_001_4.height = 140.0, 100.0
        reroute_035_3.width, reroute_035_3.height = 16.0, 100.0
        math_5.width, math_5.height = 140.0, 100.0
        reroute_034_3.width, reroute_034_3.height = 16.0, 100.0
        reroute_038_3.width, reroute_038_3.height = 16.0, 100.0
        group_input_8.width, group_input_8.height = 140.0, 100.0
        reroute_036_3.width, reroute_036_3.height = 16.0, 100.0
        reroute_037_3.width, reroute_037_3.height = 16.0, 100.0
        reroute_029_3.width, reroute_029_3.height = 16.0, 100.0
        reroute_040_3.width, reroute_040_3.height = 16.0, 100.0
        reroute_039_3.width, reroute_039_3.height = 16.0, 100.0

        #initialize z_rotation links
        #reroute_040_3.Output -> separate_xyz_2.Vector
        z_rotation.links.new(reroute_040_3.outputs[0], separate_xyz_2.inputs[0])
        #reroute_031_3.Output -> sine_1.Value
        z_rotation.links.new(reroute_031_3.outputs[0], sine_1.inputs[0])
        #reroute_033_3.Output -> cosine_1.Value
        z_rotation.links.new(reroute_033_3.outputs[0], cosine_1.inputs[0])
        #reroute_020_6.Output -> multiply_1_1.Value
        z_rotation.links.new(reroute_020_6.outputs[0], multiply_1_1.inputs[1])
        #reroute_019_6.Output -> multiply_2_1.Value
        z_rotation.links.new(reroute_019_6.outputs[0], multiply_2_1.inputs[0])
        #reroute_018_6.Output -> multiply_2_1.Value
        z_rotation.links.new(reroute_018_6.outputs[0], multiply_2_1.inputs[1])
        #reroute_010_7.Output -> subtract_1.Value
        z_rotation.links.new(reroute_010_7.outputs[0], subtract_1.inputs[0])
        #reroute_009_7.Output -> subtract_1.Value
        z_rotation.links.new(reroute_009_7.outputs[0], subtract_1.inputs[1])
        #reroute_002_8.Output -> combine_xyz_1.X
        z_rotation.links.new(reroute_002_8.outputs[0], combine_xyz_1.inputs[0])
        #reroute_022_6.Output -> multiply_3_1.Value
        z_rotation.links.new(reroute_022_6.outputs[0], multiply_3_1.inputs[1])
        #cosine_1.Value -> multiply_4_1.Value
        z_rotation.links.new(cosine_1.outputs[0], multiply_4_1.inputs[0])
        #reroute_024_5.Output -> multiply_4_1.Value
        z_rotation.links.new(reroute_024_5.outputs[0], multiply_4_1.inputs[1])
        #reroute_008_7.Output -> add_1.Value
        z_rotation.links.new(reroute_008_7.outputs[0], add_1.inputs[0])
        #reroute_007_6.Output -> add_1.Value
        z_rotation.links.new(reroute_007_6.outputs[0], add_1.inputs[1])
        #reroute_001_8.Output -> combine_xyz_1.Y
        z_rotation.links.new(reroute_001_8.outputs[0], combine_xyz_1.inputs[1])
        #reroute_8.Output -> combine_xyz_1.Z
        z_rotation.links.new(reroute_8.outputs[0], combine_xyz_1.inputs[2])
        #combine_xyz_1.Vector -> group_output_8.Vector
        z_rotation.links.new(combine_xyz_1.outputs[0], group_output_8.inputs[0])
        #reroute_035_3.Output -> math_001_4.Value
        z_rotation.links.new(reroute_035_3.outputs[0], math_001_4.inputs[0])
        #reroute_038_3.Output -> math_5.Value
        z_rotation.links.new(reroute_038_3.outputs[0], math_5.inputs[0])
        #reroute_032_3.Output -> sine_001_1.Value
        z_rotation.links.new(reroute_032_3.outputs[0], sine_001_1.inputs[0])
        #reroute_016_6.Output -> multiply_3_1.Value
        z_rotation.links.new(reroute_016_6.outputs[0], multiply_3_1.inputs[0])
        #reroute_030_3.Output -> cosine_001_1.Value
        z_rotation.links.new(reroute_030_3.outputs[0], cosine_001_1.inputs[0])
        #reroute_015_5.Output -> multiply_1_1.Value
        z_rotation.links.new(reroute_015_5.outputs[0], multiply_1_1.inputs[0])
        #reroute_006_7.Output -> reroute_8.Input
        z_rotation.links.new(reroute_006_7.outputs[0], reroute_8.inputs[0])
        #reroute_004_8.Output -> reroute_001_8.Input
        z_rotation.links.new(reroute_004_8.outputs[0], reroute_001_8.inputs[0])
        #reroute_003_8.Output -> reroute_002_8.Input
        z_rotation.links.new(reroute_003_8.outputs[0], reroute_002_8.inputs[0])
        #subtract_1.Value -> reroute_003_8.Input
        z_rotation.links.new(subtract_1.outputs[0], reroute_003_8.inputs[0])
        #add_1.Value -> reroute_004_8.Input
        z_rotation.links.new(add_1.outputs[0], reroute_004_8.inputs[0])
        #reroute_014_6.Output -> reroute_006_7.Input
        z_rotation.links.new(reroute_014_6.outputs[0], reroute_006_7.inputs[0])
        #reroute_013_6.Output -> reroute_007_6.Input
        z_rotation.links.new(reroute_013_6.outputs[0], reroute_007_6.inputs[0])
        #reroute_012_6.Output -> reroute_008_7.Input
        z_rotation.links.new(reroute_012_6.outputs[0], reroute_008_7.inputs[0])
        #reroute_011_7.Output -> reroute_009_7.Input
        z_rotation.links.new(reroute_011_7.outputs[0], reroute_009_7.inputs[0])
        #reroute_005_7.Output -> reroute_010_7.Input
        z_rotation.links.new(reroute_005_7.outputs[0], reroute_010_7.inputs[0])
        #multiply_1_1.Value -> reroute_005_7.Input
        z_rotation.links.new(multiply_1_1.outputs[0], reroute_005_7.inputs[0])
        #multiply_2_1.Value -> reroute_011_7.Input
        z_rotation.links.new(multiply_2_1.outputs[0], reroute_011_7.inputs[0])
        #multiply_3_1.Value -> reroute_012_6.Input
        z_rotation.links.new(multiply_3_1.outputs[0], reroute_012_6.inputs[0])
        #multiply_4_1.Value -> reroute_013_6.Input
        z_rotation.links.new(multiply_4_1.outputs[0], reroute_013_6.inputs[0])
        #reroute_017_5.Output -> reroute_014_6.Input
        z_rotation.links.new(reroute_017_5.outputs[0], reroute_014_6.inputs[0])
        #reroute_021_6.Output -> reroute_015_5.Input
        z_rotation.links.new(reroute_021_6.outputs[0], reroute_015_5.inputs[0])
        #reroute_027_4.Output -> reroute_016_6.Input
        z_rotation.links.new(reroute_027_4.outputs[0], reroute_016_6.inputs[0])
        #reroute_025_5.Output -> reroute_018_6.Input
        z_rotation.links.new(reroute_025_5.outputs[0], reroute_018_6.inputs[0])
        #reroute_026_4.Output -> reroute_019_6.Input
        z_rotation.links.new(reroute_026_4.outputs[0], reroute_019_6.inputs[0])
        #cosine_001_1.Value -> reroute_021_6.Input
        z_rotation.links.new(cosine_001_1.outputs[0], reroute_021_6.inputs[0])
        #reroute_023_5.Output -> reroute_022_6.Input
        z_rotation.links.new(reroute_023_5.outputs[0], reroute_022_6.inputs[0])
        #separate_xyz_2.X -> reroute_023_5.Input
        z_rotation.links.new(separate_xyz_2.outputs[0], reroute_023_5.inputs[0])
        #reroute_023_5.Output -> reroute_020_6.Input
        z_rotation.links.new(reroute_023_5.outputs[0], reroute_020_6.inputs[0])
        #reroute_018_6.Output -> reroute_024_5.Input
        z_rotation.links.new(reroute_018_6.outputs[0], reroute_024_5.inputs[0])
        #separate_xyz_2.Y -> reroute_025_5.Input
        z_rotation.links.new(separate_xyz_2.outputs[1], reroute_025_5.inputs[0])
        #sine_1.Value -> reroute_026_4.Input
        z_rotation.links.new(sine_1.outputs[0], reroute_026_4.inputs[0])
        #sine_001_1.Value -> reroute_027_4.Input
        z_rotation.links.new(sine_001_1.outputs[0], reroute_027_4.inputs[0])
        #separate_xyz_2.Z -> reroute_017_5.Input
        z_rotation.links.new(separate_xyz_2.outputs[2], reroute_017_5.inputs[0])
        #math_001_4.Value -> reroute_028_4.Input
        z_rotation.links.new(math_001_4.outputs[0], reroute_028_4.inputs[0])
        #reroute_028_4.Output -> reroute_030_3.Input
        z_rotation.links.new(reroute_028_4.outputs[0], reroute_030_3.inputs[0])
        #reroute_030_3.Output -> reroute_031_3.Input
        z_rotation.links.new(reroute_030_3.outputs[0], reroute_031_3.inputs[0])
        #reroute_031_3.Output -> reroute_032_3.Input
        z_rotation.links.new(reroute_031_3.outputs[0], reroute_032_3.inputs[0])
        #reroute_032_3.Output -> reroute_033_3.Input
        z_rotation.links.new(reroute_032_3.outputs[0], reroute_033_3.inputs[0])
        #math_5.Value -> reroute_034_3.Input
        z_rotation.links.new(math_5.outputs[0], reroute_034_3.inputs[0])
        #reroute_034_3.Output -> reroute_035_3.Input
        z_rotation.links.new(reroute_034_3.outputs[0], reroute_035_3.inputs[0])
        #group_input_8.Vector -> reroute_036_3.Input
        z_rotation.links.new(group_input_8.outputs[1], reroute_036_3.inputs[0])
        #group_input_8.Angle -> reroute_037_3.Input
        z_rotation.links.new(group_input_8.outputs[0], reroute_037_3.inputs[0])
        #reroute_037_3.Output -> reroute_038_3.Input
        z_rotation.links.new(reroute_037_3.outputs[0], reroute_038_3.inputs[0])
        #reroute_029_3.Output -> reroute_039_3.Input
        z_rotation.links.new(reroute_029_3.outputs[0], reroute_039_3.inputs[0])
        #reroute_036_3.Output -> reroute_029_3.Input
        z_rotation.links.new(reroute_036_3.outputs[0], reroute_029_3.inputs[0])
        #reroute_039_3.Output -> reroute_040_3.Input
        z_rotation.links.new(reroute_039_3.outputs[0], reroute_040_3.inputs[0])
        return z_rotation

    z_rotation = z_rotation_node_group()

    #initialize X, Y, Z Multiplier.002 node group
    def x__y__z_multiplier_002_node_group():

        x__y__z_multiplier_002 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "X, Y, Z Multiplier.002")

        x__y__z_multiplier_002.color_tag = 'NONE'
        x__y__z_multiplier_002.description = ""
        x__y__z_multiplier_002.default_group_node_width = 140
        

        #x__y__z_multiplier_002 interface
        #Socket X
        x_socket_1 = x__y__z_multiplier_002.interface.new_socket(name = "X", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        x_socket_1.default_value = 0.0
        x_socket_1.min_value = -3.4028234663852886e+38
        x_socket_1.max_value = 3.4028234663852886e+38
        x_socket_1.subtype = 'NONE'
        x_socket_1.attribute_domain = 'POINT'

        #Socket Y
        y_socket_1 = x__y__z_multiplier_002.interface.new_socket(name = "Y", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        y_socket_1.default_value = 0.0
        y_socket_1.min_value = -3.4028234663852886e+38
        y_socket_1.max_value = 3.4028234663852886e+38
        y_socket_1.subtype = 'NONE'
        y_socket_1.attribute_domain = 'POINT'

        #Socket Z
        z_socket_1 = x__y__z_multiplier_002.interface.new_socket(name = "Z", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
        z_socket_1.default_value = 0.0
        z_socket_1.min_value = -3.4028234663852886e+38
        z_socket_1.max_value = 3.4028234663852886e+38
        z_socket_1.subtype = 'NONE'
        z_socket_1.attribute_domain = 'POINT'

        #Socket Factor
        factor_socket = x__y__z_multiplier_002.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
        factor_socket.default_value = 0.5
        factor_socket.min_value = -10000.0
        factor_socket.max_value = 10000.0
        factor_socket.subtype = 'NONE'
        factor_socket.attribute_domain = 'POINT'

        #Socket X
        x_socket_2 = x__y__z_multiplier_002.interface.new_socket(name = "X", in_out='INPUT', socket_type = 'NodeSocketFloat')
        x_socket_2.default_value = 0.5
        x_socket_2.min_value = -10000.0
        x_socket_2.max_value = 10000.0
        x_socket_2.subtype = 'NONE'
        x_socket_2.attribute_domain = 'POINT'

        #Socket Y
        y_socket_2 = x__y__z_multiplier_002.interface.new_socket(name = "Y", in_out='INPUT', socket_type = 'NodeSocketFloat')
        y_socket_2.default_value = 0.5
        y_socket_2.min_value = -10000.0
        y_socket_2.max_value = 10000.0
        y_socket_2.subtype = 'NONE'
        y_socket_2.attribute_domain = 'POINT'

        #Socket Z
        z_socket_2 = x__y__z_multiplier_002.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
        z_socket_2.default_value = 0.5
        z_socket_2.min_value = -10000.0
        z_socket_2.max_value = 10000.0
        z_socket_2.subtype = 'NONE'
        z_socket_2.attribute_domain = 'POINT'


        #initialize x__y__z_multiplier_002 nodes
        #node Author
        author_7 = x__y__z_multiplier_002.nodes.new("NodeFrame")
        author_7.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_7.name = "Author"
        author_7.use_custom_color = True
        author_7.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_7.label_size = 16
        author_7.shrink = True

        #node X, Y, Z MultiplierNode
        x__y__z_multipliernode = x__y__z_multiplier_002.nodes.new("NodeFrame")
        x__y__z_multipliernode.label = "X, Y, Z Multiplier Node"
        x__y__z_multipliernode.name = "X, Y, Z MultiplierNode"
        x__y__z_multipliernode.use_custom_color = True
        x__y__z_multipliernode.color = (0.20527799427509308, 0.10875699669122696, 0.27383100986480713)
        x__y__z_multipliernode.label_size = 15
        x__y__z_multipliernode.shrink = True

        #node Math.003
        math_003_2 = x__y__z_multiplier_002.nodes.new("ShaderNodeMath")
        math_003_2.label = "Multiply X Factor"
        math_003_2.name = "Math.003"
        math_003_2.operation = 'MULTIPLY'
        math_003_2.use_clamp = False
        math_003_2.inputs[2].hide = True

        #node Math.004
        math_004 = x__y__z_multiplier_002.nodes.new("ShaderNodeMath")
        math_004.label = "Multiply Y Factor"
        math_004.name = "Math.004"
        math_004.operation = 'MULTIPLY'
        math_004.use_clamp = False
        math_004.inputs[2].hide = True

        #node Math.005
        math_005 = x__y__z_multiplier_002.nodes.new("ShaderNodeMath")
        math_005.label = "Multiply Z Factor"
        math_005.name = "Math.005"
        math_005.operation = 'MULTIPLY'
        math_005.use_clamp = False

        #node Reroute.003
        reroute_003_9 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_003_9.name = "Reroute.003"
        reroute_003_9.socket_idname = "NodeSocketFloat"
        #node Reroute
        reroute_9 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_9.name = "Reroute"
        reroute_9.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_9 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_001_9.name = "Reroute.001"
        reroute_001_9.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_9 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_002_9.name = "Reroute.002"
        reroute_002_9.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_006_8.name = "Reroute.006"
        reroute_006_8.socket_idname = "NodeSocketFloat"
        #node Group Input
        group_input_9 = x__y__z_multiplier_002.nodes.new("NodeGroupInput")
        group_input_9.name = "Group Input"
        group_input_9.use_custom_color = True
        group_input_9.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_9.outputs[4].hide = True

        #node Reroute.009
        reroute_009_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_009_8.name = "Reroute.009"
        reroute_009_8.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_011_8.name = "Reroute.011"
        reroute_011_8.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_008_8.name = "Reroute.008"
        reroute_008_8.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_010_8.name = "Reroute.010"
        reroute_010_8.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_7 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_007_7.name = "Reroute.007"
        reroute_007_7.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_7 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_013_7.name = "Reroute.013"
        reroute_013_7.socket_idname = "NodeSocketFloat"
        #node Reroute.005
        reroute_005_8 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_005_8.name = "Reroute.005"
        reroute_005_8.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_7 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_012_7.name = "Reroute.012"
        reroute_012_7.socket_idname = "NodeSocketFloat"
        #node Reroute.004
        reroute_004_9 = x__y__z_multiplier_002.nodes.new("NodeReroute")
        reroute_004_9.name = "Reroute.004"
        reroute_004_9.socket_idname = "NodeSocketFloat"
        #node Group Output
        group_output_9 = x__y__z_multiplier_002.nodes.new("NodeGroupOutput")
        group_output_9.name = "Group Output"
        group_output_9.use_custom_color = True
        group_output_9.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_9.is_active_output = True
        group_output_9.inputs[3].hide = True


        #Set locations
        author_7.location = (-187.70846557617188, -460.0)
        x__y__z_multipliernode.location = (-340.0, 120.0)
        math_003_2.location = (-180.0, 0.0)
        math_004.location = (-180.0, -174.0)
        math_005.location = (-180.0, -348.0)
        reroute_003_9.location = (-21.18727684020996, -208.7156982421875)
        reroute_9.location = (-1.780914068222046, -382.3756408691406)
        reroute_001_9.location = (-20.0, -56.4365348815918)
        reroute_002_9.location = (-0.5936380624771118, -79.40608978271484)
        reroute_006_8.location = (-200.0, -137.22341918945312)
        group_input_9.location = (-440.0, 0.0)
        reroute_009_8.location = (-200.0, -56.4365348815918)
        reroute_011_8.location = (-220.0, -310.09649658203125)
        reroute_008_8.location = (-260.3674011230469, -114.65480041503906)
        reroute_010_8.location = (-259.7737731933594, -35.24871063232422)
        reroute_007_7.location = (-260.3674011230469, -288.9086608886719)
        reroute_013_7.location = (-260.3674011230469, -462.96954345703125)
        reroute_005_8.location = (-220.0, -78.21826934814453)
        reroute_012_7.location = (-240.0, -101.78173065185547)
        reroute_004_9.location = (-241.96461486816406, -485.9391174316406)
        group_output_9.location = (20.0, 0.0)

        #Set dimensions
        author_7.width, author_7.height = 275.01275634765625, 30.0
        x__y__z_multipliernode.width, x__y__z_multipliernode.height = 355.3053894042969, 100.0
        math_003_2.width, math_003_2.height = 140.0, 100.0
        math_004.width, math_004.height = 140.0, 100.0
        math_005.width, math_005.height = 140.0, 100.0
        reroute_003_9.width, reroute_003_9.height = 16.0, 100.0
        reroute_9.width, reroute_9.height = 16.0, 100.0
        reroute_001_9.width, reroute_001_9.height = 16.0, 100.0
        reroute_002_9.width, reroute_002_9.height = 16.0, 100.0
        reroute_006_8.width, reroute_006_8.height = 16.0, 100.0
        group_input_9.width, group_input_9.height = 140.0, 100.0
        reroute_009_8.width, reroute_009_8.height = 16.0, 100.0
        reroute_011_8.width, reroute_011_8.height = 16.0, 100.0
        reroute_008_8.width, reroute_008_8.height = 16.0, 100.0
        reroute_010_8.width, reroute_010_8.height = 16.0, 100.0
        reroute_007_7.width, reroute_007_7.height = 16.0, 100.0
        reroute_013_7.width, reroute_013_7.height = 16.0, 100.0
        reroute_005_8.width, reroute_005_8.height = 16.0, 100.0
        reroute_012_7.width, reroute_012_7.height = 16.0, 100.0
        reroute_004_9.width, reroute_004_9.height = 16.0, 100.0
        group_output_9.width, group_output_9.height = 140.0, 100.0

        #initialize x__y__z_multiplier_002 links
        #reroute_008_8.Output -> math_003_2.Value
        x__y__z_multiplier_002.links.new(reroute_008_8.outputs[0], math_003_2.inputs[0])
        #reroute_007_7.Output -> math_004.Value
        x__y__z_multiplier_002.links.new(reroute_007_7.outputs[0], math_004.inputs[0])
        #reroute_013_7.Output -> math_005.Value
        x__y__z_multiplier_002.links.new(reroute_013_7.outputs[0], math_005.inputs[0])
        #reroute_006_8.Output -> math_003_2.Value
        x__y__z_multiplier_002.links.new(reroute_006_8.outputs[0], math_003_2.inputs[1])
        #reroute_011_8.Output -> math_004.Value
        x__y__z_multiplier_002.links.new(reroute_011_8.outputs[0], math_004.inputs[1])
        #reroute_004_9.Output -> math_005.Value
        x__y__z_multiplier_002.links.new(reroute_004_9.outputs[0], math_005.inputs[1])
        #reroute_002_9.Output -> group_output_9.Z
        x__y__z_multiplier_002.links.new(reroute_002_9.outputs[0], group_output_9.inputs[2])
        #reroute_001_9.Output -> group_output_9.Y
        x__y__z_multiplier_002.links.new(reroute_001_9.outputs[0], group_output_9.inputs[1])
        #math_003_2.Value -> group_output_9.X
        x__y__z_multiplier_002.links.new(math_003_2.outputs[0], group_output_9.inputs[0])
        #reroute_003_9.Output -> reroute_001_9.Input
        x__y__z_multiplier_002.links.new(reroute_003_9.outputs[0], reroute_001_9.inputs[0])
        #reroute_9.Output -> reroute_002_9.Input
        x__y__z_multiplier_002.links.new(reroute_9.outputs[0], reroute_002_9.inputs[0])
        #math_005.Value -> reroute_9.Input
        x__y__z_multiplier_002.links.new(math_005.outputs[0], reroute_9.inputs[0])
        #math_004.Value -> reroute_003_9.Input
        x__y__z_multiplier_002.links.new(math_004.outputs[0], reroute_003_9.inputs[0])
        #reroute_012_7.Output -> reroute_004_9.Input
        x__y__z_multiplier_002.links.new(reroute_012_7.outputs[0], reroute_004_9.inputs[0])
        #reroute_009_8.Output -> reroute_006_8.Input
        x__y__z_multiplier_002.links.new(reroute_009_8.outputs[0], reroute_006_8.inputs[0])
        #group_input_9.X -> reroute_009_8.Input
        x__y__z_multiplier_002.links.new(group_input_9.outputs[1], reroute_009_8.inputs[0])
        #group_input_9.Factor -> reroute_010_8.Input
        x__y__z_multiplier_002.links.new(group_input_9.outputs[0], reroute_010_8.inputs[0])
        #reroute_005_8.Output -> reroute_011_8.Input
        x__y__z_multiplier_002.links.new(reroute_005_8.outputs[0], reroute_011_8.inputs[0])
        #group_input_9.Z -> reroute_012_7.Input
        x__y__z_multiplier_002.links.new(group_input_9.outputs[3], reroute_012_7.inputs[0])
        #reroute_010_8.Output -> reroute_008_8.Input
        x__y__z_multiplier_002.links.new(reroute_010_8.outputs[0], reroute_008_8.inputs[0])
        #reroute_008_8.Output -> reroute_007_7.Input
        x__y__z_multiplier_002.links.new(reroute_008_8.outputs[0], reroute_007_7.inputs[0])
        #reroute_007_7.Output -> reroute_013_7.Input
        x__y__z_multiplier_002.links.new(reroute_007_7.outputs[0], reroute_013_7.inputs[0])
        #group_input_9.Y -> reroute_005_8.Input
        x__y__z_multiplier_002.links.new(group_input_9.outputs[2], reroute_005_8.inputs[0])
        return x__y__z_multiplier_002

    x__y__z_multiplier_002 = x__y__z_multiplier_002_node_group()

    #initialize Scale node group
    def scale_node_group():

        scale = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Scale")

        scale.color_tag = 'NONE'
        scale.description = ""
        scale.default_group_node_width = 140
        

        #scale interface
        #Socket Vector
        vector_socket_9 = scale.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_9.default_value = (0.0, 0.0, 0.0)
        vector_socket_9.min_value = 0.0
        vector_socket_9.max_value = 0.0
        vector_socket_9.subtype = 'NONE'
        vector_socket_9.attribute_domain = 'POINT'

        #Socket Factor
        factor_socket_1 = scale.interface.new_socket(name = "Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
        factor_socket_1.default_value = 0.0
        factor_socket_1.min_value = -3.4028234663852886e+38
        factor_socket_1.max_value = 3.4028234663852886e+38
        factor_socket_1.subtype = 'NONE'
        factor_socket_1.attribute_domain = 'POINT'

        #Socket X
        x_socket_3 = scale.interface.new_socket(name = "X", in_out='INPUT', socket_type = 'NodeSocketFloat')
        x_socket_3.default_value = 1.0
        x_socket_3.min_value = -10000.0
        x_socket_3.max_value = 10000.0
        x_socket_3.subtype = 'NONE'
        x_socket_3.attribute_domain = 'POINT'

        #Socket Y
        y_socket_3 = scale.interface.new_socket(name = "Y", in_out='INPUT', socket_type = 'NodeSocketFloat')
        y_socket_3.default_value = 1.0
        y_socket_3.min_value = -10000.0
        y_socket_3.max_value = 10000.0
        y_socket_3.subtype = 'NONE'
        y_socket_3.attribute_domain = 'POINT'

        #Socket Z
        z_socket_3 = scale.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat')
        z_socket_3.default_value = 1.0
        z_socket_3.min_value = -10000.0
        z_socket_3.max_value = 10000.0
        z_socket_3.subtype = 'NONE'
        z_socket_3.attribute_domain = 'POINT'

        #Socket Vector
        vector_socket_10 = scale.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        vector_socket_10.default_value = (0.0, 0.0, 0.0)
        vector_socket_10.min_value = -10000.0
        vector_socket_10.max_value = 10000.0
        vector_socket_10.subtype = 'NONE'
        vector_socket_10.attribute_domain = 'POINT'


        #initialize scale nodes
        #node Author
        author_8 = scale.nodes.new("NodeFrame")
        author_8.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_8.name = "Author"
        author_8.use_custom_color = True
        author_8.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_8.label_size = 16
        author_8.shrink = True

        #node Combine XYZ
        combine_xyz_2 = scale.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_2.name = "Combine XYZ"

        #node Group Output
        group_output_10 = scale.nodes.new("NodeGroupOutput")
        group_output_10.name = "Group Output"
        group_output_10.use_custom_color = True
        group_output_10.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_10.is_active_output = True
        group_output_10.inputs[1].hide = True

        #node Reroute
        reroute_10 = scale.nodes.new("NodeReroute")
        reroute_10.name = "Reroute"
        reroute_10.socket_idname = "NodeSocketFloat"
        #node Reroute.001
        reroute_001_10 = scale.nodes.new("NodeReroute")
        reroute_001_10.name = "Reroute.001"
        reroute_001_10.socket_idname = "NodeSocketFloat"
        #node Reroute.002
        reroute_002_10 = scale.nodes.new("NodeReroute")
        reroute_002_10.name = "Reroute.002"
        reroute_002_10.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_10 = scale.nodes.new("NodeReroute")
        reroute_003_10.name = "Reroute.003"
        reroute_003_10.socket_idname = "NodeSocketFloat"
        #node Math
        math_6 = scale.nodes.new("ShaderNodeMath")
        math_6.name = "Math"
        math_6.operation = 'MULTIPLY'
        math_6.use_clamp = False
        math_6.inputs[2].hide = True

        #node Math.001
        math_001_5 = scale.nodes.new("ShaderNodeMath")
        math_001_5.name = "Math.001"
        math_001_5.operation = 'MULTIPLY'
        math_001_5.use_clamp = False
        math_001_5.inputs[2].hide = True

        #node Math.002
        math_002_2 = scale.nodes.new("ShaderNodeMath")
        math_002_2.name = "Math.002"
        math_002_2.operation = 'MULTIPLY'
        math_002_2.use_clamp = False
        math_002_2.inputs[2].hide = True

        #node Reroute.004
        reroute_004_10 = scale.nodes.new("NodeReroute")
        reroute_004_10.name = "Reroute.004"
        reroute_004_10.socket_idname = "NodeSocketFloat"
        #node Reroute.005
        reroute_005_9 = scale.nodes.new("NodeReroute")
        reroute_005_9.name = "Reroute.005"
        reroute_005_9.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_9 = scale.nodes.new("NodeReroute")
        reroute_008_9.name = "Reroute.008"
        reroute_008_9.socket_idname = "NodeSocketFloat"
        #node Reroute.012
        reroute_012_8 = scale.nodes.new("NodeReroute")
        reroute_012_8.name = "Reroute.012"
        reroute_012_8.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_8 = scale.nodes.new("NodeReroute")
        reroute_013_8.name = "Reroute.013"
        reroute_013_8.socket_idname = "NodeSocketFloat"
        #node Reroute.006
        reroute_006_9 = scale.nodes.new("NodeReroute")
        reroute_006_9.name = "Reroute.006"
        reroute_006_9.socket_idname = "NodeSocketFloat"
        #node Reroute.011
        reroute_011_9 = scale.nodes.new("NodeReroute")
        reroute_011_9.name = "Reroute.011"
        reroute_011_9.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_8 = scale.nodes.new("NodeReroute")
        reroute_007_8.name = "Reroute.007"
        reroute_007_8.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_9 = scale.nodes.new("NodeReroute")
        reroute_010_9.name = "Reroute.010"
        reroute_010_9.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_6 = scale.nodes.new("NodeReroute")
        reroute_015_6.name = "Reroute.015"
        reroute_015_6.socket_idname = "NodeSocketFloat"
        #node Reroute.009
        reroute_009_9 = scale.nodes.new("NodeReroute")
        reroute_009_9.name = "Reroute.009"
        reroute_009_9.socket_idname = "NodeSocketFloat"
        #node Reroute.014
        reroute_014_7 = scale.nodes.new("NodeReroute")
        reroute_014_7.name = "Reroute.014"
        reroute_014_7.socket_idname = "NodeSocketFloat"
        #node Separate XYZ.001
        separate_xyz_001_2 = scale.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_001_2.name = "Separate XYZ.001"

        #node Reroute.017
        reroute_017_6 = scale.nodes.new("NodeReroute")
        reroute_017_6.name = "Reroute.017"
        reroute_017_6.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_7 = scale.nodes.new("NodeReroute")
        reroute_016_7.name = "Reroute.016"
        reroute_016_7.socket_idname = "NodeSocketFloat"
        #node Reroute.018
        reroute_018_7 = scale.nodes.new("NodeReroute")
        reroute_018_7.name = "Reroute.018"
        reroute_018_7.socket_idname = "NodeSocketFloat"
        #node Reroute.020
        reroute_020_7 = scale.nodes.new("NodeReroute")
        reroute_020_7.name = "Reroute.020"
        reroute_020_7.socket_idname = "NodeSocketFloat"
        #node Reroute.019
        reroute_019_7 = scale.nodes.new("NodeReroute")
        reroute_019_7.name = "Reroute.019"
        reroute_019_7.socket_idname = "NodeSocketFloat"
        #node Reroute.021
        reroute_021_7 = scale.nodes.new("NodeReroute")
        reroute_021_7.name = "Reroute.021"
        reroute_021_7.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022_7 = scale.nodes.new("NodeReroute")
        reroute_022_7.name = "Reroute.022"
        reroute_022_7.socket_idname = "NodeSocketVector"
        #node Reroute.024
        reroute_024_6 = scale.nodes.new("NodeReroute")
        reroute_024_6.name = "Reroute.024"
        reroute_024_6.socket_idname = "NodeSocketFloat"
        #node Reroute.025
        reroute_025_6 = scale.nodes.new("NodeReroute")
        reroute_025_6.name = "Reroute.025"
        reroute_025_6.socket_idname = "NodeSocketFloat"
        #node Reroute.026
        reroute_026_5 = scale.nodes.new("NodeReroute")
        reroute_026_5.name = "Reroute.026"
        reroute_026_5.socket_idname = "NodeSocketFloat"
        #node Reroute.027
        reroute_027_5 = scale.nodes.new("NodeReroute")
        reroute_027_5.name = "Reroute.027"
        reroute_027_5.socket_idname = "NodeSocketFloat"
        #node Reroute.023
        reroute_023_6 = scale.nodes.new("NodeReroute")
        reroute_023_6.name = "Reroute.023"
        reroute_023_6.socket_idname = "NodeSocketVector"
        #node Group Input
        group_input_10 = scale.nodes.new("NodeGroupInput")
        group_input_10.name = "Group Input"
        group_input_10.use_custom_color = True
        group_input_10.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_10.outputs[5].hide = True

        #node X, Y, Z Multiplier.001
        x__y__z_multiplier_001 = scale.nodes.new("ShaderNodeGroup")
        x__y__z_multiplier_001.label = "X, Y, Z Multiplier"
        x__y__z_multiplier_001.name = "X, Y, Z Multiplier.001"
        x__y__z_multiplier_001.use_custom_color = True
        x__y__z_multiplier_001.color = (0.2052781730890274, 0.10875720530748367, 0.27383115887641907)
        x__y__z_multiplier_001.node_tree = x__y__z_multiplier_002


        #Set locations
        author_8.location = (-80.0, -80.0)
        combine_xyz_2.location = (-180.0, 0.0)
        group_output_10.location = (0.0, 0.0)
        reroute_10.location = (-200.6938018798828, -103.9406967163086)
        reroute_001_10.location = (-220.0, -82.35027313232422)
        reroute_002_10.location = (-200.0, -60.0)
        reroute_003_10.location = (-200.0, -34.41016387939453)
        math_6.location = (-380.0, 0.0)
        math_001_5.location = (-380.0, -180.0)
        math_002_2.location = (-380.0, -360.0)
        reroute_004_10.location = (-219.3061981201172, -214.4469757080078)
        reroute_005_9.location = (-200.0, -394.4469909667969)
        reroute_008_9.location = (-398.7164611816406, -115.50552368164062)
        reroute_012_8.location = (-400.0, -35.50551986694336)
        reroute_013_8.location = (-420.0, -56.78965759277344)
        reroute_006_9.location = (-440.0, -79.3579330444336)
        reroute_011_9.location = (-460.0, -137.43173217773438)
        reroute_007_8.location = (-420.0, -295.5055236816406)
        reroute_010_9.location = (-460.0, -317.4317321777344)
        reroute_015_6.location = (-480.0, -320.0)
        reroute_009_9.location = (-479.3582458496094, -497.4317321777344)
        reroute_014_7.location = (-440.0, -474.8634338378906)
        separate_xyz_001_2.location = (-640.0, -240.0)
        reroute_017_6.location = (-460.64178466796875, -275.5055236816406)
        reroute_016_7.location = (-460.0, -296.7896728515625)
        reroute_018_7.location = (-720.0, -200.0)
        reroute_020_7.location = (-680.0, -154.76760864257812)
        reroute_019_7.location = (-700.0, -176.78965759277344)
        reroute_021_7.location = (-661.2835693359375, -134.1255340576172)
        reroute_022_7.location = (-740.0, -344.4944763183594)
        reroute_024_6.location = (-661.2835693359375, -34.863441467285156)
        reroute_025_6.location = (-680.6417846679688, -56.147579193115234)
        reroute_026_5.location = (-700.0, -80.0)
        reroute_027_5.location = (-720.0, -100.6420669555664)
        reroute_023_6.location = (-740.0, -122.56827545166016)
        group_input_10.location = (-900.0, 0.0)
        x__y__z_multiplier_001.location = (-640.0, 0.0)

        #Set dimensions
        author_8.width, author_8.height = 269.55352783203125, 30.0
        combine_xyz_2.width, combine_xyz_2.height = 140.0, 100.0
        group_output_10.width, group_output_10.height = 140.0, 100.0
        reroute_10.width, reroute_10.height = 16.0, 100.0
        reroute_001_10.width, reroute_001_10.height = 16.0, 100.0
        reroute_002_10.width, reroute_002_10.height = 16.0, 100.0
        reroute_003_10.width, reroute_003_10.height = 16.0, 100.0
        math_6.width, math_6.height = 140.0, 100.0
        math_001_5.width, math_001_5.height = 140.0, 100.0
        math_002_2.width, math_002_2.height = 140.0, 100.0
        reroute_004_10.width, reroute_004_10.height = 16.0, 100.0
        reroute_005_9.width, reroute_005_9.height = 16.0, 100.0
        reroute_008_9.width, reroute_008_9.height = 16.0, 100.0
        reroute_012_8.width, reroute_012_8.height = 16.0, 100.0
        reroute_013_8.width, reroute_013_8.height = 16.0, 100.0
        reroute_006_9.width, reroute_006_9.height = 16.0, 100.0
        reroute_011_9.width, reroute_011_9.height = 16.0, 100.0
        reroute_007_8.width, reroute_007_8.height = 16.0, 100.0
        reroute_010_9.width, reroute_010_9.height = 16.0, 100.0
        reroute_015_6.width, reroute_015_6.height = 16.0, 100.0
        reroute_009_9.width, reroute_009_9.height = 16.0, 100.0
        reroute_014_7.width, reroute_014_7.height = 16.0, 100.0
        separate_xyz_001_2.width, separate_xyz_001_2.height = 140.0, 100.0
        reroute_017_6.width, reroute_017_6.height = 16.0, 100.0
        reroute_016_7.width, reroute_016_7.height = 16.0, 100.0
        reroute_018_7.width, reroute_018_7.height = 16.0, 100.0
        reroute_020_7.width, reroute_020_7.height = 16.0, 100.0
        reroute_019_7.width, reroute_019_7.height = 16.0, 100.0
        reroute_021_7.width, reroute_021_7.height = 16.0, 100.0
        reroute_022_7.width, reroute_022_7.height = 16.0, 100.0
        reroute_024_6.width, reroute_024_6.height = 16.0, 100.0
        reroute_025_6.width, reroute_025_6.height = 16.0, 100.0
        reroute_026_5.width, reroute_026_5.height = 16.0, 100.0
        reroute_027_5.width, reroute_027_5.height = 16.0, 100.0
        reroute_023_6.width, reroute_023_6.height = 16.0, 100.0
        group_input_10.width, group_input_10.height = 140.0, 100.0
        x__y__z_multiplier_001.width, x__y__z_multiplier_001.height = 140.0, 100.0

        #initialize scale links
        #reroute_011_9.Output -> math_6.Value
        scale.links.new(reroute_011_9.outputs[0], math_6.inputs[1])
        #reroute_010_9.Output -> math_001_5.Value
        scale.links.new(reroute_010_9.outputs[0], math_001_5.inputs[1])
        #reroute_009_9.Output -> math_002_2.Value
        scale.links.new(reroute_009_9.outputs[0], math_002_2.inputs[1])
        #reroute_002_10.Output -> combine_xyz_2.X
        scale.links.new(reroute_002_10.outputs[0], combine_xyz_2.inputs[0])
        #reroute_001_10.Output -> combine_xyz_2.Y
        scale.links.new(reroute_001_10.outputs[0], combine_xyz_2.inputs[1])
        #reroute_10.Output -> combine_xyz_2.Z
        scale.links.new(reroute_10.outputs[0], combine_xyz_2.inputs[2])
        #reroute_022_7.Output -> separate_xyz_001_2.Vector
        scale.links.new(reroute_022_7.outputs[0], separate_xyz_001_2.inputs[0])
        #combine_xyz_2.Vector -> group_output_10.Vector
        scale.links.new(combine_xyz_2.outputs[0], group_output_10.inputs[0])
        #reroute_008_9.Output -> math_6.Value
        scale.links.new(reroute_008_9.outputs[0], math_6.inputs[0])
        #reroute_007_8.Output -> math_001_5.Value
        scale.links.new(reroute_007_8.outputs[0], math_001_5.inputs[0])
        #reroute_014_7.Output -> math_002_2.Value
        scale.links.new(reroute_014_7.outputs[0], math_002_2.inputs[0])
        #reroute_021_7.Output -> x__y__z_multiplier_001.Factor
        scale.links.new(reroute_021_7.outputs[0], x__y__z_multiplier_001.inputs[0])
        #reroute_020_7.Output -> x__y__z_multiplier_001.X
        scale.links.new(reroute_020_7.outputs[0], x__y__z_multiplier_001.inputs[1])
        #reroute_019_7.Output -> x__y__z_multiplier_001.Y
        scale.links.new(reroute_019_7.outputs[0], x__y__z_multiplier_001.inputs[2])
        #reroute_018_7.Output -> x__y__z_multiplier_001.Z
        scale.links.new(reroute_018_7.outputs[0], x__y__z_multiplier_001.inputs[3])
        #reroute_005_9.Output -> reroute_10.Input
        scale.links.new(reroute_005_9.outputs[0], reroute_10.inputs[0])
        #reroute_004_10.Output -> reroute_001_10.Input
        scale.links.new(reroute_004_10.outputs[0], reroute_001_10.inputs[0])
        #reroute_003_10.Output -> reroute_002_10.Input
        scale.links.new(reroute_003_10.outputs[0], reroute_002_10.inputs[0])
        #math_6.Value -> reroute_003_10.Input
        scale.links.new(math_6.outputs[0], reroute_003_10.inputs[0])
        #math_001_5.Value -> reroute_004_10.Input
        scale.links.new(math_001_5.outputs[0], reroute_004_10.inputs[0])
        #math_002_2.Value -> reroute_005_9.Input
        scale.links.new(math_002_2.outputs[0], reroute_005_9.inputs[0])
        #x__y__z_multiplier_001.Z -> reroute_006_9.Input
        scale.links.new(x__y__z_multiplier_001.outputs[2], reroute_006_9.inputs[0])
        #reroute_013_8.Output -> reroute_007_8.Input
        scale.links.new(reroute_013_8.outputs[0], reroute_007_8.inputs[0])
        #reroute_012_8.Output -> reroute_008_9.Input
        scale.links.new(reroute_012_8.outputs[0], reroute_008_9.inputs[0])
        #reroute_015_6.Output -> reroute_009_9.Input
        scale.links.new(reroute_015_6.outputs[0], reroute_009_9.inputs[0])
        #reroute_016_7.Output -> reroute_010_9.Input
        scale.links.new(reroute_016_7.outputs[0], reroute_010_9.inputs[0])
        #reroute_017_6.Output -> reroute_011_9.Input
        scale.links.new(reroute_017_6.outputs[0], reroute_011_9.inputs[0])
        #x__y__z_multiplier_001.X -> reroute_012_8.Input
        scale.links.new(x__y__z_multiplier_001.outputs[0], reroute_012_8.inputs[0])
        #x__y__z_multiplier_001.Y -> reroute_013_8.Input
        scale.links.new(x__y__z_multiplier_001.outputs[1], reroute_013_8.inputs[0])
        #reroute_006_9.Output -> reroute_014_7.Input
        scale.links.new(reroute_006_9.outputs[0], reroute_014_7.inputs[0])
        #separate_xyz_001_2.Z -> reroute_015_6.Input
        scale.links.new(separate_xyz_001_2.outputs[2], reroute_015_6.inputs[0])
        #separate_xyz_001_2.Y -> reroute_016_7.Input
        scale.links.new(separate_xyz_001_2.outputs[1], reroute_016_7.inputs[0])
        #separate_xyz_001_2.X -> reroute_017_6.Input
        scale.links.new(separate_xyz_001_2.outputs[0], reroute_017_6.inputs[0])
        #reroute_027_5.Output -> reroute_018_7.Input
        scale.links.new(reroute_027_5.outputs[0], reroute_018_7.inputs[0])
        #reroute_026_5.Output -> reroute_019_7.Input
        scale.links.new(reroute_026_5.outputs[0], reroute_019_7.inputs[0])
        #reroute_025_6.Output -> reroute_020_7.Input
        scale.links.new(reroute_025_6.outputs[0], reroute_020_7.inputs[0])
        #reroute_024_6.Output -> reroute_021_7.Input
        scale.links.new(reroute_024_6.outputs[0], reroute_021_7.inputs[0])
        #reroute_023_6.Output -> reroute_022_7.Input
        scale.links.new(reroute_023_6.outputs[0], reroute_022_7.inputs[0])
        #group_input_10.Vector -> reroute_023_6.Input
        scale.links.new(group_input_10.outputs[4], reroute_023_6.inputs[0])
        #group_input_10.Factor -> reroute_024_6.Input
        scale.links.new(group_input_10.outputs[0], reroute_024_6.inputs[0])
        #group_input_10.X -> reroute_025_6.Input
        scale.links.new(group_input_10.outputs[1], reroute_025_6.inputs[0])
        #group_input_10.Y -> reroute_026_5.Input
        scale.links.new(group_input_10.outputs[2], reroute_026_5.inputs[0])
        #group_input_10.Z -> reroute_027_5.Input
        scale.links.new(group_input_10.outputs[3], reroute_027_5.inputs[0])
        return scale

    scale = scale_node_group()

    #initialize Mapping Ver. 4 node group
    def mapping_ver__4_node_group():

        mapping_ver__4 = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Mapping Ver. 4")

        mapping_ver__4.color_tag = 'NONE'
        mapping_ver__4.description = ""
        mapping_ver__4.default_group_node_width = 140
        

        #mapping_ver__4 interface
        #Socket Vector
        vector_socket_11 = mapping_ver__4.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        vector_socket_11.default_value = (0.0, 0.0, 0.0)
        vector_socket_11.min_value = 0.0
        vector_socket_11.max_value = 0.0
        vector_socket_11.subtype = 'NONE'
        vector_socket_11.attribute_domain = 'POINT'

        #Socket Grid View
        grid_view_socket = mapping_ver__4.interface.new_socket(name = "Grid View", in_out='OUTPUT', socket_type = 'NodeSocketColor')
        grid_view_socket.default_value = (0.0, 0.0, 0.0, 0.0)
        grid_view_socket.attribute_domain = 'POINT'

        #Socket Input Vector
        input_vector_socket = mapping_ver__4.interface.new_socket(name = "Input Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
        input_vector_socket.default_value = (0.0, 0.0, 0.0)
        input_vector_socket.min_value = -10000.0
        input_vector_socket.max_value = 10000.0
        input_vector_socket.subtype = 'NONE'
        input_vector_socket.attribute_domain = 'POINT'

        #Socket SCALE
        scale_socket = mapping_ver__4.interface.new_socket(name = "SCALE", in_out='INPUT', socket_type = 'NodeSocketFloat')
        scale_socket.default_value = 0.0
        scale_socket.min_value = -3.4028234663852886e+38
        scale_socket.max_value = 3.4028234663852886e+38
        scale_socket.subtype = 'NONE'
        scale_socket.attribute_domain = 'POINT'
        scale_socket.hide_value = True

        #Socket Global Scale
        global_scale_socket = mapping_ver__4.interface.new_socket(name = "Global Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        global_scale_socket.default_value = 5.0
        global_scale_socket.min_value = -10000.0
        global_scale_socket.max_value = 10000.0
        global_scale_socket.subtype = 'NONE'
        global_scale_socket.attribute_domain = 'POINT'

        #Socket     X Aspect Radio
        ____x_aspect_radio_socket = mapping_ver__4.interface.new_socket(name = "    X Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____x_aspect_radio_socket.default_value = 0.0
        ____x_aspect_radio_socket.min_value = -3.4028234663852886e+38
        ____x_aspect_radio_socket.max_value = 3.4028234663852886e+38
        ____x_aspect_radio_socket.subtype = 'NONE'
        ____x_aspect_radio_socket.attribute_domain = 'POINT'

        #Socket     Y Aspect Radio
        ____y_aspect_radio_socket = mapping_ver__4.interface.new_socket(name = "    Y Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____y_aspect_radio_socket.default_value = 5.0
        ____y_aspect_radio_socket.min_value = -10000.0
        ____y_aspect_radio_socket.max_value = 10000.0
        ____y_aspect_radio_socket.subtype = 'NONE'
        ____y_aspect_radio_socket.attribute_domain = 'POINT'

        #Socket     Z Aspect Radio
        ____z_aspect_radio_socket = mapping_ver__4.interface.new_socket(name = "    Z Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____z_aspect_radio_socket.default_value = 5.0
        ____z_aspect_radio_socket.min_value = -10000.0
        ____z_aspect_radio_socket.max_value = 10000.0
        ____z_aspect_radio_socket.subtype = 'NONE'
        ____z_aspect_radio_socket.attribute_domain = 'POINT'

        #Socket ROTATION
        rotation_socket = mapping_ver__4.interface.new_socket(name = "ROTATION", in_out='INPUT', socket_type = 'NodeSocketFloat')
        rotation_socket.default_value = 0.0
        rotation_socket.min_value = -3.4028234663852886e+38
        rotation_socket.max_value = 3.4028234663852886e+38
        rotation_socket.subtype = 'NONE'
        rotation_socket.attribute_domain = 'POINT'
        rotation_socket.hide_value = True

        #Socket Global Rotation
        global_rotation_socket = mapping_ver__4.interface.new_socket(name = "Global Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        global_rotation_socket.default_value = 0.0
        global_rotation_socket.min_value = -3.4028234663852886e+38
        global_rotation_socket.max_value = 3.4028234663852886e+38
        global_rotation_socket.subtype = 'ANGLE'
        global_rotation_socket.attribute_domain = 'POINT'

        #Socket    X Rotation
        ___x_rotation_socket = mapping_ver__4.interface.new_socket(name = "   X Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___x_rotation_socket.default_value = 0.0
        ___x_rotation_socket.min_value = -3.4028234663852886e+38
        ___x_rotation_socket.max_value = 3.4028234663852886e+38
        ___x_rotation_socket.subtype = 'NONE'
        ___x_rotation_socket.attribute_domain = 'POINT'

        #Socket    Y Rotation
        ___y_rotation_socket = mapping_ver__4.interface.new_socket(name = "   Y Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___y_rotation_socket.default_value = 0.0
        ___y_rotation_socket.min_value = -3.4028234663852886e+38
        ___y_rotation_socket.max_value = 3.4028234663852886e+38
        ___y_rotation_socket.subtype = 'NONE'
        ___y_rotation_socket.attribute_domain = 'POINT'

        #Socket    Z Rotation
        ___z_rotation_socket = mapping_ver__4.interface.new_socket(name = "   Z Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___z_rotation_socket.default_value = 0.0
        ___z_rotation_socket.min_value = -3.4028234663852886e+38
        ___z_rotation_socket.max_value = 3.4028234663852886e+38
        ___z_rotation_socket.subtype = 'NONE'
        ___z_rotation_socket.attribute_domain = 'POINT'

        #Socket TRANSLATION
        translation_socket = mapping_ver__4.interface.new_socket(name = "TRANSLATION", in_out='INPUT', socket_type = 'NodeSocketFloat')
        translation_socket.default_value = 0.0
        translation_socket.min_value = -3.4028234663852886e+38
        translation_socket.max_value = 3.4028234663852886e+38
        translation_socket.subtype = 'NONE'
        translation_socket.attribute_domain = 'POINT'
        translation_socket.hide_value = True

        #Socket    X Translate
        ___x_translate_socket = mapping_ver__4.interface.new_socket(name = "   X Translate", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___x_translate_socket.default_value = 0.0
        ___x_translate_socket.min_value = -10000.0
        ___x_translate_socket.max_value = 10000.0
        ___x_translate_socket.subtype = 'NONE'
        ___x_translate_socket.attribute_domain = 'POINT'

        #Socket    Y Translate
        ___y_translate_socket = mapping_ver__4.interface.new_socket(name = "   Y Translate", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___y_translate_socket.default_value = 0.0
        ___y_translate_socket.min_value = -10000.0
        ___y_translate_socket.max_value = 10000.0
        ___y_translate_socket.subtype = 'NONE'
        ___y_translate_socket.attribute_domain = 'POINT'

        #Socket    Z Translate
        ___z_translate_socket = mapping_ver__4.interface.new_socket(name = "   Z Translate", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ___z_translate_socket.default_value = 0.0
        ___z_translate_socket.min_value = -10000.0
        ___z_translate_socket.max_value = 10000.0
        ___z_translate_socket.subtype = 'NONE'
        ___z_translate_socket.attribute_domain = 'POINT'


        #initialize mapping_ver__4 nodes
        #node Node Group Description
        node_group_description_1 = mapping_ver__4.nodes.new("NodeFrame")
        node_group_description_1.label = "MAPPING NODE"
        node_group_description_1.name = "Node Group Description"
        node_group_description_1.use_custom_color = True
        node_group_description_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        node_group_description_1.label_size = 15
        node_group_description_1.shrink = True

        #node Author
        author_9 = mapping_ver__4.nodes.new("NodeFrame")
        author_9.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_9.name = "Author"
        author_9.use_custom_color = True
        author_9.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_9.label_size = 16
        author_9.shrink = True

        #node Reroute.004
        reroute_004_11 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_004_11.name = "Reroute.004"
        reroute_004_11.socket_idname = "NodeSocketVector"
        #node Group Output
        group_output_11 = mapping_ver__4.nodes.new("NodeGroupOutput")
        group_output_11.name = "Group Output"
        group_output_11.use_custom_color = True
        group_output_11.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_11.is_active_output = True
        group_output_11.inputs[2].hide = True

        #node Reroute.001
        reroute_001_11 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_001_11.name = "Reroute.001"
        reroute_001_11.socket_idname = "NodeSocketVector"
        #node Reroute
        reroute_11 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_11.name = "Reroute"
        reroute_11.socket_idname = "NodeSocketColor"
        #node Reroute.006
        reroute_006_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_006_10.name = "Reroute.006"
        reroute_006_10.socket_idname = "NodeSocketColor"
        #node Reroute.012
        reroute_012_9 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_012_9.name = "Reroute.012"
        reroute_012_9.socket_idname = "NodeSocketVector"
        #node Reroute.009
        reroute_009_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_009_10.name = "Reroute.009"
        reroute_009_10.socket_idname = "NodeSocketVector"
        #node Group Input.001
        group_input_001_1 = mapping_ver__4.nodes.new("NodeGroupInput")
        group_input_001_1.label = "Texture Coordinates"
        group_input_001_1.name = "Group Input.001"
        group_input_001_1.use_custom_color = True
        group_input_001_1.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_001_1.outputs[0].hide = True
        group_input_001_1.outputs[1].hide = True
        group_input_001_1.outputs[6].hide = True
        group_input_001_1.outputs[7].hide = True
        group_input_001_1.outputs[8].hide = True
        group_input_001_1.outputs[9].hide = True
        group_input_001_1.outputs[10].hide = True
        group_input_001_1.outputs[11].hide = True
        group_input_001_1.outputs[12].hide = True
        group_input_001_1.outputs[13].hide = True
        group_input_001_1.outputs[14].hide = True
        group_input_001_1.outputs[15].hide = True

        #node Reroute.011
        reroute_011_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_011_10.name = "Reroute.011"
        reroute_011_10.socket_idname = "NodeSocketFloat"
        #node Reroute.013
        reroute_013_9 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_013_9.name = "Reroute.013"
        reroute_013_9.socket_idname = "NodeSocketFloat"
        #node Reroute.014
        reroute_014_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_014_8.name = "Reroute.014"
        reroute_014_8.socket_idname = "NodeSocketFloat"
        #node Reroute.016
        reroute_016_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_016_8.name = "Reroute.016"
        reroute_016_8.socket_idname = "NodeSocketFloat"
        #node Reroute.015
        reroute_015_7 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_015_7.name = "Reroute.015"
        reroute_015_7.socket_idname = "NodeSocketFloat"
        #node Reroute.007
        reroute_007_9 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_007_9.name = "Reroute.007"
        reroute_007_9.socket_idname = "NodeSocketFloat"
        #node Reroute.008
        reroute_008_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_008_10.name = "Reroute.008"
        reroute_008_10.socket_idname = "NodeSocketFloat"
        #node Reroute.010
        reroute_010_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_010_10.name = "Reroute.010"
        reroute_010_10.socket_idname = "NodeSocketFloat"
        #node Vector Rotate
        vector_rotate = mapping_ver__4.nodes.new("ShaderNodeVectorRotate")
        vector_rotate.label = "Global Rotation"
        vector_rotate.name = "Vector Rotate"
        vector_rotate.invert = False
        vector_rotate.rotation_type = 'AXIS_ANGLE'
        vector_rotate.inputs[1].hide = True
        vector_rotate.inputs[2].hide = True
        vector_rotate.inputs[4].hide = True
        #Center
        vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
        #Axis
        vector_rotate.inputs[2].default_value = (0.0, 0.0, 1.0)

        #node Reroute.018
        reroute_018_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_018_8.name = "Reroute.018"
        reroute_018_8.socket_idname = "NodeSocketVector"
        #node Reroute.017
        reroute_017_7 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_017_7.name = "Reroute.017"
        reroute_017_7.socket_idname = "NodeSocketVector"
        #node Reroute.020
        reroute_020_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_020_8.name = "Reroute.020"
        reroute_020_8.socket_idname = "NodeSocketVector"
        #node Reroute.019
        reroute_019_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_019_8.name = "Reroute.019"
        reroute_019_8.socket_idname = "NodeSocketVector"
        #node Reroute.023
        reroute_023_7 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_023_7.name = "Reroute.023"
        reroute_023_7.socket_idname = "NodeSocketFloat"
        #node Reroute.022
        reroute_022_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_022_8.name = "Reroute.022"
        reroute_022_8.socket_idname = "NodeSocketVector"
        #node Reroute.021
        reroute_021_8 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_021_8.name = "Reroute.021"
        reroute_021_8.socket_idname = "NodeSocketVector"
        #node Reroute.024
        reroute_024_7 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_024_7.name = "Reroute.024"
        reroute_024_7.socket_idname = "NodeSocketFloat"
        #node Reroute.025
        reroute_025_7 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_025_7.name = "Reroute.025"
        reroute_025_7.socket_idname = "NodeSocketFloatAngle"
        #node Reroute.026
        reroute_026_6 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_026_6.name = "Reroute.026"
        reroute_026_6.socket_idname = "NodeSocketFloatAngle"
        #node Reroute.027
        reroute_027_6 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_027_6.name = "Reroute.027"
        reroute_027_6.socket_idname = "NodeSocketFloat"
        #node Reroute.031
        reroute_031_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_031_4.name = "Reroute.031"
        reroute_031_4.socket_idname = "NodeSocketVector"
        #node Reroute.030
        reroute_030_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_030_4.name = "Reroute.030"
        reroute_030_4.socket_idname = "NodeSocketFloat"
        #node Group Input.002
        group_input_002 = mapping_ver__4.nodes.new("NodeGroupInput")
        group_input_002.label = "Texture Coordinates"
        group_input_002.name = "Group Input.002"
        group_input_002.use_custom_color = True
        group_input_002.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_002.outputs[0].hide = True
        group_input_002.outputs[1].hide = True
        group_input_002.outputs[2].hide = True
        group_input_002.outputs[3].hide = True
        group_input_002.outputs[4].hide = True
        group_input_002.outputs[5].hide = True
        group_input_002.outputs[6].hide = True
        group_input_002.outputs[11].hide = True
        group_input_002.outputs[12].hide = True
        group_input_002.outputs[13].hide = True
        group_input_002.outputs[14].hide = True
        group_input_002.outputs[15].hide = True

        #node Reroute.029
        reroute_029_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_029_4.name = "Reroute.029"
        reroute_029_4.socket_idname = "NodeSocketFloat"
        #node Reroute.032
        reroute_032_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_032_4.name = "Reroute.032"
        reroute_032_4.socket_idname = "NodeSocketVector"
        #node Reroute.033
        reroute_033_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_033_4.name = "Reroute.033"
        reroute_033_4.socket_idname = "NodeSocketVector"
        #node Reroute.036
        reroute_036_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_036_4.name = "Reroute.036"
        reroute_036_4.socket_idname = "NodeSocketFloat"
        #node Reroute.040
        reroute_040_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_040_4.name = "Reroute.040"
        reroute_040_4.socket_idname = "NodeSocketVector"
        #node Group Input
        group_input_11 = mapping_ver__4.nodes.new("NodeGroupInput")
        group_input_11.label = "Texture Coordinates"
        group_input_11.name = "Group Input"
        group_input_11.use_custom_color = True
        group_input_11.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_11.outputs[1].hide = True
        group_input_11.outputs[2].hide = True
        group_input_11.outputs[3].hide = True
        group_input_11.outputs[4].hide = True
        group_input_11.outputs[5].hide = True
        group_input_11.outputs[6].hide = True
        group_input_11.outputs[7].hide = True
        group_input_11.outputs[8].hide = True
        group_input_11.outputs[9].hide = True
        group_input_11.outputs[10].hide = True
        group_input_11.outputs[11].hide = True
        group_input_11.outputs[15].hide = True

        #node Reroute.038
        reroute_038_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_038_4.name = "Reroute.038"
        reroute_038_4.socket_idname = "NodeSocketFloat"
        #node Reroute.037
        reroute_037_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_037_4.name = "Reroute.037"
        reroute_037_4.socket_idname = "NodeSocketFloat"
        #node Reroute.035
        reroute_035_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_035_4.name = "Reroute.035"
        reroute_035_4.socket_idname = "NodeSocketFloat"
        #node Reroute.034
        reroute_034_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_034_4.name = "Reroute.034"
        reroute_034_4.socket_idname = "NodeSocketFloat"
        #node Reroute.039
        reroute_039_4 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_039_4.name = "Reroute.039"
        reroute_039_4.socket_idname = "NodeSocketFloat"
        #node Reroute.003
        reroute_003_11 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_003_11.name = "Reroute.003"
        reroute_003_11.socket_idname = "NodeSocketVector"
        #node Reroute.002
        reroute_002_11 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_002_11.name = "Reroute.002"
        reroute_002_11.socket_idname = "NodeSocketVector"
        #node Reroute.005
        reroute_005_10 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_005_10.name = "Reroute.005"
        reroute_005_10.socket_idname = "NodeSocketVector"
        #node Grid View
        grid_view_1 = mapping_ver__4.nodes.new("ShaderNodeGroup")
        grid_view_1.label = "Grid View"
        grid_view_1.name = "Grid View"
        grid_view_1.use_custom_color = True
        grid_view_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        grid_view_1.node_tree = grid_view

        #node Reroute.028
        reroute_028_5 = mapping_ver__4.nodes.new("NodeReroute")
        reroute_028_5.name = "Reroute.028"
        reroute_028_5.socket_idname = "NodeSocketFloat"
        #node Y Rotation
        y_rotation_1 = mapping_ver__4.nodes.new("ShaderNodeGroup")
        y_rotation_1.label = "Y Rotation"
        y_rotation_1.name = "Y Rotation"
        y_rotation_1.use_custom_color = True
        y_rotation_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        y_rotation_1.node_tree = y_rotation

        #node X Rotation
        x_rotation_1 = mapping_ver__4.nodes.new("ShaderNodeGroup")
        x_rotation_1.label = "X Rotation"
        x_rotation_1.name = "X Rotation"
        x_rotation_1.use_custom_color = True
        x_rotation_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        x_rotation_1.node_tree = x_rotation

        #node Translation
        translation = mapping_ver__4.nodes.new("ShaderNodeGroup")
        translation.label = "Translation"
        translation.name = "Translation"
        translation.use_custom_color = True
        translation.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        translation.node_tree = translate_001

        #node Z Rotation
        z_rotation_1 = mapping_ver__4.nodes.new("ShaderNodeGroup")
        z_rotation_1.label = "Z Rotation"
        z_rotation_1.name = "Z Rotation"
        z_rotation_1.use_custom_color = True
        z_rotation_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        z_rotation_1.node_tree = z_rotation

        #node Scale
        scale_1 = mapping_ver__4.nodes.new("ShaderNodeGroup")
        scale_1.label = "Scale"
        scale_1.name = "Scale"
        scale_1.use_custom_color = True
        scale_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        scale_1.node_tree = scale


        #Set locations
        node_group_description_1.location = (-1240.0, 180.0)
        author_9.location = (200.0, -100.0)
        reroute_004_11.location = (80.0, -35.842655181884766)
        group_output_11.location = (300.18353271484375, 0.0)
        reroute_001_11.location = (280.18353271484375, -35.842655181884766)
        reroute_11.location = (261.187255859375, -57.03046798706055)
        reroute_006_10.location = (260.5936279296875, -35.248748779296875)
        reroute_012_9.location = (-100.46983337402344, -177.64974975585938)
        reroute_009_10.location = (-100.0, -35.299503326416016)
        group_input_001_1.location = (-340.0, -180.0)
        reroute_011_10.location = (-140.0, -260.0)
        reroute_013_9.location = (-180.6417694091797, -91.0111312866211)
        reroute_014_8.location = (-160.0, -112.93731689453125)
        reroute_016_8.location = (-140.6417694091797, -133.57937622070312)
        reroute_015_7.location = (-120.64176940917969, -156.1476287841797)
        reroute_007_9.location = (-180.0, -214.86351013183594)
        reroute_008_10.location = (-160.6417694091797, -237.43174743652344)
        reroute_010_10.location = (-120.0, -281.9261779785156)
        vector_rotate.location = (-340.0, 0.0)
        reroute_018_8.location = (-360.0, -115.14115142822266)
        reroute_017_7.location = (-360.0, -35.14114761352539)
        reroute_020_8.location = (-540.0, -112.30888366699219)
        reroute_019_8.location = (-540.0, -35.05570983886719)
        reroute_023_7.location = (-560.0, -90.43794250488281)
        reroute_022_8.location = (-740.5491333007812, -112.85824584960938)
        reroute_021_8.location = (-740.0, -35.05570983886719)
        reroute_024_7.location = (-760.5491333007812, -90.66078186035156)
        reroute_025_7.location = (-360.5936279296875, -137.03045654296875)
        reroute_026_6.location = (-361.7809143066406, -234.0609130859375)
        reroute_027_6.location = (-760.0, -278.81219482421875)
        reroute_031_4.location = (-940.0, -111.09136962890625)
        reroute_030_4.location = (-960.0, -89.8710708618164)
        group_input_002.location = (-1120.0, -200.0)
        reroute_029_4.location = (-960.4698486328125, -256.70965576171875)
        reroute_032_4.location = (-940.0, -35.077152252197266)
        reroute_033_4.location = (-1140.0, -89.87108612060547)
        reroute_036_4.location = (-1160.0, -111.75128936767578)
        reroute_040_4.location = (-1140.0, -35.041656494140625)
        group_input_11.location = (-1360.0, 0.0)
        reroute_038_4.location = (-1180.0, -79.05989837646484)
        reroute_037_4.location = (-1160.0, -55.769535064697266)
        reroute_035_4.location = (-1180.6728515625, -134.1015625)
        reroute_034_4.location = (-1199.060302734375, -156.7096405029297)
        reroute_039_4.location = (-1199.5301513671875, -100.72787475585938)
        reroute_003_11.location = (80.0, -120.0)
        reroute_002_11.location = (280.0, -120.0)
        reroute_005_10.location = (80.59363555908203, -90.69031524658203)
        grid_view_1.location = (100.0, 0.0)
        reroute_028_5.location = (-560.0, -301.2841491699219)
        y_rotation_1.location = (-720.0, 0.0)
        x_rotation_1.location = (-920.0, 0.0)
        translation.location = (-1120.0, 0.0)
        z_rotation_1.location = (-520.0, 0.0)
        scale_1.location = (-80.0, 0.0)

        #Set dimensions
        node_group_description_1.width, node_group_description_1.height = 379.257568359375, 172.431884765625
        author_9.width, author_9.height = 269.55352783203125, 30.0
        reroute_004_11.width, reroute_004_11.height = 16.0, 100.0
        group_output_11.width, group_output_11.height = 140.0, 100.0
        reroute_001_11.width, reroute_001_11.height = 16.0, 100.0
        reroute_11.width, reroute_11.height = 16.0, 100.0
        reroute_006_10.width, reroute_006_10.height = 16.0, 100.0
        reroute_012_9.width, reroute_012_9.height = 16.0, 100.0
        reroute_009_10.width, reroute_009_10.height = 16.0, 100.0
        group_input_001_1.width, group_input_001_1.height = 140.0, 100.0
        reroute_011_10.width, reroute_011_10.height = 16.0, 100.0
        reroute_013_9.width, reroute_013_9.height = 16.0, 100.0
        reroute_014_8.width, reroute_014_8.height = 16.0, 100.0
        reroute_016_8.width, reroute_016_8.height = 16.0, 100.0
        reroute_015_7.width, reroute_015_7.height = 16.0, 100.0
        reroute_007_9.width, reroute_007_9.height = 16.0, 100.0
        reroute_008_10.width, reroute_008_10.height = 16.0, 100.0
        reroute_010_10.width, reroute_010_10.height = 16.0, 100.0
        vector_rotate.width, vector_rotate.height = 140.0, 100.0
        reroute_018_8.width, reroute_018_8.height = 16.0, 100.0
        reroute_017_7.width, reroute_017_7.height = 16.0, 100.0
        reroute_020_8.width, reroute_020_8.height = 16.0, 100.0
        reroute_019_8.width, reroute_019_8.height = 16.0, 100.0
        reroute_023_7.width, reroute_023_7.height = 16.0, 100.0
        reroute_022_8.width, reroute_022_8.height = 16.0, 100.0
        reroute_021_8.width, reroute_021_8.height = 16.0, 100.0
        reroute_024_7.width, reroute_024_7.height = 16.0, 100.0
        reroute_025_7.width, reroute_025_7.height = 16.0, 100.0
        reroute_026_6.width, reroute_026_6.height = 16.0, 100.0
        reroute_027_6.width, reroute_027_6.height = 16.0, 100.0
        reroute_031_4.width, reroute_031_4.height = 16.0, 100.0
        reroute_030_4.width, reroute_030_4.height = 16.0, 100.0
        group_input_002.width, group_input_002.height = 140.0, 100.0
        reroute_029_4.width, reroute_029_4.height = 16.0, 100.0
        reroute_032_4.width, reroute_032_4.height = 16.0, 100.0
        reroute_033_4.width, reroute_033_4.height = 16.0, 100.0
        reroute_036_4.width, reroute_036_4.height = 16.0, 100.0
        reroute_040_4.width, reroute_040_4.height = 16.0, 100.0
        group_input_11.width, group_input_11.height = 140.0, 100.0
        reroute_038_4.width, reroute_038_4.height = 16.0, 100.0
        reroute_037_4.width, reroute_037_4.height = 16.0, 100.0
        reroute_035_4.width, reroute_035_4.height = 16.0, 100.0
        reroute_034_4.width, reroute_034_4.height = 16.0, 100.0
        reroute_039_4.width, reroute_039_4.height = 16.0, 100.0
        reroute_003_11.width, reroute_003_11.height = 16.0, 100.0
        reroute_002_11.width, reroute_002_11.height = 16.0, 100.0
        reroute_005_10.width, reroute_005_10.height = 16.0, 100.0
        grid_view_1.width, grid_view_1.height = 140.0, 100.0
        reroute_028_5.width, reroute_028_5.height = 16.0, 100.0
        y_rotation_1.width, y_rotation_1.height = 140.0, 100.0
        x_rotation_1.width, x_rotation_1.height = 140.0, 100.0
        translation.width, translation.height = 140.0, 100.0
        z_rotation_1.width, z_rotation_1.height = 140.0, 100.0
        scale_1.width, scale_1.height = 140.0, 100.0

        #initialize mapping_ver__4 links
        #reroute_036_4.Output -> translation.X
        mapping_ver__4.links.new(reroute_036_4.outputs[0], translation.inputs[1])
        #reroute_035_4.Output -> translation.Y
        mapping_ver__4.links.new(reroute_035_4.outputs[0], translation.inputs[2])
        #reroute_034_4.Output -> translation.Z
        mapping_ver__4.links.new(reroute_034_4.outputs[0], translation.inputs[3])
        #reroute_001_11.Output -> group_output_11.Vector
        mapping_ver__4.links.new(reroute_001_11.outputs[0], group_output_11.inputs[0])
        #reroute_033_4.Output -> translation.Vector
        mapping_ver__4.links.new(reroute_033_4.outputs[0], translation.inputs[0])
        #reroute_016_8.Output -> scale_1.Y
        mapping_ver__4.links.new(reroute_016_8.outputs[0], scale_1.inputs[2])
        #reroute_015_7.Output -> scale_1.Z
        mapping_ver__4.links.new(reroute_015_7.outputs[0], scale_1.inputs[3])
        #reroute_022_8.Output -> y_rotation_1.Vector
        mapping_ver__4.links.new(reroute_022_8.outputs[0], y_rotation_1.inputs[1])
        #reroute_020_8.Output -> z_rotation_1.Vector
        mapping_ver__4.links.new(reroute_020_8.outputs[0], z_rotation_1.inputs[1])
        #reroute_012_9.Output -> scale_1.Vector
        mapping_ver__4.links.new(reroute_012_9.outputs[0], scale_1.inputs[4])
        #reroute_018_8.Output -> vector_rotate.Vector
        mapping_ver__4.links.new(reroute_018_8.outputs[0], vector_rotate.inputs[0])
        #reroute_014_8.Output -> scale_1.X
        mapping_ver__4.links.new(reroute_014_8.outputs[0], scale_1.inputs[1])
        #reroute_031_4.Output -> x_rotation_1.Vector
        mapping_ver__4.links.new(reroute_031_4.outputs[0], x_rotation_1.inputs[1])
        #reroute_11.Output -> group_output_11.Grid View
        mapping_ver__4.links.new(reroute_11.outputs[0], group_output_11.inputs[1])
        #reroute_006_10.Output -> reroute_11.Input
        mapping_ver__4.links.new(reroute_006_10.outputs[0], reroute_11.inputs[0])
        #reroute_002_11.Output -> reroute_001_11.Input
        mapping_ver__4.links.new(reroute_002_11.outputs[0], reroute_001_11.inputs[0])
        #reroute_003_11.Output -> reroute_002_11.Input
        mapping_ver__4.links.new(reroute_003_11.outputs[0], reroute_002_11.inputs[0])
        #scale_1.Vector -> reroute_004_11.Input
        mapping_ver__4.links.new(scale_1.outputs[0], reroute_004_11.inputs[0])
        #reroute_005_10.Output -> grid_view_1.Vector
        mapping_ver__4.links.new(reroute_005_10.outputs[0], grid_view_1.inputs[0])
        #reroute_004_11.Output -> reroute_005_10.Input
        mapping_ver__4.links.new(reroute_004_11.outputs[0], reroute_005_10.inputs[0])
        #grid_view_1.Color -> reroute_006_10.Input
        mapping_ver__4.links.new(grid_view_1.outputs[0], reroute_006_10.inputs[0])
        #vector_rotate.Vector -> reroute_009_10.Input
        mapping_ver__4.links.new(vector_rotate.outputs[0], reroute_009_10.inputs[0])
        #reroute_009_10.Output -> reroute_012_9.Input
        mapping_ver__4.links.new(reroute_009_10.outputs[0], reroute_012_9.inputs[0])
        #group_input_001_1.Global Scale -> reroute_007_9.Input
        mapping_ver__4.links.new(group_input_001_1.outputs[2], reroute_007_9.inputs[0])
        #group_input_001_1.    X Aspect Radio -> reroute_008_10.Input
        mapping_ver__4.links.new(group_input_001_1.outputs[3], reroute_008_10.inputs[0])
        #group_input_001_1.    Y Aspect Radio -> reroute_011_10.Input
        mapping_ver__4.links.new(group_input_001_1.outputs[4], reroute_011_10.inputs[0])
        #group_input_001_1.    Z Aspect Radio -> reroute_010_10.Input
        mapping_ver__4.links.new(group_input_001_1.outputs[5], reroute_010_10.inputs[0])
        #reroute_007_9.Output -> reroute_013_9.Input
        mapping_ver__4.links.new(reroute_007_9.outputs[0], reroute_013_9.inputs[0])
        #reroute_008_10.Output -> reroute_014_8.Input
        mapping_ver__4.links.new(reroute_008_10.outputs[0], reroute_014_8.inputs[0])
        #reroute_010_10.Output -> reroute_015_7.Input
        mapping_ver__4.links.new(reroute_010_10.outputs[0], reroute_015_7.inputs[0])
        #reroute_011_10.Output -> reroute_016_8.Input
        mapping_ver__4.links.new(reroute_011_10.outputs[0], reroute_016_8.inputs[0])
        #reroute_013_9.Output -> scale_1.Factor
        mapping_ver__4.links.new(reroute_013_9.outputs[0], scale_1.inputs[0])
        #z_rotation_1.Vector -> reroute_017_7.Input
        mapping_ver__4.links.new(z_rotation_1.outputs[0], reroute_017_7.inputs[0])
        #reroute_017_7.Output -> reroute_018_8.Input
        mapping_ver__4.links.new(reroute_017_7.outputs[0], reroute_018_8.inputs[0])
        #reroute_025_7.Output -> vector_rotate.Angle
        mapping_ver__4.links.new(reroute_025_7.outputs[0], vector_rotate.inputs[3])
        #reroute_030_4.Output -> x_rotation_1.Angle
        mapping_ver__4.links.new(reroute_030_4.outputs[0], x_rotation_1.inputs[0])
        #reroute_024_7.Output -> y_rotation_1.Angle
        mapping_ver__4.links.new(reroute_024_7.outputs[0], y_rotation_1.inputs[0])
        #reroute_023_7.Output -> z_rotation_1.Angle
        mapping_ver__4.links.new(reroute_023_7.outputs[0], z_rotation_1.inputs[0])
        #y_rotation_1.Vector -> reroute_019_8.Input
        mapping_ver__4.links.new(y_rotation_1.outputs[0], reroute_019_8.inputs[0])
        #reroute_019_8.Output -> reroute_020_8.Input
        mapping_ver__4.links.new(reroute_019_8.outputs[0], reroute_020_8.inputs[0])
        #x_rotation_1.Vector -> reroute_021_8.Input
        mapping_ver__4.links.new(x_rotation_1.outputs[0], reroute_021_8.inputs[0])
        #reroute_021_8.Output -> reroute_022_8.Input
        mapping_ver__4.links.new(reroute_021_8.outputs[0], reroute_022_8.inputs[0])
        #reroute_028_5.Output -> reroute_023_7.Input
        mapping_ver__4.links.new(reroute_028_5.outputs[0], reroute_023_7.inputs[0])
        #reroute_027_6.Output -> reroute_024_7.Input
        mapping_ver__4.links.new(reroute_027_6.outputs[0], reroute_024_7.inputs[0])
        #reroute_026_6.Output -> reroute_025_7.Input
        mapping_ver__4.links.new(reroute_026_6.outputs[0], reroute_025_7.inputs[0])
        #group_input_002.Global Rotation -> reroute_026_6.Input
        mapping_ver__4.links.new(group_input_002.outputs[7], reroute_026_6.inputs[0])
        #group_input_002.   Y Rotation -> reroute_027_6.Input
        mapping_ver__4.links.new(group_input_002.outputs[9], reroute_027_6.inputs[0])
        #group_input_002.   Z Rotation -> reroute_028_5.Input
        mapping_ver__4.links.new(group_input_002.outputs[10], reroute_028_5.inputs[0])
        #group_input_002.   X Rotation -> reroute_029_4.Input
        mapping_ver__4.links.new(group_input_002.outputs[8], reroute_029_4.inputs[0])
        #reroute_029_4.Output -> reroute_030_4.Input
        mapping_ver__4.links.new(reroute_029_4.outputs[0], reroute_030_4.inputs[0])
        #reroute_032_4.Output -> reroute_031_4.Input
        mapping_ver__4.links.new(reroute_032_4.outputs[0], reroute_031_4.inputs[0])
        #translation.Vector -> reroute_032_4.Input
        mapping_ver__4.links.new(translation.outputs[0], reroute_032_4.inputs[0])
        #reroute_040_4.Output -> reroute_033_4.Input
        mapping_ver__4.links.new(reroute_040_4.outputs[0], reroute_033_4.inputs[0])
        #reroute_039_4.Output -> reroute_034_4.Input
        mapping_ver__4.links.new(reroute_039_4.outputs[0], reroute_034_4.inputs[0])
        #reroute_038_4.Output -> reroute_035_4.Input
        mapping_ver__4.links.new(reroute_038_4.outputs[0], reroute_035_4.inputs[0])
        #reroute_037_4.Output -> reroute_036_4.Input
        mapping_ver__4.links.new(reroute_037_4.outputs[0], reroute_036_4.inputs[0])
        #group_input_11.   X Translate -> reroute_037_4.Input
        mapping_ver__4.links.new(group_input_11.outputs[12], reroute_037_4.inputs[0])
        #group_input_11.   Y Translate -> reroute_038_4.Input
        mapping_ver__4.links.new(group_input_11.outputs[13], reroute_038_4.inputs[0])
        #group_input_11.   Z Translate -> reroute_039_4.Input
        mapping_ver__4.links.new(group_input_11.outputs[14], reroute_039_4.inputs[0])
        #group_input_11.Input Vector -> reroute_040_4.Input
        mapping_ver__4.links.new(group_input_11.outputs[0], reroute_040_4.inputs[0])
        #reroute_005_10.Output -> reroute_003_11.Input
        mapping_ver__4.links.new(reroute_005_10.outputs[0], reroute_003_11.inputs[0])
        return mapping_ver__4

    mapping_ver__4 = mapping_ver__4_node_group()

    #initialize Water node group
    def water_node_group():

        water = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "Water")

        water.color_tag = 'NONE'
        water.description = ""
        water.default_group_node_width = 140
        

        #water interface
        #Socket Shader
        shader_socket_2 = water.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
        shader_socket_2.attribute_domain = 'POINT'

        #Socket Displacement
        displacement_socket = water.interface.new_socket(name = "Displacement", in_out='OUTPUT', socket_type = 'NodeSocketVector')
        displacement_socket.default_value = (0.0, 0.0, 0.0)
        displacement_socket.min_value = -3.4028234663852886e+38
        displacement_socket.max_value = 3.4028234663852886e+38
        displacement_socket.subtype = 'NONE'
        displacement_socket.attribute_domain = 'POINT'

        #Socket Water Color
        water_color_socket = water.interface.new_socket(name = "Water Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        water_color_socket.default_value = (0.5593100190162659, 0.8119490146636963, 1.0, 1.0)
        water_color_socket.attribute_domain = 'POINT'

        #Socket Generated / Object (0/1)
        generated___object__0_1__socket = water.interface.new_socket(name = "Generated / Object (0/1)", in_out='INPUT', socket_type = 'NodeSocketFloat')
        generated___object__0_1__socket.default_value = 0.0
        generated___object__0_1__socket.min_value = 0.0
        generated___object__0_1__socket.max_value = 1.0
        generated___object__0_1__socket.subtype = 'NONE'
        generated___object__0_1__socket.attribute_domain = 'POINT'

        #Socket Waviness Global Scale
        waviness_global_scale_socket = water.interface.new_socket(name = "Waviness Global Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        waviness_global_scale_socket.default_value = 1.0
        waviness_global_scale_socket.min_value = -10000.0
        waviness_global_scale_socket.max_value = 10000.0
        waviness_global_scale_socket.subtype = 'NONE'
        waviness_global_scale_socket.attribute_domain = 'POINT'

        #Socket     X Aspect Radio
        ____x_aspect_radio_socket_1 = water.interface.new_socket(name = "    X Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____x_aspect_radio_socket_1.default_value = 1.0
        ____x_aspect_radio_socket_1.min_value = -3.4028234663852886e+38
        ____x_aspect_radio_socket_1.max_value = 3.4028234663852886e+38
        ____x_aspect_radio_socket_1.subtype = 'NONE'
        ____x_aspect_radio_socket_1.attribute_domain = 'POINT'

        #Socket     Y Aspect Radio
        ____y_aspect_radio_socket_1 = water.interface.new_socket(name = "    Y Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____y_aspect_radio_socket_1.default_value = 1.0
        ____y_aspect_radio_socket_1.min_value = -10000.0
        ____y_aspect_radio_socket_1.max_value = 10000.0
        ____y_aspect_radio_socket_1.subtype = 'NONE'
        ____y_aspect_radio_socket_1.attribute_domain = 'POINT'

        #Socket     Z Aspect Radio
        ____z_aspect_radio_socket_1 = water.interface.new_socket(name = "    Z Aspect Radio", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____z_aspect_radio_socket_1.default_value = 1.0
        ____z_aspect_radio_socket_1.min_value = -10000.0
        ____z_aspect_radio_socket_1.max_value = 10000.0
        ____z_aspect_radio_socket_1.subtype = 'NONE'
        ____z_aspect_radio_socket_1.attribute_domain = 'POINT'

        #Socket COLOR VARIATION
        color_variation_socket_1 = water.interface.new_socket(name = "COLOR VARIATION", in_out='INPUT', socket_type = 'NodeSocketFloat')
        color_variation_socket_1.default_value = 0.0
        color_variation_socket_1.min_value = -3.4028234663852886e+38
        color_variation_socket_1.max_value = 3.4028234663852886e+38
        color_variation_socket_1.subtype = 'FACTOR'
        color_variation_socket_1.attribute_domain = 'POINT'
        color_variation_socket_1.hide_value = True

        #Socket   Color Variation Scale
        __color_variation_scale_socket_1 = water.interface.new_socket(name = "  Color Variation Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_variation_scale_socket_1.default_value = 6.386778354644775
        __color_variation_scale_socket_1.min_value = 0.05000000074505806
        __color_variation_scale_socket_1.max_value = 10.0
        __color_variation_scale_socket_1.subtype = 'FACTOR'
        __color_variation_scale_socket_1.attribute_domain = 'POINT'

        #Socket   Color Variation Distortion
        __color_variation_distortion_socket_1 = water.interface.new_socket(name = "  Color Variation Distortion", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_variation_distortion_socket_1.default_value = 1.254807710647583
        __color_variation_distortion_socket_1.min_value = 0.0
        __color_variation_distortion_socket_1.max_value = 3.0
        __color_variation_distortion_socket_1.subtype = 'FACTOR'
        __color_variation_distortion_socket_1.attribute_domain = 'POINT'

        #Socket   Random Color Var
        __random_color_var_socket_1 = water.interface.new_socket(name = "  Random Color Var", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __random_color_var_socket_1.default_value = 1.0
        __random_color_var_socket_1.min_value = 0.0
        __random_color_var_socket_1.max_value = 1.0
        __random_color_var_socket_1.subtype = 'FACTOR'
        __random_color_var_socket_1.attribute_domain = 'POINT'

        #Socket COLOR ADJUSTMENTS
        color_adjustments_socket_1 = water.interface.new_socket(name = "COLOR ADJUSTMENTS", in_out='INPUT', socket_type = 'NodeSocketFloat')
        color_adjustments_socket_1.default_value = 0.0
        color_adjustments_socket_1.min_value = -3.4028234663852886e+38
        color_adjustments_socket_1.max_value = 3.4028234663852886e+38
        color_adjustments_socket_1.subtype = 'NONE'
        color_adjustments_socket_1.attribute_domain = 'POINT'
        color_adjustments_socket_1.hide_value = True

        #Socket   Unpaint
        __unpaint_socket_1 = water.interface.new_socket(name = "  Unpaint", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __unpaint_socket_1.default_value = 0.0
        __unpaint_socket_1.min_value = 0.0
        __unpaint_socket_1.max_value = 1.0
        __unpaint_socket_1.subtype = 'FACTOR'
        __unpaint_socket_1.attribute_domain = 'POINT'

        #Socket   Color Inverter
        __color_inverter_socket_1 = water.interface.new_socket(name = "  Color Inverter", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __color_inverter_socket_1.default_value = 0.0
        __color_inverter_socket_1.min_value = 0.0
        __color_inverter_socket_1.max_value = 1.0
        __color_inverter_socket_1.subtype = 'FACTOR'
        __color_inverter_socket_1.attribute_domain = 'POINT'

        #Socket   Contrast
        __contrast_socket_1 = water.interface.new_socket(name = "  Contrast", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __contrast_socket_1.default_value = 0.0
        __contrast_socket_1.min_value = -100.0
        __contrast_socket_1.max_value = 100.0
        __contrast_socket_1.subtype = 'NONE'
        __contrast_socket_1.attribute_domain = 'POINT'

        #Socket   Gamma
        __gamma_socket_1 = water.interface.new_socket(name = "  Gamma", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __gamma_socket_1.default_value = 1.0
        __gamma_socket_1.min_value = 0.0010000000474974513
        __gamma_socket_1.max_value = 10.0
        __gamma_socket_1.attribute_domain = 'POINT'

        #Socket   Hue / Sat Value
        __hue___sat_value_socket_1 = water.interface.new_socket(name = "  Hue / Sat Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __hue___sat_value_socket_1.default_value = 1.0
        __hue___sat_value_socket_1.min_value = 0.0
        __hue___sat_value_socket_1.max_value = 2.0
        __hue___sat_value_socket_1.subtype = 'NONE'
        __hue___sat_value_socket_1.attribute_domain = 'POINT'

        #Socket     Hue
        ____hue_socket_1 = water.interface.new_socket(name = "    Hue", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____hue_socket_1.default_value = 0.49999991059303284
        ____hue_socket_1.min_value = 0.0
        ____hue_socket_1.max_value = 1.0
        ____hue_socket_1.subtype = 'NONE'
        ____hue_socket_1.attribute_domain = 'POINT'

        #Socket     Saturation
        ____saturation_socket_1 = water.interface.new_socket(name = "    Saturation", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____saturation_socket_1.default_value = 1.0
        ____saturation_socket_1.min_value = 0.0
        ____saturation_socket_1.max_value = 2.0
        ____saturation_socket_1.subtype = 'NONE'
        ____saturation_socket_1.attribute_domain = 'POINT'

        #Socket BRIGHTNESS
        brightness_socket_1 = water.interface.new_socket(name = "BRIGHTNESS", in_out='INPUT', socket_type = 'NodeSocketFloat')
        brightness_socket_1.default_value = 0.0
        brightness_socket_1.min_value = -3.4028234663852886e+38
        brightness_socket_1.max_value = 3.4028234663852886e+38
        brightness_socket_1.subtype = 'NONE'
        brightness_socket_1.attribute_domain = 'POINT'
        brightness_socket_1.hide_value = True

        #Socket   Glowing Level
        __glowing_level_socket_1 = water.interface.new_socket(name = "  Glowing Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __glowing_level_socket_1.default_value = 1.100000023841858
        __glowing_level_socket_1.min_value = -3.4028234663852886e+38
        __glowing_level_socket_1.max_value = 3.4028234663852886e+38
        __glowing_level_socket_1.subtype = 'NONE'
        __glowing_level_socket_1.attribute_domain = 'POINT'

        #Socket   Brightness
        __brightness_socket_1 = water.interface.new_socket(name = "  Brightness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __brightness_socket_1.default_value = 0.0
        __brightness_socket_1.min_value = -100.0
        __brightness_socket_1.max_value = 100.0
        __brightness_socket_1.subtype = 'NONE'
        __brightness_socket_1.attribute_domain = 'POINT'

        #Socket   Dark / Bright Threshold
        __dark___bright_threshold_socket_1 = water.interface.new_socket(name = "  Dark / Bright Threshold", in_out='INPUT', socket_type = 'NodeSocketFloat')
        __dark___bright_threshold_socket_1.default_value = 2.5
        __dark___bright_threshold_socket_1.min_value = -10000.0
        __dark___bright_threshold_socket_1.max_value = 10000.0
        __dark___bright_threshold_socket_1.subtype = 'NONE'
        __dark___bright_threshold_socket_1.attribute_domain = 'POINT'

        #Socket     Dark Spot Intensity
        ____dark_spot_intensity_socket_1 = water.interface.new_socket(name = "    Dark Spot Intensity", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____dark_spot_intensity_socket_1.default_value = 0.0
        ____dark_spot_intensity_socket_1.min_value = 0.0
        ____dark_spot_intensity_socket_1.max_value = 1.0
        ____dark_spot_intensity_socket_1.subtype = 'FACTOR'
        ____dark_spot_intensity_socket_1.attribute_domain = 'POINT'

        #Socket     Bright Spot Intensity
        ____bright_spot_intensity_socket_1 = water.interface.new_socket(name = "    Bright Spot Intensity", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ____bright_spot_intensity_socket_1.default_value = 0.0
        ____bright_spot_intensity_socket_1.min_value = 0.0
        ____bright_spot_intensity_socket_1.max_value = 1.0
        ____bright_spot_intensity_socket_1.subtype = 'FACTOR'
        ____bright_spot_intensity_socket_1.attribute_domain = 'POINT'

        #Socket Emission Strength
        emission_strength_socket = water.interface.new_socket(name = "Emission Strength", in_out='INPUT', socket_type = 'NodeSocketFloat')
        emission_strength_socket.default_value = 1.0
        emission_strength_socket.min_value = -10000.0
        emission_strength_socket.max_value = 10000.0
        emission_strength_socket.subtype = 'NONE'
        emission_strength_socket.attribute_domain = 'POINT'

        #Socket Reflection Color
        reflection_color_socket_1 = water.interface.new_socket(name = "Reflection Color", in_out='INPUT', socket_type = 'NodeSocketColor')
        reflection_color_socket_1.default_value = (0.004776659421622753, 0.11193225532770157, 0.3324514925479889, 1.0)
        reflection_color_socket_1.attribute_domain = 'POINT'

        #Socket Reflection Factor
        reflection_factor_socket_1 = water.interface.new_socket(name = "Reflection Factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
        reflection_factor_socket_1.default_value = 0.25
        reflection_factor_socket_1.min_value = 0.0
        reflection_factor_socket_1.max_value = 1.0
        reflection_factor_socket_1.subtype = 'FACTOR'
        reflection_factor_socket_1.attribute_domain = 'POINT'

        #Socket IOR
        ior_socket = water.interface.new_socket(name = "IOR", in_out='INPUT', socket_type = 'NodeSocketFloat')
        ior_socket.default_value = 1.4500000476837158
        ior_socket.min_value = 0.0
        ior_socket.max_value = 1000.0
        ior_socket.subtype = 'NONE'
        ior_socket.attribute_domain = 'POINT'

        #Socket Roughness
        roughness_socket_4 = water.interface.new_socket(name = "Roughness", in_out='INPUT', socket_type = 'NodeSocketFloat')
        roughness_socket_4.default_value = 0.0
        roughness_socket_4.min_value = -10000.0
        roughness_socket_4.max_value = 10000.0
        roughness_socket_4.subtype = 'NONE'
        roughness_socket_4.attribute_domain = 'POINT'

        #Socket Waves Displacement
        waves_displacement_socket = water.interface.new_socket(name = "Waves Displacement", in_out='INPUT', socket_type = 'NodeSocketFloat')
        waves_displacement_socket.default_value = 0.25
        waves_displacement_socket.min_value = 0.0
        waves_displacement_socket.max_value = 1000.0
        waves_displacement_socket.subtype = 'NONE'
        waves_displacement_socket.attribute_domain = 'POINT'


        #initialize water nodes
        #node Author
        author_10 = water.nodes.new("NodeFrame")
        author_10.label = "By: Dr. Hacker \"BE HACK 2000\""
        author_10.name = "Author"
        author_10.use_custom_color = True
        author_10.color = (0.015208303928375244, 0.12743757665157318, 0.18447497487068176)
        author_10.label_size = 16
        author_10.shrink = True

        #node Group Output
        group_output_12 = water.nodes.new("NodeGroupOutput")
        group_output_12.name = "Group Output"
        group_output_12.use_custom_color = True
        group_output_12.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_output_12.is_active_output = True
        group_output_12.inputs[2].hide = True

        #node Displacement
        displacement = water.nodes.new("ShaderNodeDisplacement")
        displacement.name = "Displacement"
        displacement.space = 'OBJECT'
        displacement.inputs[1].hide = True
        #Midlevel
        displacement.inputs[1].default_value = 0.5

        #node Reflection.001
        reflection_001_1 = water.nodes.new("ShaderNodeGroup")
        reflection_001_1.label = "Reflection"
        reflection_001_1.name = "Reflection.001"
        reflection_001_1.use_custom_color = True
        reflection_001_1.color = (0.6080002188682556, 0.5312551856040955, 0.49913641810417175)
        reflection_001_1.node_tree = reflection_001
        reflection_001_1.inputs[4].hide = True
        reflection_001_1.outputs[1].hide = True
        #Input_7
        reflection_001_1.inputs[4].default_value = (0.0, 0.0, 0.0)

        #node Group Input.005
        group_input_005 = water.nodes.new("NodeGroupInput")
        group_input_005.name = "Group Input.005"
        group_input_005.use_custom_color = True
        group_input_005.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_005.outputs[0].hide = True
        group_input_005.outputs[1].hide = True
        group_input_005.outputs[2].hide = True
        group_input_005.outputs[3].hide = True
        group_input_005.outputs[4].hide = True
        group_input_005.outputs[5].hide = True
        group_input_005.outputs[6].hide = True
        group_input_005.outputs[7].hide = True
        group_input_005.outputs[8].hide = True
        group_input_005.outputs[9].hide = True
        group_input_005.outputs[10].hide = True
        group_input_005.outputs[11].hide = True
        group_input_005.outputs[12].hide = True
        group_input_005.outputs[13].hide = True
        group_input_005.outputs[14].hide = True
        group_input_005.outputs[15].hide = True
        group_input_005.outputs[16].hide = True
        group_input_005.outputs[17].hide = True
        group_input_005.outputs[18].hide = True
        group_input_005.outputs[19].hide = True
        group_input_005.outputs[20].hide = True
        group_input_005.outputs[21].hide = True
        group_input_005.outputs[22].hide = True
        group_input_005.outputs[23].hide = True
        group_input_005.outputs[24].hide = True
        group_input_005.outputs[27].hide = True
        group_input_005.outputs[28].hide = True
        group_input_005.outputs[30].hide = True

        #node Principled BSDF
        principled_bsdf = water.nodes.new("ShaderNodeBsdfPrincipled")
        principled_bsdf.name = "Principled BSDF"
        principled_bsdf.distribution = 'GGX'
        principled_bsdf.subsurface_method = 'RANDOM_WALK_SKIN'
        principled_bsdf.inputs[1].hide = True
        principled_bsdf.inputs[4].hide = True
        principled_bsdf.inputs[6].hide = True
        principled_bsdf.inputs[8].hide = True
        principled_bsdf.inputs[9].hide = True
        principled_bsdf.inputs[11].hide = True
        principled_bsdf.inputs[12].hide = True
        principled_bsdf.inputs[13].hide = True
        principled_bsdf.inputs[14].hide = True
        principled_bsdf.inputs[15].hide = True
        principled_bsdf.inputs[16].hide = True
        principled_bsdf.inputs[17].hide = True
        principled_bsdf.inputs[18].hide = True
        principled_bsdf.inputs[19].hide = True
        principled_bsdf.inputs[20].hide = True
        principled_bsdf.inputs[23].hide = True
        principled_bsdf.inputs[24].hide = True
        principled_bsdf.inputs[26].hide = True
        #Metallic
        principled_bsdf.inputs[1].default_value = 0.0
        #Alpha
        principled_bsdf.inputs[4].default_value = 1.0
        #Diffuse Roughness
        principled_bsdf.inputs[7].default_value = 0.0
        #Subsurface Weight
        principled_bsdf.inputs[8].default_value = 0.0
        #Subsurface Radius
        principled_bsdf.inputs[9].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
        #Subsurface Scale
        principled_bsdf.inputs[10].default_value = 0.05000000074505806
        #Subsurface IOR
        principled_bsdf.inputs[11].default_value = 1.0099999904632568
        #Subsurface Anisotropy
        principled_bsdf.inputs[12].default_value = 0.0
        #Specular IOR Level
        principled_bsdf.inputs[13].default_value = 0.5
        #Anisotropic
        principled_bsdf.inputs[15].default_value = 0.0
        #Anisotropic Rotation
        principled_bsdf.inputs[16].default_value = 0.0
        #Tangent
        principled_bsdf.inputs[17].default_value = (0.0, 0.0, 0.0)
        #Transmission Weight
        principled_bsdf.inputs[18].default_value = 1.0
        #Coat Weight
        principled_bsdf.inputs[19].default_value = 0.0
        #Coat Roughness
        principled_bsdf.inputs[20].default_value = 0.029999999329447746
        #Coat IOR
        principled_bsdf.inputs[21].default_value = 1.5
        #Coat Tint
        principled_bsdf.inputs[22].default_value = (1.0, 1.0, 1.0, 1.0)
        #Coat Normal
        principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
        #Sheen Weight
        principled_bsdf.inputs[24].default_value = 0.0
        #Sheen Roughness
        principled_bsdf.inputs[25].default_value = 0.5
        #Sheen Tint
        principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
        #Thin Film Thickness
        principled_bsdf.inputs[29].default_value = 0.0
        #Thin Film IOR
        principled_bsdf.inputs[30].default_value = 1.3300000429153442

        #node Math
        math_7 = water.nodes.new("ShaderNodeMath")
        math_7.name = "Math"
        math_7.operation = 'MULTIPLY'
        math_7.use_clamp = False
        math_7.inputs[1].hide = True
        math_7.inputs[2].hide = True
        #Value_001
        math_7.inputs[1].default_value = 0.009999999776482582

        #node Bump
        bump = water.nodes.new("ShaderNodeBump")
        bump.name = "Bump"
        bump.invert = False
        bump.inputs[0].hide = True
        bump.inputs[1].hide = True
        bump.inputs[3].hide = True
        #Strength
        bump.inputs[0].default_value = 0.20000000298023224
        #Distance
        bump.inputs[1].default_value = 1.0
        #Normal
        bump.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Group Input.004
        group_input_004 = water.nodes.new("NodeGroupInput")
        group_input_004.name = "Group Input.004"
        group_input_004.use_custom_color = True
        group_input_004.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_004.outputs[0].hide = True
        group_input_004.outputs[1].hide = True
        group_input_004.outputs[2].hide = True
        group_input_004.outputs[3].hide = True
        group_input_004.outputs[4].hide = True
        group_input_004.outputs[5].hide = True
        group_input_004.outputs[6].hide = True
        group_input_004.outputs[7].hide = True
        group_input_004.outputs[8].hide = True
        group_input_004.outputs[9].hide = True
        group_input_004.outputs[10].hide = True
        group_input_004.outputs[11].hide = True
        group_input_004.outputs[12].hide = True
        group_input_004.outputs[13].hide = True
        group_input_004.outputs[14].hide = True
        group_input_004.outputs[15].hide = True
        group_input_004.outputs[16].hide = True
        group_input_004.outputs[17].hide = True
        group_input_004.outputs[18].hide = True
        group_input_004.outputs[19].hide = True
        group_input_004.outputs[20].hide = True
        group_input_004.outputs[21].hide = True
        group_input_004.outputs[22].hide = True
        group_input_004.outputs[23].hide = True
        group_input_004.outputs[24].hide = True
        group_input_004.outputs[25].hide = True
        group_input_004.outputs[26].hide = True
        group_input_004.outputs[28].hide = True
        group_input_004.outputs[29].hide = True
        group_input_004.outputs[30].hide = True

        #node Color Variation Ver. 3.001
        color_variation_ver__3_001 = water.nodes.new("ShaderNodeGroup")
        color_variation_ver__3_001.label = "Color Variation Ver. 3"
        color_variation_ver__3_001.name = "Color Variation Ver. 3.001"
        color_variation_ver__3_001.use_custom_color = True
        color_variation_ver__3_001.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        color_variation_ver__3_001.node_tree = color_variation_ver__3

        #node Micro Roughness.002
        micro_roughness_002 = water.nodes.new("ShaderNodeGroup")
        micro_roughness_002.label = "Micro Roughness"
        micro_roughness_002.name = "Micro Roughness.002"
        micro_roughness_002.use_custom_color = True
        micro_roughness_002.color = (0.6079999804496765, 0.6079999804496765, 0.6079999804496765)
        micro_roughness_002.node_tree = micro_roughness
        micro_roughness_002.inputs[1].hide = True
        micro_roughness_002.inputs[2].hide = True
        #Input_7
        micro_roughness_002.inputs[1].default_value = 0.0
        #Input_5
        micro_roughness_002.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Group Input.003
        group_input_003 = water.nodes.new("NodeGroupInput")
        group_input_003.name = "Group Input.003"
        group_input_003.use_custom_color = True
        group_input_003.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_003.outputs[1].hide = True
        group_input_003.outputs[2].hide = True
        group_input_003.outputs[3].hide = True
        group_input_003.outputs[4].hide = True
        group_input_003.outputs[5].hide = True
        group_input_003.outputs[25].hide = True
        group_input_003.outputs[26].hide = True
        group_input_003.outputs[27].hide = True
        group_input_003.outputs[28].hide = True
        group_input_003.outputs[29].hide = True
        group_input_003.outputs[30].hide = True

        #node Noise Texture
        noise_texture_1 = water.nodes.new("ShaderNodeTexNoise")
        noise_texture_1.name = "Noise Texture"
        noise_texture_1.noise_dimensions = '4D'
        noise_texture_1.noise_type = 'FBM'
        noise_texture_1.normalize = True
        noise_texture_1.inputs[1].hide = True
        noise_texture_1.inputs[2].hide = True
        noise_texture_1.inputs[3].hide = True
        noise_texture_1.inputs[4].hide = True
        noise_texture_1.inputs[8].hide = True
        noise_texture_1.outputs[1].hide = True
        #W
        noise_texture_1.inputs[1].default_value = 0.004999999888241291
        #Scale
        noise_texture_1.inputs[2].default_value = 3.8999996185302734
        #Detail
        noise_texture_1.inputs[3].default_value = 2.0
        #Roughness
        noise_texture_1.inputs[4].default_value = 0.5666666626930237
        #Lacunarity
        noise_texture_1.inputs[5].default_value = 2.0
        #Distortion
        noise_texture_1.inputs[8].default_value = 0.0

        #node Group Input.002
        group_input_002_1 = water.nodes.new("NodeGroupInput")
        group_input_002_1.name = "Group Input.002"
        group_input_002_1.use_custom_color = True
        group_input_002_1.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_002_1.outputs[0].hide = True
        group_input_002_1.outputs[1].hide = True
        group_input_002_1.outputs[2].hide = True
        group_input_002_1.outputs[3].hide = True
        group_input_002_1.outputs[4].hide = True
        group_input_002_1.outputs[5].hide = True
        group_input_002_1.outputs[6].hide = True
        group_input_002_1.outputs[7].hide = True
        group_input_002_1.outputs[8].hide = True
        group_input_002_1.outputs[9].hide = True
        group_input_002_1.outputs[10].hide = True
        group_input_002_1.outputs[11].hide = True
        group_input_002_1.outputs[12].hide = True
        group_input_002_1.outputs[13].hide = True
        group_input_002_1.outputs[14].hide = True
        group_input_002_1.outputs[15].hide = True
        group_input_002_1.outputs[16].hide = True
        group_input_002_1.outputs[17].hide = True
        group_input_002_1.outputs[18].hide = True
        group_input_002_1.outputs[19].hide = True
        group_input_002_1.outputs[20].hide = True
        group_input_002_1.outputs[21].hide = True
        group_input_002_1.outputs[22].hide = True
        group_input_002_1.outputs[23].hide = True
        group_input_002_1.outputs[24].hide = True
        group_input_002_1.outputs[25].hide = True
        group_input_002_1.outputs[26].hide = True
        group_input_002_1.outputs[27].hide = True
        group_input_002_1.outputs[29].hide = True
        group_input_002_1.outputs[30].hide = True

        #node Mapping Ver. 3.1
        mapping_ver__3_1 = water.nodes.new("ShaderNodeGroup")
        mapping_ver__3_1.label = "Mapping Ver. 4"
        mapping_ver__3_1.name = "Mapping Ver. 3.1"
        mapping_ver__3_1.use_custom_color = True
        mapping_ver__3_1.color = (0.11353799700737, 0.30544498562812805, 0.6079999804496765)
        mapping_ver__3_1.node_tree = mapping_ver__4
        mapping_ver__3_1.inputs[1].hide = True
        mapping_ver__3_1.inputs[6].hide = True
        mapping_ver__3_1.inputs[7].hide = True
        mapping_ver__3_1.inputs[8].hide = True
        mapping_ver__3_1.inputs[9].hide = True
        mapping_ver__3_1.inputs[10].hide = True
        mapping_ver__3_1.inputs[11].hide = True
        mapping_ver__3_1.inputs[12].hide = True
        mapping_ver__3_1.inputs[13].hide = True
        mapping_ver__3_1.inputs[14].hide = True
        mapping_ver__3_1.outputs[1].hide = True
        #Input_24
        mapping_ver__3_1.inputs[1].default_value = 0.0
        #Input_25
        mapping_ver__3_1.inputs[6].default_value = 0.0
        #Input_22
        mapping_ver__3_1.inputs[7].default_value = 0.0
        #Input_11
        mapping_ver__3_1.inputs[8].default_value = 0.0
        #Input_13
        mapping_ver__3_1.inputs[9].default_value = 0.0
        #Input_15
        mapping_ver__3_1.inputs[10].default_value = 0.0
        #Input_26
        mapping_ver__3_1.inputs[11].default_value = 0.0
        #Input_3
        mapping_ver__3_1.inputs[12].default_value = 0.0
        #Input_5
        mapping_ver__3_1.inputs[13].default_value = 0.0
        #Input_7
        mapping_ver__3_1.inputs[14].default_value = 0.0

        #node Group Input.001
        group_input_001_2 = water.nodes.new("NodeGroupInput")
        group_input_001_2.name = "Group Input.001"
        group_input_001_2.use_custom_color = True
        group_input_001_2.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_001_2.outputs[0].hide = True
        group_input_001_2.outputs[1].hide = True
        group_input_001_2.outputs[6].hide = True
        group_input_001_2.outputs[7].hide = True
        group_input_001_2.outputs[8].hide = True
        group_input_001_2.outputs[9].hide = True
        group_input_001_2.outputs[10].hide = True
        group_input_001_2.outputs[11].hide = True
        group_input_001_2.outputs[12].hide = True
        group_input_001_2.outputs[13].hide = True
        group_input_001_2.outputs[14].hide = True
        group_input_001_2.outputs[15].hide = True
        group_input_001_2.outputs[16].hide = True
        group_input_001_2.outputs[17].hide = True
        group_input_001_2.outputs[18].hide = True
        group_input_001_2.outputs[19].hide = True
        group_input_001_2.outputs[20].hide = True
        group_input_001_2.outputs[21].hide = True
        group_input_001_2.outputs[22].hide = True
        group_input_001_2.outputs[23].hide = True
        group_input_001_2.outputs[24].hide = True
        group_input_001_2.outputs[25].hide = True
        group_input_001_2.outputs[26].hide = True
        group_input_001_2.outputs[27].hide = True
        group_input_001_2.outputs[28].hide = True
        group_input_001_2.outputs[29].hide = True
        group_input_001_2.outputs[30].hide = True

        #node Mix
        mix_2 = water.nodes.new("ShaderNodeMix")
        mix_2.name = "Mix"
        mix_2.blend_type = 'MIX'
        mix_2.clamp_factor = True
        mix_2.clamp_result = False
        mix_2.data_type = 'RGBA'
        mix_2.factor_mode = 'UNIFORM'

        #node Texture Coordinate
        texture_coordinate_1 = water.nodes.new("ShaderNodeTexCoord")
        texture_coordinate_1.name = "Texture Coordinate"
        texture_coordinate_1.from_instancer = False
        texture_coordinate_1.outputs[1].hide = True
        texture_coordinate_1.outputs[2].hide = True
        texture_coordinate_1.outputs[4].hide = True
        texture_coordinate_1.outputs[5].hide = True
        texture_coordinate_1.outputs[6].hide = True

        #node Math.001
        math_001_6 = water.nodes.new("ShaderNodeMath")
        math_001_6.name = "Math.001"
        math_001_6.operation = 'GREATER_THAN'
        math_001_6.use_clamp = True
        math_001_6.inputs[1].hide = True
        math_001_6.inputs[2].hide = True
        #Value_001
        math_001_6.inputs[1].default_value = 0.0

        #node Group Input
        group_input_12 = water.nodes.new("NodeGroupInput")
        group_input_12.name = "Group Input"
        group_input_12.use_custom_color = True
        group_input_12.color = (0.6151790022850037, 0.6093840003013611, 0.45541998744010925)
        group_input_12.outputs[0].hide = True
        group_input_12.outputs[2].hide = True
        group_input_12.outputs[3].hide = True
        group_input_12.outputs[4].hide = True
        group_input_12.outputs[5].hide = True
        group_input_12.outputs[6].hide = True
        group_input_12.outputs[7].hide = True
        group_input_12.outputs[8].hide = True
        group_input_12.outputs[9].hide = True
        group_input_12.outputs[10].hide = True
        group_input_12.outputs[11].hide = True
        group_input_12.outputs[12].hide = True
        group_input_12.outputs[13].hide = True
        group_input_12.outputs[14].hide = True
        group_input_12.outputs[15].hide = True
        group_input_12.outputs[16].hide = True
        group_input_12.outputs[17].hide = True
        group_input_12.outputs[18].hide = True
        group_input_12.outputs[19].hide = True
        group_input_12.outputs[20].hide = True
        group_input_12.outputs[21].hide = True
        group_input_12.outputs[22].hide = True
        group_input_12.outputs[23].hide = True
        group_input_12.outputs[24].hide = True
        group_input_12.outputs[25].hide = True
        group_input_12.outputs[26].hide = True
        group_input_12.outputs[27].hide = True
        group_input_12.outputs[28].hide = True
        group_input_12.outputs[29].hide = True
        group_input_12.outputs[30].hide = True

        #node Mix.001
        mix_001_1 = water.nodes.new("ShaderNodeMix")
        mix_001_1.name = "Mix.001"
        mix_001_1.blend_type = 'MIX'
        mix_001_1.clamp_factor = True
        mix_001_1.clamp_result = False
        mix_001_1.data_type = 'RGBA'
        mix_001_1.factor_mode = 'UNIFORM'
        #Factor_Float
        mix_001_1.inputs[0].default_value = 0.5
        #A_Color
        mix_001_1.inputs[6].default_value = (1.0, 1.0, 1.0, 1.0)


        #Set locations
        author_10.location = (540.0, -300.0)
        group_output_12.location = (620.0, 0.0)
        displacement.location = (460.0, -190.0)
        reflection_001_1.location = (460.0, 0.0)
        group_input_005.location = (300.0, -279.0)
        principled_bsdf.location = (300.0, 0.0)
        math_7.location = (140.0, -538.0)
        bump.location = (140.0, -685.0)
        group_input_004.location = (140.0, -807.0)
        color_variation_ver__3_001.location = (140.0, 0.0)
        micro_roughness_002.location = (-20.0, -124.0)
        group_input_003.location = (-20.0, -246.0)
        noise_texture_1.location = (-20.0, 0.0)
        group_input_002_1.location = (-180.0, -212.0)
        mapping_ver__3_1.location = (-180.0, 0.0)
        group_input_001_2.location = (-340.0, -186.0)
        mix_2.location = (-340.0, 0.0)
        texture_coordinate_1.location = (-500.0, -147.0)
        math_001_6.location = (-500.0, 0.0)
        group_input_12.location = (-660.0, 0.0)
        mix_001_1.location = (130.0, -120.0)

        #Set dimensions
        author_10.width, author_10.height = 290.42974853515625, 30.0
        group_output_12.width, group_output_12.height = 140.0, 100.0
        displacement.width, displacement.height = 140.0, 100.0
        reflection_001_1.width, reflection_001_1.height = 140.0, 100.0
        group_input_005.width, group_input_005.height = 140.0, 100.0
        principled_bsdf.width, principled_bsdf.height = 140.0, 100.0
        math_7.width, math_7.height = 140.0, 100.0
        bump.width, bump.height = 140.0, 100.0
        group_input_004.width, group_input_004.height = 140.0, 100.0
        color_variation_ver__3_001.width, color_variation_ver__3_001.height = 140.0, 100.0
        micro_roughness_002.width, micro_roughness_002.height = 140.0, 100.0
        group_input_003.width, group_input_003.height = 140.0, 100.0
        noise_texture_1.width, noise_texture_1.height = 140.0, 100.0
        group_input_002_1.width, group_input_002_1.height = 140.0, 100.0
        mapping_ver__3_1.width, mapping_ver__3_1.height = 140.0, 100.0
        group_input_001_2.width, group_input_001_2.height = 140.0, 100.0
        mix_2.width, mix_2.height = 140.0, 100.0
        texture_coordinate_1.width, texture_coordinate_1.height = 140.0, 100.0
        math_001_6.width, math_001_6.height = 140.0, 100.0
        group_input_12.width, group_input_12.height = 140.0, 100.0
        mix_001_1.width, mix_001_1.height = 140.0, 100.0

        #initialize water links
        #reflection_001_1.Shader -> group_output_12.Shader
        water.links.new(reflection_001_1.outputs[0], group_output_12.inputs[0])
        #displacement.Displacement -> group_output_12.Displacement
        water.links.new(displacement.outputs[0], group_output_12.inputs[1])
        #bump.Normal -> principled_bsdf.Normal
        water.links.new(bump.outputs[0], principled_bsdf.inputs[5])
        #noise_texture_1.Fac -> bump.Height
        water.links.new(noise_texture_1.outputs[0], bump.inputs[2])
        #color_variation_ver__3_001.Color -> principled_bsdf.Base Color
        water.links.new(color_variation_ver__3_001.outputs[0], principled_bsdf.inputs[0])
        #color_variation_ver__3_001.Color -> principled_bsdf.Emission Color
        water.links.new(color_variation_ver__3_001.outputs[0], principled_bsdf.inputs[27])
        #math_7.Value -> principled_bsdf.Emission Strength
        water.links.new(math_7.outputs[0], principled_bsdf.inputs[28])
        #principled_bsdf.BSDF -> reflection_001_1.Shader
        water.links.new(principled_bsdf.outputs[0], reflection_001_1.inputs[0])
        #mapping_ver__3_1.Vector -> noise_texture_1.Vector
        water.links.new(mapping_ver__3_1.outputs[0], noise_texture_1.inputs[0])
        #mix_2.Result -> mapping_ver__3_1.Input Vector
        water.links.new(mix_2.outputs[2], mapping_ver__3_1.inputs[0])
        #texture_coordinate_1.Generated -> mix_2.A
        water.links.new(texture_coordinate_1.outputs[0], mix_2.inputs[6])
        #texture_coordinate_1.Object -> mix_2.B
        water.links.new(texture_coordinate_1.outputs[3], mix_2.inputs[7])
        #math_001_6.Value -> mix_2.Factor
        water.links.new(math_001_6.outputs[0], mix_2.inputs[0])
        #micro_roughness_002.Roughness -> color_variation_ver__3_001.  Roughness
        water.links.new(micro_roughness_002.outputs[0], color_variation_ver__3_001.inputs[19])
        #micro_roughness_002.Roughness -> principled_bsdf.Roughness
        water.links.new(micro_roughness_002.outputs[0], principled_bsdf.inputs[2])
        #micro_roughness_002.Roughness -> reflection_001_1.Roughness
        water.links.new(micro_roughness_002.outputs[0], reflection_001_1.inputs[1])
        #bump.Normal -> displacement.Normal
        water.links.new(bump.outputs[0], displacement.inputs[3])
        #noise_texture_1.Fac -> displacement.Height
        water.links.new(noise_texture_1.outputs[0], displacement.inputs[0])
        #group_input_12.Generated / Object (0/1) -> math_001_6.Value
        water.links.new(group_input_12.outputs[1], math_001_6.inputs[0])
        #group_input_001_2.Waviness Global Scale -> mapping_ver__3_1.Global Scale
        water.links.new(group_input_001_2.outputs[2], mapping_ver__3_1.inputs[2])
        #group_input_001_2.    X Aspect Radio -> mapping_ver__3_1.    X Aspect Radio
        water.links.new(group_input_001_2.outputs[3], mapping_ver__3_1.inputs[3])
        #group_input_001_2.    Y Aspect Radio -> mapping_ver__3_1.    Y Aspect Radio
        water.links.new(group_input_001_2.outputs[4], mapping_ver__3_1.inputs[4])
        #group_input_001_2.    Z Aspect Radio -> mapping_ver__3_1.    Z Aspect Radio
        water.links.new(group_input_001_2.outputs[5], mapping_ver__3_1.inputs[5])
        #group_input_002_1.Roughness -> micro_roughness_002.Roughness
        water.links.new(group_input_002_1.outputs[28], micro_roughness_002.inputs[0])
        #group_input_003.Water Color -> color_variation_ver__3_001.Input Color
        water.links.new(group_input_003.outputs[0], color_variation_ver__3_001.inputs[0])
        #group_input_003.COLOR VARIATION -> color_variation_ver__3_001.COLOR VARIATION
        water.links.new(group_input_003.outputs[6], color_variation_ver__3_001.inputs[1])
        #group_input_003.  Color Variation Scale -> color_variation_ver__3_001.  Color Variation Scale
        water.links.new(group_input_003.outputs[7], color_variation_ver__3_001.inputs[2])
        #group_input_003.  Color Variation Distortion -> color_variation_ver__3_001.  Color Variation Distortion
        water.links.new(group_input_003.outputs[8], color_variation_ver__3_001.inputs[3])
        #group_input_003.  Random Color Var -> color_variation_ver__3_001.  Random Color Var
        water.links.new(group_input_003.outputs[9], color_variation_ver__3_001.inputs[4])
        #group_input_003.COLOR ADJUSTMENTS -> color_variation_ver__3_001.COLOR ADJUSTMENTS
        water.links.new(group_input_003.outputs[10], color_variation_ver__3_001.inputs[5])
        #group_input_003.  Unpaint -> color_variation_ver__3_001.  Unpaint
        water.links.new(group_input_003.outputs[11], color_variation_ver__3_001.inputs[6])
        #group_input_003.  Color Inverter -> color_variation_ver__3_001.  Color Inverter
        water.links.new(group_input_003.outputs[12], color_variation_ver__3_001.inputs[7])
        #group_input_003.  Contrast -> color_variation_ver__3_001.  Contrast
        water.links.new(group_input_003.outputs[13], color_variation_ver__3_001.inputs[8])
        #group_input_003.  Gamma -> color_variation_ver__3_001.  Gamma
        water.links.new(group_input_003.outputs[14], color_variation_ver__3_001.inputs[9])
        #group_input_003.  Hue / Sat Value -> color_variation_ver__3_001.  Hue / Sat Value
        water.links.new(group_input_003.outputs[15], color_variation_ver__3_001.inputs[10])
        #group_input_003.    Hue -> color_variation_ver__3_001.    Hue
        water.links.new(group_input_003.outputs[16], color_variation_ver__3_001.inputs[11])
        #group_input_003.    Saturation -> color_variation_ver__3_001.    Saturation
        water.links.new(group_input_003.outputs[17], color_variation_ver__3_001.inputs[12])
        #group_input_003.BRIGHTNESS -> color_variation_ver__3_001.BRIGHTNESS
        water.links.new(group_input_003.outputs[18], color_variation_ver__3_001.inputs[13])
        #group_input_003.  Glowing Level -> color_variation_ver__3_001.  Glowing Level
        water.links.new(group_input_003.outputs[19], color_variation_ver__3_001.inputs[14])
        #group_input_003.  Brightness -> color_variation_ver__3_001.  Brightness
        water.links.new(group_input_003.outputs[20], color_variation_ver__3_001.inputs[15])
        #group_input_003.  Dark / Bright Threshold -> color_variation_ver__3_001.  Dark / Bright Threshold
        water.links.new(group_input_003.outputs[21], color_variation_ver__3_001.inputs[16])
        #group_input_003.    Dark Spot Intensity -> color_variation_ver__3_001.    Dark Spot Intensity
        water.links.new(group_input_003.outputs[22], color_variation_ver__3_001.inputs[17])
        #group_input_003.    Bright Spot Intensity -> color_variation_ver__3_001.    Bright Spot Intensity
        water.links.new(group_input_003.outputs[23], color_variation_ver__3_001.inputs[18])
        #group_input_003.Emission Strength -> math_7.Value
        water.links.new(group_input_003.outputs[24], math_7.inputs[0])
        #group_input_004.IOR -> principled_bsdf.IOR
        water.links.new(group_input_004.outputs[27], principled_bsdf.inputs[3])
        #group_input_005.Waves Displacement -> displacement.Scale
        water.links.new(group_input_005.outputs[29], displacement.inputs[2])
        #group_input_005.Reflection Color -> reflection_001_1.Reflection Color
        water.links.new(group_input_005.outputs[25], reflection_001_1.inputs[2])
        #group_input_005.Reflection Factor -> reflection_001_1.Reflection Factor
        water.links.new(group_input_005.outputs[26], reflection_001_1.inputs[3])
        #color_variation_ver__3_001.Color -> mix_001_1.B
        water.links.new(color_variation_ver__3_001.outputs[0], mix_001_1.inputs[7])
        #mix_001_1.Result -> principled_bsdf.Specular Tint
        water.links.new(mix_001_1.outputs[2], principled_bsdf.inputs[14])
        return water

    water = water_node_group()

    #initialize Ocean.001 node group
    def ocean_001_node_group():

        ocean_001 = mat.node_tree
        #start with a clean node tree
        for node in ocean_001.nodes:
            ocean_001.nodes.remove(node)
        ocean_001.color_tag = 'NONE'
        ocean_001.description = ""
        ocean_001.default_group_node_width = 140
        

        #ocean_001 interface

        #initialize ocean_001 nodes
        #node Material Output
        material_output = ocean_001.nodes.new("ShaderNodeOutputMaterial")
        material_output.name = "Material Output"
        material_output.is_active_output = True
        material_output.target = 'ALL'
        material_output.inputs[1].hide = True
        material_output.inputs[3].hide = True
        #Thickness
        material_output.inputs[3].default_value = 0.0

        #node Water
        water_1 = ocean_001.nodes.new("ShaderNodeGroup")
        water_1.label = "Water"
        water_1.name = "Water"
        water_1.use_custom_color = True
        water_1.color = (0.01520800031721592, 0.1274379938840866, 0.18447500467300415)
        water_1.node_tree = water
        #Input_8
        water_1.inputs[0].default_value = (0.5593100190162659, 0.8119490146636963, 1.0, 1.0)
        #Input_2
        water_1.inputs[1].default_value = 0.0
        #Input_3
        water_1.inputs[2].default_value = 1.0
        #Input_4
        water_1.inputs[3].default_value = 1.0
        #Input_5
        water_1.inputs[4].default_value = 1.0
        #Input_6
        water_1.inputs[5].default_value = 1.0
        #Input_9
        water_1.inputs[6].default_value = 0.0
        #Input_10
        water_1.inputs[7].default_value = 6.386778354644775
        #Input_11
        water_1.inputs[8].default_value = 1.254807710647583
        #Input_12
        water_1.inputs[9].default_value = 1.0
        #Input_13
        water_1.inputs[10].default_value = 0.0
        #Input_14
        water_1.inputs[11].default_value = 0.0
        #Input_15
        water_1.inputs[12].default_value = 0.0
        #Input_16
        water_1.inputs[13].default_value = 0.0
        #Input_17
        water_1.inputs[14].default_value = 1.0
        #Input_18
        water_1.inputs[15].default_value = 1.0
        #Input_19
        water_1.inputs[16].default_value = 0.49999991059303284
        #Input_20
        water_1.inputs[17].default_value = 1.0
        #Input_21
        water_1.inputs[18].default_value = 0.0
        #Input_22
        water_1.inputs[19].default_value = 1.100000023841858
        #Input_23
        water_1.inputs[20].default_value = 0.0
        #Input_24
        water_1.inputs[21].default_value = 2.5
        #Input_25
        water_1.inputs[22].default_value = 0.0
        #Input_26
        water_1.inputs[23].default_value = 0.0
        #Input_27
        water_1.inputs[24].default_value = 1.0
        #Input_30
        water_1.inputs[25].default_value = (0.004776659421622753, 0.11193225532770157, 0.3324514925479889, 1.0)
        #Input_31
        water_1.inputs[26].default_value = 0.25
        #Input_28
        water_1.inputs[27].default_value = 1.4500000476837158
        #Input_7
        water_1.inputs[28].default_value = 0.0
        #Input_29
        water_1.inputs[29].default_value = 0.15000000596046448


        #Set locations
        material_output.location = (200.0, -20.0)
        water_1.location = (-60.0, -20.0)

        #Set dimensions
        material_output.width, material_output.height = 140.0, 100.0
        water_1.width, water_1.height = 240.0, 100.0

        #initialize ocean_001 links
        #water_1.Shader -> material_output.Surface
        ocean_001.links.new(water_1.outputs[0], material_output.inputs[0])
        #water_1.Displacement -> material_output.Displacement
        ocean_001.links.new(water_1.outputs[1], material_output.inputs[2])
        return ocean_001


    ocean_001_node_group()
    return mat

#HELPER FUNCTIONS TO PRINT NODE INPUTS (DEBUG)
def print_node_inputs(node):
    """Helper function to print all inputs of a node with their indices"""
    print(f"Node: {node.name}, Type: {node.type}")
    for i, input in enumerate(node.inputs):
        if hasattr(input, 'name'):
            print(f"  Input {i}: {input.name}, Default Value: {input.default_value}")
        else:
            print(f"  Input {i}: Default Value: {input.default_value}")

#CREATION OF BASIC TERRAIN NODE GROUP SETUP
def nodegroup_node_group():
    # Check if the nodegroup already exists
    if "NodeGroup" in bpy.data.node_groups:
        return bpy.data.node_groups["NodeGroup"]
    
    # Create a new node group
    nodegroup = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "NodeGroup")

    nodegroup.color_tag = 'NONE'
    nodegroup.description = ""
    nodegroup.default_group_node_width = 140
    
    #nodegroup interface
    #Socket Geometry
    geometry_socket = nodegroup.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Seed
    seed_socket = nodegroup.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
    seed_socket.default_value = 1
    seed_socket.min_value = -2147483648
    seed_socket.max_value = 2147483647
    seed_socket.subtype = 'NONE'
    seed_socket.attribute_domain = 'POINT'

    #Socket Vertices X
    vertices_x_socket = nodegroup.interface.new_socket(name = "Vertices X", in_out='INPUT', socket_type = 'NodeSocketInt')
    vertices_x_socket.default_value = 500
    vertices_x_socket.min_value = 2
    vertices_x_socket.max_value = 1000
    vertices_x_socket.subtype = 'NONE'
    vertices_x_socket.attribute_domain = 'POINT'

    #Socket Vertices Y
    vertices_y_socket = nodegroup.interface.new_socket(name = "Vertices Y", in_out='INPUT', socket_type = 'NodeSocketInt')
    vertices_y_socket.default_value = 500
    vertices_y_socket.min_value = 2
    vertices_y_socket.max_value = 1000
    vertices_y_socket.subtype = 'NONE'
    vertices_y_socket.attribute_domain = 'POINT'

    #Socket Subdivision
    subdivision_socket = nodegroup.interface.new_socket(name = "Subdivision", in_out='INPUT', socket_type = 'NodeSocketInt')
    subdivision_socket.default_value = 0
    subdivision_socket.min_value = 0
    subdivision_socket.max_value = 6
    subdivision_socket.subtype = 'NONE'
    subdivision_socket.attribute_domain = 'POINT'

    #Socket Size X
    size_x_socket = nodegroup.interface.new_socket(name = "Size X", in_out='INPUT', socket_type = 'NodeSocketFloat')
    size_x_socket.default_value = 4.0
    size_x_socket.min_value = 0.0
    size_x_socket.max_value = 3.4028234663852886e+38
    size_x_socket.subtype = 'DISTANCE'
    size_x_socket.attribute_domain = 'POINT'

    #Socket Size Y
    size_y_socket = nodegroup.interface.new_socket(name = "Size Y", in_out='INPUT', socket_type = 'NodeSocketFloat')
    size_y_socket.default_value = 4.0
    size_y_socket.min_value = 0.0
    size_y_socket.max_value = 3.4028234663852886e+38
    size_y_socket.subtype = 'DISTANCE'
    size_y_socket.attribute_domain = 'POINT'

    #Socket Scale
    scale_socket = nodegroup.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
    scale_socket.default_value = 0.6800000071525574
    scale_socket.min_value = -1000.0
    scale_socket.max_value = 1000.0
    scale_socket.subtype = 'NONE'
    scale_socket.attribute_domain = 'POINT'

    #Socket Detail
    detail_socket = nodegroup.interface.new_socket(name = "Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
    detail_socket.default_value = 15.0
    detail_socket.min_value = 0.0
    detail_socket.max_value = 15.0
    detail_socket.subtype = 'NONE'
    detail_socket.attribute_domain = 'POINT'

    #Socket Terrain Level
    terrain_level_socket = nodegroup.interface.new_socket(name = "Terrain Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
    terrain_level_socket.default_value = 0.4000000059604645
    terrain_level_socket.min_value = -3.4028234663852886e+38
    terrain_level_socket.max_value = 3.4028234663852886e+38
    terrain_level_socket.subtype = 'NONE'
    terrain_level_socket.attribute_domain = 'POINT'
    terrain_level_socket.description = "Default 0.400"

    #Socket Ground Level
    ground_level_socket = nodegroup.interface.new_socket(name = "Ground Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
    ground_level_socket.default_value = 0.0
    ground_level_socket.min_value = -3.4028234663852886e+38
    ground_level_socket.max_value = 3.4028234663852886e+38
    ground_level_socket.subtype = 'NONE'
    ground_level_socket.attribute_domain = 'POINT'

    #Socket Crater-Peaks
    crater_peaks_socket = nodegroup.interface.new_socket(name = "Crater-Peaks", in_out='INPUT', socket_type = 'NodeSocketFloat')
    crater_peaks_socket.default_value = 1.0
    crater_peaks_socket.min_value = -10.0
    crater_peaks_socket.max_value = 10.0
    crater_peaks_socket.subtype = 'NONE'
    crater_peaks_socket.attribute_domain = 'POINT'

    #Socket Mt Height
    mt_height_socket = nodegroup.interface.new_socket(name = "Mt Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
    mt_height_socket.default_value = 0.0
    mt_height_socket.min_value = 0.0
    mt_height_socket.max_value = 10.0
    mt_height_socket.subtype = 'NONE'
    mt_height_socket.attribute_domain = 'POINT'

    #Socket Rocky Surface
    rocky_surface_socket = nodegroup.interface.new_socket(name = "Rocky Surface", in_out='INPUT', socket_type = 'NodeSocketFloat')
    rocky_surface_socket.default_value = 0.0
    rocky_surface_socket.min_value = 0.0
    rocky_surface_socket.max_value = 0.10000000149011612
    rocky_surface_socket.subtype = 'FACTOR'
    rocky_surface_socket.attribute_domain = 'POINT'

    #Socket Terraces
    terraces_socket = nodegroup.interface.new_socket(name = "Terraces", in_out='INPUT', socket_type = 'NodeSocketFloat')
    terraces_socket.default_value = 1.0
    terraces_socket.min_value = 0.0
    terraces_socket.max_value = 1.0
    terraces_socket.subtype = 'FACTOR'
    terraces_socket.attribute_domain = 'POINT'

    #Socket Coast
    coast_socket = nodegroup.interface.new_socket(name = "Coast", in_out='INPUT', socket_type = 'NodeSocketFloat')
    coast_socket.default_value = 1.0
    coast_socket.min_value = 0.0
    coast_socket.max_value = 1.0
    coast_socket.subtype = 'NONE'
    coast_socket.attribute_domain = 'POINT'

    #initialize nodegroup nodes
    #node Group Output
    group_output = nodegroup.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Group Input
    group_input = nodegroup.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Grid
    grid = nodegroup.nodes.new("GeometryNodeMeshGrid")
    grid.name = "Grid"

    #node Set Position
    set_position = nodegroup.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    #Selection
    set_position.inputs[1].default_value = True
    #Position
    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)

    #node Noise Texture
    noise_texture = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '4D'
    noise_texture.noise_type = 'FBM'
    noise_texture.normalize = True
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture.inputs[5].default_value = 2.0
    #Distortion
    noise_texture.inputs[8].default_value = 0.0

    #node Combine XYZ
    combine_xyz = nodegroup.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"
    #X
    combine_xyz.inputs[0].default_value = 0.0
    #Y
    combine_xyz.inputs[1].default_value = 0.0

    #node Set Shade Smooth
    set_shade_smooth = nodegroup.nodes.new("GeometryNodeSetShadeSmooth")
    set_shade_smooth.name = "Set Shade Smooth"
    set_shade_smooth.domain = 'FACE'
    #Selection
    set_shade_smooth.inputs[1].default_value = True
    #Shade Smooth
    set_shade_smooth.inputs[2].default_value = True

    #node Mix
    mix = nodegroup.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'SCREEN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.06666666269302368

    #node Noise Texture.001
    noise_texture_001 = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    noise_texture_001.noise_type = 'FBM'
    noise_texture_001.normalize = True
    #Vector
    noise_texture_001.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Scale
    noise_texture_001.inputs[2].default_value = 3.5
    #Detail
    noise_texture_001.inputs[3].default_value = 15.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture_001.inputs[5].default_value = 2.0
    #Distortion
    noise_texture_001.inputs[8].default_value = 0.0

    #node Subdivide Mesh
    subdivide_mesh = nodegroup.nodes.new("GeometryNodeSubdivideMesh")
    subdivide_mesh.name = "Subdivide Mesh"

   #node Set Material
    set_material = nodegroup.nodes.new("GeometryNodeSetMaterial")
    set_material.name = "Set Material"
    #Selection
    set_material.inputs[1].default_value = True
    # Set the terrain material as default
    terrain_material = create_terrain_material()
    set_material.inputs[2].default_value = terrain_material

    #node Math
    math = nodegroup.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.0

    #node Color Ramp.002
    color_ramp_002 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_002.name = "Color Ramp.002"
    color_ramp_002.color_ramp.color_mode = 'RGB'
    color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_002.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
    color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
    color_ramp_002_cre_0.position = 0.0
    color_ramp_002_cre_0.alpha = 1.0
    color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(0.45909082889556885)
    color_ramp_002_cre_1.alpha = 1.0
    color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)


    #node Mix.002
    mix_002 = nodegroup.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'

    #node Color Ramp.003
    color_ramp_003 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_003.name = "Color Ramp.003"
    color_ramp_003.color_ramp.color_mode = 'RGB'
    color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_003.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
    color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
    color_ramp_003_cre_0.position = 0.45909082889556885
    color_ramp_003_cre_0.alpha = 1.0
    color_ramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.6363638639450073)
    color_ramp_003_cre_1.alpha = 1.0
    color_ramp_003_cre_1.color = (0.9051787853240967, 0.9051787853240967, 0.9051787853240967, 1.0)


    #node Mix.003
    mix_003 = nodegroup.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    #B_Color
    mix_003.inputs[7].default_value = (0.9529872536659241, 0.9529872536659241, 0.9529872536659241, 1.0)

    #node Color Ramp.004
    color_ramp_004 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_004.name = "Color Ramp.004"
    color_ramp_004.color_ramp.color_mode = 'RGB'
    color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_004.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
    color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
    color_ramp_004_cre_0.position = 0.6363638639450073
    color_ramp_004_cre_0.alpha = 1.0
    color_ramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(1.0)
    color_ramp_004_cre_1.alpha = 1.0
    color_ramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)


    #node Mix.004
    mix_004 = nodegroup.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MIX'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'

    #node Group Input.001
    group_input_001 = nodegroup.nodes.new("NodeGroupInput")
    group_input_001.name = "Group Input.001"

    #node Math.001
    math_001 = nodegroup.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 0.0

    #node Math.002
    math_002 = nodegroup.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False

    #node Noise Texture.002
    noise_texture_002 = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    noise_texture_002.noise_type = 'MULTIFRACTAL'
    noise_texture_002.normalize = True
    #Vector
    noise_texture_002.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Scale
    noise_texture_002.inputs[2].default_value = 3.3899998664855957
    #Detail
    noise_texture_002.inputs[3].default_value = 15.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture_002.inputs[5].default_value = 2.0
    #Distortion
    noise_texture_002.inputs[8].default_value = 0.0

    #node Mix.001
    mix_001 = nodegroup.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'SCREEN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'

    #node Position
    position = nodegroup.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"

    #node RGB Curves
    rgb_curves = nodegroup.nodes.new("ShaderNodeRGBCurve")
    rgb_curves.name = "RGB Curves"
    #mapping settings
    rgb_curves.mapping.extend = 'EXTRAPOLATED'
    rgb_curves.mapping.tone = 'STANDARD'
    rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
    rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
    rgb_curves.mapping.clip_min_x = 0.0
    rgb_curves.mapping.clip_min_y = 0.0
    rgb_curves.mapping.clip_max_x = 1.0
    rgb_curves.mapping.clip_max_y = 1.0
    rgb_curves.mapping.use_clip = True
    #curve 0
    rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
    rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
    rgb_curves_curve_0_point_0.location = (0.0, 0.0)
    rgb_curves_curve_0_point_0.handle_type = 'AUTO'
    rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
    rgb_curves_curve_0_point_1.location = (1.0, 1.0)
    rgb_curves_curve_0_point_1.handle_type = 'AUTO'
    #curve 1
    rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
    rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
    rgb_curves_curve_1_point_0.location = (0.0, 0.0)
    rgb_curves_curve_1_point_0.handle_type = 'AUTO'
    rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
    rgb_curves_curve_1_point_1.location = (1.0, 1.0)
    rgb_curves_curve_1_point_1.handle_type = 'AUTO'
    #curve 2
    rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
    rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
    rgb_curves_curve_2_point_0.location = (0.0, 0.0)
    rgb_curves_curve_2_point_0.handle_type = 'AUTO'
    rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
    rgb_curves_curve_2_point_1.location = (1.0, 1.0)
    rgb_curves_curve_2_point_1.handle_type = 'AUTO'
    #curve 3
    rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
    rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
    rgb_curves_curve_3_point_0.location = (0.0, 0.0)
    rgb_curves_curve_3_point_0.handle_type = 'AUTO'
    rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
    rgb_curves_curve_3_point_1.location = (0.5363636612892151, 0.42499998211860657)
    rgb_curves_curve_3_point_1.handle_type = 'AUTO'
    rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(0.613636314868927, 0.49374985694885254)
    rgb_curves_curve_3_point_2.handle_type = 'AUTO'
    rgb_curves_curve_3_point_3 = rgb_curves_curve_3.points.new(0.668181836605072, 0.637499988079071)
    rgb_curves_curve_3_point_3.handle_type = 'AUTO'
    rgb_curves_curve_3_point_4 = rgb_curves_curve_3.points.new(0.7636362910270691, 0.6374997496604919)
    rgb_curves_curve_3_point_4.handle_type = 'AUTO'
    rgb_curves_curve_3_point_5 = rgb_curves_curve_3.points.new(0.8227272629737854, 0.7500001788139343)
    rgb_curves_curve_3_point_5.handle_type = 'AUTO'
    rgb_curves_curve_3_point_6 = rgb_curves_curve_3.points.new(0.8909090757369995, 0.7812500596046448)
    rgb_curves_curve_3_point_6.handle_type = 'AUTO'
    rgb_curves_curve_3_point_7 = rgb_curves_curve_3.points.new(1.0, 1.0)
    rgb_curves_curve_3_point_7.handle_type = 'AUTO'
    #update curve after changes
    rgb_curves.mapping.update()

    #node Gradient Texture
    gradient_texture = nodegroup.nodes.new("ShaderNodeTexGradient")
    gradient_texture.name = "Gradient Texture"
    gradient_texture.gradient_type = 'EASING'
    #Vector
    gradient_texture.inputs[0].default_value = (0.0, 0.0, 0.0)

    #node Mix.005
    mix_005 = nodegroup.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #B_Color
    mix_005.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

    #node Color Ramp
    color_ramp = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp.name = "Color Ramp"
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.0
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (0.6441415548324585, 0.6441415548324585, 0.6441415548324585, 1.0)


    #node Math.003
    math_003 = nodegroup.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'SUBTRACT'
    math_003.use_clamp = False

    #Set locations
    group_output.location = (2106.5263671875, 679.0626220703125)
    group_input.location = (-1483.561767578125, 846.4334106445312)
    grid.location = (-558.6212158203125, 880.4542236328125)
    set_position.location = (1489.33544921875, 630.9581909179688)
    noise_texture.location = (-850.8815307617188, 541.4349975585938)
    combine_xyz.location = (1411.3565673828125, 369.5991516113281)
    set_shade_smooth.location = (1716.7391357421875, 674.7537841796875)
    mix.location = (-527.2388305664062, 528.0447387695312)
    noise_texture_001.location = (-1175.586669921875, -45.813323974609375)
    subdivide_mesh.location = (-223.39418029785156, 1070.2113037109375)
    set_material.location = (1901.5416259765625, 645.5176391601562)
    math.location = (-253.07687377929688, 727.7000732421875)
    color_ramp_002.location = (85.35531616210938, 380.3711853027344)
    mix_002.location = (398.1470642089844, 650.145263671875)
    color_ramp_003.location = (84.8779296875, 641.70703125)
    mix_003.location = (414.3746337890625, 924.3941650390625)
    color_ramp_004.location = (80.38967895507812, 889.6439819335938)
    mix_004.location = (388.44976806640625, 384.89068603515625)
    group_input_001.location = (253.38406372070312, -473.54949951171875)
    math_001.location = (-910.203125, 138.1107940673828)
    math_002.location = (-716.3067626953125, 169.30357360839844)
    noise_texture_002.location = (-1381.625732421875, 208.96961975097656)
    mix_001.location = (-1104.19775390625, 439.6932373046875)
    position.location = (-1414.175048828125, 478.4564514160156)
    rgb_curves.location = (506.13531494140625, 18.746463775634766)
    gradient_texture.location = (517.1767578125, -472.67889404296875)
    mix_005.location = (1231.0, 229.2410888671875)
    color_ramp.location = (770.954345703125, -183.71435546875)
    math_003.location = (1051.0, -42.764930725097656)

    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    grid.width, grid.height = 140.0, 100.0
    set_position.width, set_position.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
    set_material.width, set_material.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    color_ramp_003.width, color_ramp_003.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    color_ramp_004.width, color_ramp_004.height = 240.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    group_input_001.width, group_input_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0
    rgb_curves.width, rgb_curves.height = 240.0, 100.0
    gradient_texture.width, gradient_texture.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    color_ramp.width, color_ramp.height = 240.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0

    #initialize nodegroup links
    #set_position.Geometry -> set_shade_smooth.Geometry
    nodegroup.links.new(set_position.outputs[0], set_shade_smooth.inputs[0])
    #combine_xyz.Vector -> set_position.Offset
    nodegroup.links.new(combine_xyz.outputs[0], set_position.inputs[3])
    #noise_texture.Fac -> mix.A
    nodegroup.links.new(noise_texture.outputs[0], mix.inputs[6])
    #subdivide_mesh.Mesh -> set_position.Geometry
    nodegroup.links.new(subdivide_mesh.outputs[0], set_position.inputs[0])
    #set_material.Geometry -> group_output.Geometry
    nodegroup.links.new(set_material.outputs[0], group_output.inputs[0])
    #group_input.Seed -> noise_texture.W
    nodegroup.links.new(group_input.outputs[0], noise_texture.inputs[1])
    #grid.Mesh -> subdivide_mesh.Mesh
    nodegroup.links.new(grid.outputs[0], subdivide_mesh.inputs[0])
    #group_input.Subdivision -> subdivide_mesh.Level
    nodegroup.links.new(group_input.outputs[3], subdivide_mesh.inputs[1])
    #group_input.Size X -> grid.Size X
    nodegroup.links.new(group_input.outputs[4], grid.inputs[0])
    #group_input.Size Y -> grid.Size Y
    nodegroup.links.new(group_input.outputs[5], grid.inputs[1])
    #set_shade_smooth.Geometry -> set_material.Geometry
    nodegroup.links.new(set_shade_smooth.outputs[0], set_material.inputs[0])
    #group_input.Scale -> noise_texture.Scale
    nodegroup.links.new(group_input.outputs[6], noise_texture.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    nodegroup.links.new(group_input.outputs[7], noise_texture.inputs[3])
    #math.Value -> color_ramp_002.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_002.inputs[0])
    #color_ramp_002.Color -> mix_002.Factor
    nodegroup.links.new(color_ramp_002.outputs[0], mix_002.inputs[0])
    #math.Value -> color_ramp_003.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_003.inputs[0])
    #color_ramp_003.Color -> mix_003.Factor
    nodegroup.links.new(color_ramp_003.outputs[0], mix_003.inputs[0])
    #mix_002.Result -> mix_003.A
    nodegroup.links.new(mix_002.outputs[2], mix_003.inputs[6])
    #math.Value -> color_ramp_004.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_004.inputs[0])
    #mix_003.Result -> mix_004.A
    nodegroup.links.new(mix_003.outputs[2], mix_004.inputs[6])
    #color_ramp_004.Color -> mix_004.Factor
    nodegroup.links.new(color_ramp_004.outputs[0], mix_004.inputs[0])
    #group_input_001.Ground Level -> mix_002.A
    nodegroup.links.new(group_input_001.outputs[9], mix_002.inputs[6])
    #group_input_001.Terrain Level -> mix_002.B
    nodegroup.links.new(group_input_001.outputs[8], mix_002.inputs[7])
    #group_input_001.Crater-Peaks -> mix_004.B
    nodegroup.links.new(group_input_001.outputs[10], mix_004.inputs[7])
    #group_input.Vertices X -> grid.Vertices X
    nodegroup.links.new(group_input.outputs[1], grid.inputs[2])
    #group_input.Vertices Y -> grid.Vertices Y
    nodegroup.links.new(group_input.outputs[2], grid.inputs[3])
    #math_001.Value -> math_002.Value
    nodegroup.links.new(math_001.outputs[0], math_002.inputs[0])
    #noise_texture_001.Fac -> math_001.Value
    nodegroup.links.new(noise_texture_001.outputs[0], math_001.inputs[1])
    #math_002.Value -> mix.B
    nodegroup.links.new(math_002.outputs[0], mix.inputs[7])
    #group_input.Mt Height -> math_002.Value
    nodegroup.links.new(group_input.outputs[11], math_002.inputs[1])
    #noise_texture_002.Fac -> mix_001.B
    nodegroup.links.new(noise_texture_002.outputs[0], mix_001.inputs[7])
    #position.Position -> mix_001.A
    nodegroup.links.new(position.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> noise_texture.Vector
    nodegroup.links.new(mix_001.outputs[2], noise_texture.inputs[0])
    #group_input.Rocky Surface -> mix_001.Factor
    nodegroup.links.new(group_input.outputs[12], mix_001.inputs[0])
    #mix.Result -> math.Value
    nodegroup.links.new(mix.outputs[2], math.inputs[0])
    #mix_004.Result -> rgb_curves.Color
    nodegroup.links.new(mix_004.outputs[2], rgb_curves.inputs[1])
    #group_input_001.Terraces -> rgb_curves.Fac
    nodegroup.links.new(group_input_001.outputs[13], rgb_curves.inputs[0])
    #gradient_texture.Color -> color_ramp.Fac
    nodegroup.links.new(gradient_texture.outputs[0], color_ramp.inputs[0])
    #math_003.Value -> mix_005.Factor
    nodegroup.links.new(math_003.outputs[0], mix_005.inputs[0])
    #mix_005.Result -> combine_xyz.Z
    nodegroup.links.new(mix_005.outputs[2], combine_xyz.inputs[2])
    #rgb_curves.Color -> mix_005.A
    nodegroup.links.new(rgb_curves.outputs[0], mix_005.inputs[6])
    #color_ramp.Color -> math_003.Value
    nodegroup.links.new(color_ramp.outputs[0], math_003.inputs[0])
    #group_input_001.Coast -> math_003.Value
    nodegroup.links.new(group_input_001.outputs[14], math_003.inputs[1])
    
    return nodegroup
    #JESUS CHRIST

#CREATE PLANET NODEGROUP
def nodegroup_planet_node_group():
    # Check if the nodegroup already exists
    if "PlanetGroup" in bpy.data.node_groups:
        return bpy.data.node_groups["PlanetGroup"]
    
    # Create a new node group
    nodegroup = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "PlanetGroup")

    nodegroup.color_tag = 'NONE'
    nodegroup.description = ""
    nodegroup.default_group_node_width = 140
    
    #Socket Geometry
    geometry_socket = nodegroup.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Seed
    seed_socket = nodegroup.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
    seed_socket.default_value = 1
    seed_socket.min_value = -2147483648
    seed_socket.max_value = 2147483647
    seed_socket.subtype = 'NONE'
    seed_socket.attribute_domain = 'POINT'

    #Socket Sphere Segments
    segments_socket = nodegroup.interface.new_socket(name = "Segments", in_out='INPUT', socket_type = 'NodeSocketInt')
    segments_socket.default_value = 64
    segments_socket.min_value = 3
    segments_socket.max_value = 500
    segments_socket.subtype = 'NONE'
    segments_socket.attribute_domain = 'POINT'

    #Socket Sphere Rings
    rings_socket = nodegroup.interface.new_socket(name = "Rings", in_out='INPUT', socket_type = 'NodeSocketInt')
    rings_socket.default_value = 32
    rings_socket.min_value = 3
    rings_socket.max_value = 500
    rings_socket.subtype = 'NONE'
    rings_socket.attribute_domain = 'POINT'

    #Socket Sphere Radius
    sphere_radius_socket = nodegroup.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
    sphere_radius_socket.default_value = 5.0
    sphere_radius_socket.min_value = 0.1
    sphere_radius_socket.max_value = 50.0
    sphere_radius_socket.subtype = 'DISTANCE'
    sphere_radius_socket.attribute_domain = 'POINT'

    #Socket Scale
    scale_socket = nodegroup.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
    scale_socket.default_value = 0.6800000071525574
    scale_socket.min_value = -1000.0
    scale_socket.max_value = 1000.0
    scale_socket.subtype = 'NONE'
    scale_socket.attribute_domain = 'POINT'

    #Socket Detail
    detail_socket = nodegroup.interface.new_socket(name = "Detail", in_out='INPUT', socket_type = 'NodeSocketFloat')
    detail_socket.default_value = 15.0
    detail_socket.min_value = 0.0
    detail_socket.max_value = 15.0
    detail_socket.subtype = 'NONE'
    detail_socket.attribute_domain = 'POINT'

    #Socket Terrain Level
    terrain_level_socket = nodegroup.interface.new_socket(name = "Terrain Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
    terrain_level_socket.default_value = 0.4000000059604645
    terrain_level_socket.min_value = -3.4028234663852886e+38
    terrain_level_socket.max_value = 3.4028234663852886e+38
    terrain_level_socket.subtype = 'NONE'
    terrain_level_socket.attribute_domain = 'POINT'
    terrain_level_socket.description = "Default 0.400"

    #Socket Ground Level
    ground_level_socket = nodegroup.interface.new_socket(name = "Ground Level", in_out='INPUT', socket_type = 'NodeSocketFloat')
    ground_level_socket.default_value = 0.0
    ground_level_socket.min_value = -3.4028234663852886e+38
    ground_level_socket.max_value = 3.4028234663852886e+38
    ground_level_socket.subtype = 'NONE'
    ground_level_socket.attribute_domain = 'POINT'

    #Socket Crater-Peaks
    crater_peaks_socket = nodegroup.interface.new_socket(name = "Crater-Peaks", in_out='INPUT', socket_type = 'NodeSocketFloat')
    crater_peaks_socket.default_value = 1.0
    crater_peaks_socket.min_value = -10.0
    crater_peaks_socket.max_value = 10.0
    crater_peaks_socket.subtype = 'NONE'
    crater_peaks_socket.attribute_domain = 'POINT'

    #Socket Mt Height
    mt_height_socket = nodegroup.interface.new_socket(name = "Mt Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
    mt_height_socket.default_value = 0.0
    mt_height_socket.min_value = 0.0
    mt_height_socket.max_value = 10.0
    mt_height_socket.subtype = 'NONE'
    mt_height_socket.attribute_domain = 'POINT'

    #Socket Rocky Surface
    rocky_surface_socket = nodegroup.interface.new_socket(name = "Rocky Surface", in_out='INPUT', socket_type = 'NodeSocketFloat')
    rocky_surface_socket.default_value = 0.0
    rocky_surface_socket.min_value = 0.0
    rocky_surface_socket.max_value = 0.10000000149011612
    rocky_surface_socket.subtype = 'FACTOR'
    rocky_surface_socket.attribute_domain = 'POINT'

    #Socket Terraces
    terraces_socket = nodegroup.interface.new_socket(name = "Terraces", in_out='INPUT', socket_type = 'NodeSocketFloat')
    terraces_socket.default_value = 1.0
    terraces_socket.min_value = 0.0
    terraces_socket.max_value = 1.0
    terraces_socket.subtype = 'FACTOR'
    terraces_socket.attribute_domain = 'POINT'

    #Socket Coast
    coast_socket = nodegroup.interface.new_socket(name = "Coast", in_out='INPUT', socket_type = 'NodeSocketFloat')
    coast_socket.default_value = 1.0
    coast_socket.min_value = 0.0
    coast_socket.max_value = 1.0
    coast_socket.subtype = 'NONE'
    coast_socket.attribute_domain = 'POINT'

    #node Group Output
    group_output = nodegroup.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Group Input
    group_input = nodegroup.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node UV Sphere (instead of Grid)
    uv_sphere = nodegroup.nodes.new("GeometryNodeMeshUVSphere")
    uv_sphere.name = "UV Sphere"

    #node Set Position
    set_position = nodegroup.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    #Selection
    set_position.inputs[1].default_value = True
    #Position
    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)

    #node Noise Texture
    noise_texture = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '4D'
    noise_texture.noise_type = 'FBM'
    noise_texture.normalize = True
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture.inputs[5].default_value = 2.0
    #Distortion
    noise_texture.inputs[8].default_value = 0.0

    #node Normal (for sphere displacement direction)
    normal = nodegroup.nodes.new("GeometryNodeInputNormal")
    normal.name = "Normal"

    #node Vector Math (to scale displacement)
    vector_math = nodegroup.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SCALE'

    #node Set Shade Smooth
    set_shade_smooth = nodegroup.nodes.new("GeometryNodeSetShadeSmooth")
    set_shade_smooth.name = "Set Shade Smooth"
    set_shade_smooth.domain = 'FACE'
    #Selection
    set_shade_smooth.inputs[1].default_value = True
    #Shade Smooth
    set_shade_smooth.inputs[2].default_value = True

    #node Mix
    mix = nodegroup.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'SCREEN'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.06666666269302368

    #node Noise Texture.001
    noise_texture_001 = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    noise_texture_001.noise_type = 'FBM'
    noise_texture_001.normalize = True
    #Vector
    noise_texture_001.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Scale
    noise_texture_001.inputs[2].default_value = 3.5
    #Detail
    noise_texture_001.inputs[3].default_value = 15.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture_001.inputs[5].default_value = 2.0
    #Distortion
    noise_texture_001.inputs[8].default_value = 0.0

    #node Set Material
    set_material = nodegroup.nodes.new("GeometryNodeSetMaterial")
    set_material.name = "Set Material"
    #Selection
    set_material.inputs[1].default_value = True

    #node Math
    math = nodegroup.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 0.0

    #node Color Ramp.002
    color_ramp_002 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_002.name = "Color Ramp.002"
    color_ramp_002.color_ramp.color_mode = 'RGB'
    color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_002.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
    color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
    color_ramp_002_cre_0.position = 0.0
    color_ramp_002_cre_0.alpha = 1.0
    color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(0.45909082889556885)
    color_ramp_002_cre_1.alpha = 1.0
    color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    #node Mix.002
    mix_002 = nodegroup.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'

    #node Color Ramp.003
    color_ramp_003 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_003.name = "Color Ramp.003"
    color_ramp_003.color_ramp.color_mode = 'RGB'
    color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_003.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
    color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
    color_ramp_003_cre_0.position = 0.45909082889556885
    color_ramp_003_cre_0.alpha = 1.0
    color_ramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.6363638639450073)
    color_ramp_003_cre_1.alpha = 1.0
    color_ramp_003_cre_1.color = (0.9051787853240967, 0.9051787853240967, 0.9051787853240967, 1.0)

    #node Mix.003
    mix_003 = nodegroup.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'RGBA'
    mix_003.factor_mode = 'UNIFORM'
    mix_003.inputs[7].default_value = (0.9529872536659241, 0.9529872536659241, 0.9529872536659241, 1.0)

    #node Color Ramp.004
    color_ramp_004 = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp_004.name = "Color Ramp.004"
    color_ramp_004.color_ramp.color_mode = 'RGB'
    color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_004.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
    color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
    color_ramp_004_cre_0.position = 0.6363638639450073
    color_ramp_004_cre_0.alpha = 1.0
    color_ramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(1.0)
    color_ramp_004_cre_1.alpha = 1.0
    color_ramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    #node Mix.004
    mix_004 = nodegroup.nodes.new("ShaderNodeMix")
    mix_004.name = "Mix.004"
    mix_004.blend_type = 'MIX'
    mix_004.clamp_factor = True
    mix_004.clamp_result = False
    mix_004.data_type = 'RGBA'
    mix_004.factor_mode = 'UNIFORM'

    #node Group Input.001
    group_input_001 = nodegroup.nodes.new("NodeGroupInput")
    group_input_001.name = "Group Input.001"

    #node Math.001
    math_001 = nodegroup.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    #Value
    math_001.inputs[0].default_value = 0.0

    #node Math.002
    math_002 = nodegroup.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'ADD'
    math_002.use_clamp = False

    #node Noise Texture.002
    noise_texture_002 = nodegroup.nodes.new("ShaderNodeTexNoise")
    noise_texture_002.name = "Noise Texture.002"
    noise_texture_002.noise_dimensions = '3D'
    noise_texture_002.noise_type = 'MULTIFRACTAL'
    noise_texture_002.normalize = True
    #Vector
    noise_texture_002.inputs[0].default_value = (0.0, 0.0, 0.0)
    #Scale
    noise_texture_002.inputs[2].default_value = 3.3899998664855957
    #Detail
    noise_texture_002.inputs[3].default_value = 15.0
    #Roughness
    noise_texture_002.inputs[4].default_value = 0.5
    #Lacunarity
    noise_texture_002.inputs[5].default_value = 2.0
    #Distortion
    noise_texture_002.inputs[8].default_value = 0.0

    #node Mix.001
    mix_001 = nodegroup.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'SCREEN'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'

    #node Position
    position = nodegroup.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"

    #node RGB Curves
    rgb_curves = nodegroup.nodes.new("ShaderNodeRGBCurve")
    rgb_curves.name = "RGB Curves"
    #mapping settings
    rgb_curves.mapping.extend = 'EXTRAPOLATED'
    rgb_curves.mapping.tone = 'STANDARD'
    rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
    rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
    rgb_curves.mapping.clip_min_x = 0.0
    rgb_curves.mapping.clip_min_y = 0.0
    rgb_curves.mapping.clip_max_x = 1.0
    rgb_curves.mapping.clip_max_y = 1.0
    rgb_curves.mapping.use_clip = True
    #curve 0
    rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
    rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
    rgb_curves_curve_0_point_0.location = (0.0, 0.0)
    rgb_curves_curve_0_point_0.handle_type = 'AUTO'
    rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
    rgb_curves_curve_0_point_1.location = (1.0, 1.0)
    rgb_curves_curve_0_point_1.handle_type = 'AUTO'
    #curve 1
    rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
    rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
    rgb_curves_curve_1_point_0.location = (0.0, 0.0)
    rgb_curves_curve_1_point_0.handle_type = 'AUTO'
    rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
    rgb_curves_curve_1_point_1.location = (1.0, 1.0)
    rgb_curves_curve_1_point_1.handle_type = 'AUTO'
    #curve 2
    rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
    rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
    rgb_curves_curve_2_point_0.location = (0.0, 0.0)
    rgb_curves_curve_2_point_0.handle_type = 'AUTO'
    rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
    rgb_curves_curve_2_point_1.location = (1.0, 1.0)
    rgb_curves_curve_2_point_1.handle_type = 'AUTO'
    #curve 3
    rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
    rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
    rgb_curves_curve_3_point_0.location = (0.0, 0.0)
    rgb_curves_curve_3_point_0.handle_type = 'AUTO'
    rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
    rgb_curves_curve_3_point_1.location = (0.5363636612892151, 0.42499998211860657)
    rgb_curves_curve_3_point_1.handle_type = 'AUTO'
    rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(0.613636314868927, 0.49374985694885254)
    rgb_curves_curve_3_point_2.handle_type = 'AUTO'
    rgb_curves_curve_3_point_3 = rgb_curves_curve_3.points.new(0.668181836605072, 0.637499988079071)
    rgb_curves_curve_3_point_3.handle_type = 'AUTO'
    rgb_curves_curve_3_point_4 = rgb_curves_curve_3.points.new(0.7636362910270691, 0.6374997496604919)
    rgb_curves_curve_3_point_4.handle_type = 'AUTO'
    rgb_curves_curve_3_point_5 = rgb_curves_curve_3.points.new(0.8227272629737854, 0.7500001788139343)
    rgb_curves_curve_3_point_5.handle_type = 'AUTO'
    rgb_curves_curve_3_point_6 = rgb_curves_curve_3.points.new(0.8909090757369995, 0.7812500596046448)
    rgb_curves_curve_3_point_6.handle_type = 'AUTO'
    rgb_curves_curve_3_point_7 = rgb_curves_curve_3.points.new(1.0, 1.0)
    rgb_curves_curve_3_point_7.handle_type = 'AUTO'
    #update curve after changes
    rgb_curves.mapping.update()

    #node Gradient Texture
    gradient_texture = nodegroup.nodes.new("ShaderNodeTexGradient")
    gradient_texture.name = "Gradient Texture"
    gradient_texture.gradient_type = 'EASING'
    #Vector
    gradient_texture.inputs[0].default_value = (0.0, 0.0, 0.0)

    #node Mix.005
    mix_005 = nodegroup.nodes.new("ShaderNodeMix")
    mix_005.name = "Mix.005"
    mix_005.blend_type = 'MULTIPLY'
    mix_005.clamp_factor = True
    mix_005.clamp_result = False
    mix_005.data_type = 'RGBA'
    mix_005.factor_mode = 'UNIFORM'
    #B_Color
    mix_005.inputs[7].default_value = (0.0, 0.0, 0.0, 1.0)

    #node Color Ramp
    color_ramp = nodegroup.nodes.new("ShaderNodeValToRGB")
    color_ramp.name = "Color Ramp"
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.0
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (0.6441415548324585, 0.6441415548324585, 0.6441415548324585, 1.0)

    #node Math.003
    math_003 = nodegroup.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'SUBTRACT'
    math_003.use_clamp = False

    #Set locations (adjust for sphere-specific layout)
    group_output.location = (2106.5263671875, 679.0626220703125)
    group_input.location = (-1483.561767578125, 846.4334106445312)
    uv_sphere.location = (-558.6212158203125, 880.4542236328125)
    set_position.location = (1489.33544921875, 630.9581909179688)
    noise_texture.location = (-850.8815307617188, 541.4349975585938)
    normal.location = (1200.0, 400.0)
    vector_math.location = (1300.0, 450.0)
    set_shade_smooth.location = (1716.7391357421875, 674.7537841796875)
    mix.location = (-527.2388305664062, 528.0447387695312)
    noise_texture_001.location = (-1175.586669921875, -45.813323974609375)
    set_material.location = (1901.5416259765625, 645.5176391601562)
    math.location = (-253.07687377929688, 727.7000732421875)
    color_ramp_002.location = (85.35531616210938, 380.3711853027344)
    mix_002.location = (398.1470642089844, 650.145263671875)
    color_ramp_003.location = (84.8779296875, 641.70703125)
    mix_003.location = (414.3746337890625, 924.3941650390625)
    color_ramp_004.location = (80.38967895507812, 889.6439819335938)
    mix_004.location = (388.44976806640625, 384.89068603515625)
    group_input_001.location = (253.38406372070312, -473.54949951171875)
    math_001.location = (-910.203125, 138.1107940673828)
    math_002.location = (-716.3067626953125, 169.30357360839844)
    noise_texture_002.location = (-1381.625732421875, 208.96961975097656)
    mix_001.location = (-1104.19775390625, 439.6932373046875)
    position.location = (-1414.175048828125, 478.4564514160156)
    rgb_curves.location = (506.13531494140625, 18.746463775634766)
    gradient_texture.location = (517.1767578125, -472.67889404296875)
    mix_005.location = (1031.0, 329.2410888671875)
    color_ramp.location = (770.954345703125, -183.71435546875)
    math_003.location = (851.0, 57.764930725097656)

    #Set dimensions (same as original)
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    uv_sphere.width, uv_sphere.height = 140.0, 100.0
    set_position.width, set_position.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    normal.width, normal.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    set_material.width, set_material.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    color_ramp_003.width, color_ramp_003.height = 240.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    color_ramp_004.width, color_ramp_004.height = 240.0, 100.0
    mix_004.width, mix_004.height = 140.0, 100.0
    group_input_001.width, group_input_001.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0
    rgb_curves.width, rgb_curves.height = 240.0, 100.0
    gradient_texture.width, gradient_texture.height = 140.0, 100.0
    mix_005.width, mix_005.height = 140.0, 100.0
    color_ramp.width, color_ramp.height = 240.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0

    #initialize nodegroup links
    #set_position.Geometry -> set_shade_smooth.Geometry
    nodegroup.links.new(set_position.outputs[0], set_shade_smooth.inputs[0])
    #vector_math displacement -> set_position.Offset
    nodegroup.links.new(vector_math.outputs[0], set_position.inputs[3])
    #noise_texture.Fac -> mix.A
    nodegroup.links.new(noise_texture.outputs[0], mix.inputs[6])
    #uv_sphere.Mesh -> set_position.Geometry
    nodegroup.links.new(uv_sphere.outputs[0], set_position.inputs[0])
    #set_material.Geometry -> group_output.Geometry
    nodegroup.links.new(set_material.outputs[0], group_output.inputs[0])
    #group_input.Seed -> noise_texture.W
    nodegroup.links.new(group_input.outputs[0], noise_texture.inputs[1])
    #group_input.Subdivisions -> uv_sphere.Segments
    nodegroup.links.new(group_input.outputs[1], uv_sphere.inputs[0])
    #group_input.Rings -> uv_sphere.Rings  
    nodegroup.links.new(group_input.outputs[2], uv_sphere.inputs[1])
    #group_input.Radius -> uv_sphere.Radius (update index)
    nodegroup.links.new(group_input.outputs[3], uv_sphere.inputs[2])
    #set_shade_smooth.Geometry -> set_material.Geometry
    nodegroup.links.new(set_shade_smooth.outputs[0], set_material.inputs[0])
    #group_input.Scale -> noise_texture.Scale
    nodegroup.links.new(group_input.outputs[4], noise_texture.inputs[2])
    #group_input.Detail -> noise_texture.Detail
    nodegroup.links.new(group_input.outputs[5], noise_texture.inputs[3])
    #math.Value -> color_ramp_002.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_002.inputs[0])
    #color_ramp_002.Color -> mix_002.Factor
    nodegroup.links.new(color_ramp_002.outputs[0], mix_002.inputs[0])
    #math.Value -> color_ramp_003.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_003.inputs[0])
    #color_ramp_003.Color -> mix_003.Factor
    nodegroup.links.new(color_ramp_003.outputs[0], mix_003.inputs[0])
    #mix_002.Result -> mix_003.A
    nodegroup.links.new(mix_002.outputs[2], mix_003.inputs[6])
    #math.Value -> color_ramp_004.Fac
    nodegroup.links.new(math.outputs[0], color_ramp_004.inputs[0])
    #mix_003.Result -> mix_004.A
    nodegroup.links.new(mix_003.outputs[2], mix_004.inputs[6])
    #color_ramp_004.Color -> mix_004.Factor
    nodegroup.links.new(color_ramp_004.outputs[0], mix_004.inputs[0])
    #group_input_001.Ground Level -> mix_002.A
    nodegroup.links.new(group_input_001.outputs[7], mix_002.inputs[6])
    #group_input_001.Terrain Level -> mix_002.B
    nodegroup.links.new(group_input_001.outputs[6], mix_002.inputs[7])
    #group_input_001.Crater-Peaks -> mix_004.B
    nodegroup.links.new(group_input_001.outputs[8], mix_004.inputs[7])
    #math_001.Value -> math_002.Value
    nodegroup.links.new(math_001.outputs[0], math_002.inputs[0])
    #noise_texture_001.Fac -> math_001.Value
    nodegroup.links.new(noise_texture_001.outputs[0], math_001.inputs[1])
    #math_002.Value -> mix.B
    nodegroup.links.new(math_002.outputs[0], mix.inputs[7])
    #group_input.Mt Height -> math_002.Value
    nodegroup.links.new(group_input.outputs[9], math_002.inputs[1])
    #noise_texture_002.Fac -> mix_001.B
    nodegroup.links.new(noise_texture_002.outputs[0], mix_001.inputs[7])
    #position.Position -> mix_001.A
    nodegroup.links.new(position.outputs[0], mix_001.inputs[6])
    #mix_001.Result -> noise_texture.Vector
    nodegroup.links.new(mix_001.outputs[2], noise_texture.inputs[0])
    #group_input.Rocky Surface -> mix_001.Factor
    nodegroup.links.new(group_input.outputs[10], mix_001.inputs[0])
    #mix.Result -> math.Value
    nodegroup.links.new(mix.outputs[2], math.inputs[0])
    #mix_004.Result -> rgb_curves.Color
    nodegroup.links.new(mix_004.outputs[2], rgb_curves.inputs[1])
    #group_input_001.Terraces -> rgb_curves.Fac
    nodegroup.links.new(group_input_001.outputs[11], rgb_curves.inputs[0])
    #gradient_texture.Color -> color_ramp.Fac
    nodegroup.links.new(gradient_texture.outputs[0], color_ramp.inputs[0])
    #math_003.Value -> mix_005.Factor
    nodegroup.links.new(math_003.outputs[0], mix_005.inputs[0])
    #mix_005.Result -> vector_math.Scale (sphere displacement)
    nodegroup.links.new(mix_005.outputs[2], vector_math.inputs[3])
    #normal.Normal -> vector_math.Vector (displacement direction)
    nodegroup.links.new(normal.outputs[0], vector_math.inputs[0])
    #rgb_curves.Color -> mix_005.A
    nodegroup.links.new(rgb_curves.outputs[0], mix_005.inputs[6])
    #color_ramp.Color -> math_003.Value
    nodegroup.links.new(color_ramp.outputs[0], math_003.inputs[0])
    #group_input_001.Coast -> math_003.Value
    nodegroup.links.new(group_input_001.outputs[12], math_003.inputs[1])
    
    return nodegroup
    #JESUS CHRIST 2

#CREATE GEOMETRY NODES TERRAIN NODE GROUP
def geometry_nodes_terrain_node_group():
    # Check if the node group already exists
    if "Geometry Nodes Terrain" in bpy.data.node_groups:
        return bpy.data.node_groups["Geometry Nodes Terrain"]
    
    print("Creating Geometry Nodes Terrain")
    # Create a new node group
    geometry_nodes_terrain = bpy.data.node_groups.new(type='GeometryNodeTree', name="Geometry Nodes Terrain")
    geometry_nodes_terrain.is_modifier = True
    
    # Create interface sockets
    geometry_socket_1 = geometry_nodes_terrain.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket_2 = geometry_nodes_terrain.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    
    # Create basic nodes
    group_output_1 = geometry_nodes_terrain.nodes.new("NodeGroupOutput")
    
    nodegroup = nodegroup_node_group()
    
    # Create the Group node that will use the nodegroup_node_group
    group = geometry_nodes_terrain.nodes.new("GeometryNodeGroup")
    group.name = "Group"
    group.node_tree = nodegroup
    
    # Link nodes
    geometry_nodes_terrain.links.new(group.outputs[0], group_output_1.inputs[0])
    
    # Create a distribute points node for trees
    distribute_points = geometry_nodes_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points.name = "Distribute Points on Faces"
    distribute_points.distribute_method = 'POISSON'
    distribute_points.inputs["Density Max"].default_value = 50.0
    
    # Create instance on points node for trees
    instance_points = geometry_nodes_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points.name = "Instance on Points"
    
    # Create collection info node for trees
    collection_info = geometry_nodes_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info.name = "Collection Info"
    # Set separate children and reset children inputs (no more displacement?) - WORKS NOW! 
    collection_info.inputs["Separate Children"].default_value = True
    collection_info.inputs["Reset Children"].default_value = True
    
    # Create switch node for trees
    switch_node = geometry_nodes_terrain.nodes.new('GeometryNodeSwitch')
    switch_node.name = "Switch"
    switch_node.input_type = 'GEOMETRY'

    # Setup for flowers
    distribute_points_flowers = geometry_nodes_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points_flowers.name = "Distribute Points_Flowers"
    distribute_points_flowers.distribute_method = 'POISSON'
    distribute_points_flowers.inputs["Density Max"].default_value = 20.0

    instance_points_flowers = geometry_nodes_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points_flowers.name = "Instance on Points_Flowers"

    collection_info_flowers = geometry_nodes_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info_flowers.name = "Collection Info_Flowers"
    collection_info_flowers.inputs["Separate Children"].default_value = True
    collection_info_flowers.inputs["Reset Children"].default_value = True

    switch_flowers = geometry_nodes_terrain.nodes.new('GeometryNodeSwitch')
    switch_flowers.name = "Switch_Flowers"
    switch_flowers.input_type = 'GEOMETRY'

    # Setup for grass
    distribute_points_grass = geometry_nodes_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points_grass.name = "Distribute Points_Grass"
    distribute_points_grass.distribute_method = 'POISSON'
    distribute_points_grass.inputs["Density Max"].default_value = 100.0

    instance_points_grass = geometry_nodes_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points_grass.name = "Instance on Points_Grass"

    collection_info_grass = geometry_nodes_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info_grass.name = "Collection Info_Grass"
    collection_info_grass.inputs["Separate Children"].default_value = True
    collection_info_grass.inputs["Reset Children"].default_value = True

    switch_grass = geometry_nodes_terrain.nodes.new('GeometryNodeSwitch')
    switch_grass.name = "Switch_Grass"
    switch_grass.input_type = 'GEOMETRY'

    # Setup for sea grass
    distribute_points_seagrass = geometry_nodes_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points_seagrass.name = "Distribute Points_SeaGrass"
    distribute_points_seagrass.distribute_method = 'POISSON'
    distribute_points_seagrass.inputs["Density Max"].default_value = 50.0

    instance_points_seagrass = geometry_nodes_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points_seagrass.name = "Instance on Points_SeaGrass"

    collection_info_seagrass = geometry_nodes_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info_seagrass.name = "Collection Info_SeaGrass"
    collection_info_seagrass.inputs["Separate Children"].default_value = True
    collection_info_seagrass.inputs["Reset Children"].default_value = True

    switch_seagrass = geometry_nodes_terrain.nodes.new('GeometryNodeSwitch')
    switch_seagrass.name = "Switch_SeaGrass"
    switch_seagrass.input_type = 'GEOMETRY'

    # Add position node for height detection
    position_node = geometry_nodes_terrain.nodes.new('GeometryNodeInputPosition')
    position_node.name = "Position"

    # Add separate XYZ node to get Z coordinate
    separate_xyz = geometry_nodes_terrain.nodes.new('ShaderNodeSeparateXYZ')
    separate_xyz.name = "Separate XYZ"

    # Add compare nodes for height-based selection
    compare_above_water = geometry_nodes_terrain.nodes.new('FunctionNodeCompare')
    compare_above_water.name = "Compare Above Water"
    compare_above_water.data_type = 'FLOAT'
    compare_above_water.operation = 'GREATER_THAN'

    compare_below_water = geometry_nodes_terrain.nodes.new('FunctionNodeCompare')
    compare_below_water.name = "Compare Below Water"
    compare_below_water.data_type = 'FLOAT'
    compare_below_water.operation = 'LESS_THAN'

    # Add water level value node for comparison
    water_level_compare = geometry_nodes_terrain.nodes.new('ShaderNodeValue')
    water_level_compare.name = "Water Level Compare"
    water_level_compare.outputs[0].default_value = 0.4

    ## Add nodes to avoid same point dist
    sample_nearest_trees = geometry_nodes_terrain.nodes.new('GeometryNodeSampleNearest')
    sample_nearest_trees.name = "Sample Nearest Trees"
    sample_nearest_trees.location = (-400, 150)

    vector_math_distance = geometry_nodes_terrain.nodes.new('ShaderNodeVectorMath')
    vector_math_distance.name = "Vector Math Distance"
    vector_math_distance.operation = 'DISTANCE'
    vector_math_distance.location = (-200, 150)

    compare_distance = geometry_nodes_terrain.nodes.new('FunctionNodeCompare')
    compare_distance.name = "Compare Distance"
    compare_distance.data_type = 'FLOAT'
    compare_distance.operation = 'GREATER_THAN'
    compare_distance.inputs[1].default_value = 0.5  # Minimum distance from trees
    compare_distance.location = (0, 150)

    boolean_and_flowers = geometry_nodes_terrain.nodes.new('FunctionNodeBooleanMath')
    boolean_and_flowers.name = "Boolean AND Flowers"
    boolean_and_flowers.operation = 'AND'
    boolean_and_flowers.location = (200, 50)

    boolean_and_grass = geometry_nodes_terrain.nodes.new('FunctionNodeBooleanMath')
    boolean_and_grass.name = "Boolean AND Grass"
    boolean_and_grass.operation = 'AND'
    boolean_and_grass.location = (200, -50)
    
    # Create water nodes
    water_grid = geometry_nodes_terrain.nodes.new('GeometryNodeMeshGrid')
    water_grid.name = "Grid"
    
    water_position = geometry_nodes_terrain.nodes.new('GeometryNodeSetPosition')
    water_position.name = "Set Position"
    
    # Create Value nodes for water level and scale
    water_level_value = geometry_nodes_terrain.nodes.new('ShaderNodeValue')
    water_level_value.name = "Water Level Value"
    water_level_value.outputs[0].default_value = 0.4  # Default water level
    
    water_scale_x_value = geometry_nodes_terrain.nodes.new('ShaderNodeValue')
    water_scale_x_value.name = "Water Scale X Value"
    water_scale_x_value.outputs[0].default_value = 5.0  # Default water X scale
    
    water_scale_y_value = geometry_nodes_terrain.nodes.new('ShaderNodeValue')
    water_scale_y_value.name = "Water Scale Y Value"
    water_scale_y_value.outputs[0].default_value = 5.0  # Default water Y scale
    
    water_combine = geometry_nodes_terrain.nodes.new('ShaderNodeCombineXYZ')
    water_combine.name = "Combine XYZ"
    
    water_material = geometry_nodes_terrain.nodes.new('GeometryNodeSetMaterial')
    water_material.name = "Set Material.001"  
    
    water_switch = geometry_nodes_terrain.nodes.new('GeometryNodeSwitch')
    water_switch.name = "Switch.001"
    water_switch.input_type = 'GEOMETRY'
    
    # Create join geometry node
    join_node = geometry_nodes_terrain.nodes.new('GeometryNodeJoinGeometry')
    join_node.name = "Join Geometry"
    
    # Basic vegetation distribution setup
    geometry_nodes_terrain.links.new(group.outputs[0], distribute_points.inputs[0])  # Trees
    geometry_nodes_terrain.links.new(group.outputs[0], distribute_points_flowers.inputs[0])  # Flowers
    geometry_nodes_terrain.links.new(group.outputs[0], distribute_points_grass.inputs[0])  # Grass
    geometry_nodes_terrain.links.new(group.outputs[0], distribute_points_seagrass.inputs[0])  # SeaGrass
    
    # Instance connections for trees
    geometry_nodes_terrain.links.new(distribute_points.outputs[0], instance_points.inputs[0])
    geometry_nodes_terrain.links.new(collection_info.outputs[0], instance_points.inputs[2])
    geometry_nodes_terrain.links.new(instance_points.outputs[0], switch_node.inputs[2])  # True input
    geometry_nodes_terrain.links.new(switch_node.outputs[0], join_node.inputs[0])

    # Instance connections for flowers
    geometry_nodes_terrain.links.new(distribute_points_flowers.outputs[0], instance_points_flowers.inputs[0])
    geometry_nodes_terrain.links.new(collection_info_flowers.outputs[0], instance_points_flowers.inputs[2])
    geometry_nodes_terrain.links.new(instance_points_flowers.outputs[0], switch_flowers.inputs[2])  # True input
    geometry_nodes_terrain.links.new(switch_flowers.outputs[0], join_node.inputs[0])

    # Instance connections for grass
    geometry_nodes_terrain.links.new(distribute_points_grass.outputs[0], instance_points_grass.inputs[0])
    geometry_nodes_terrain.links.new(collection_info_grass.outputs[0], instance_points_grass.inputs[2])
    geometry_nodes_terrain.links.new(instance_points_grass.outputs[0], switch_grass.inputs[2])  # True input
    geometry_nodes_terrain.links.new(switch_grass.outputs[0], join_node.inputs[0])

    # Instance connections for seagrass
    geometry_nodes_terrain.links.new(distribute_points_seagrass.outputs[0], instance_points_seagrass.inputs[0])
    geometry_nodes_terrain.links.new(collection_info_seagrass.outputs[0], instance_points_seagrass.inputs[2])
    geometry_nodes_terrain.links.new(instance_points_seagrass.outputs[0], switch_seagrass.inputs[2])  # True input
    geometry_nodes_terrain.links.new(switch_seagrass.outputs[0], join_node.inputs[0])
    
    # Position and height calculation
    geometry_nodes_terrain.links.new(position_node.outputs[0], separate_xyz.inputs[0])
    geometry_nodes_terrain.links.new(separate_xyz.outputs[2], compare_above_water.inputs[0])  # Z to A
    geometry_nodes_terrain.links.new(water_level_compare.outputs[0], compare_above_water.inputs[1])  # Water level to B
    geometry_nodes_terrain.links.new(separate_xyz.outputs[2], compare_below_water.inputs[0])  # Z to A
    geometry_nodes_terrain.links.new(water_level_compare.outputs[0], compare_below_water.inputs[1])  # Water level to B

    # Sample nearest trees for flowers and grass
    geometry_nodes_terrain.links.new(distribute_points.outputs[0], sample_nearest_trees.inputs[0])  # Tree points as geometry
    geometry_nodes_terrain.links.new(position_node.outputs[0], sample_nearest_trees.inputs[1])  # Sample position
    geometry_nodes_terrain.links.new(sample_nearest_trees.outputs[0], vector_math_distance.inputs[0])  # Nearest tree position
    geometry_nodes_terrain.links.new(position_node.outputs[0], vector_math_distance.inputs[1])  # Current position
    geometry_nodes_terrain.links.new(vector_math_distance.outputs[1], compare_distance.inputs[0])  # Distance value

    # Combine height and distance checks for flowers and grass
    geometry_nodes_terrain.links.new(compare_above_water.outputs[0], boolean_and_flowers.inputs[0])  # Height selection
    geometry_nodes_terrain.links.new(compare_distance.outputs[0], boolean_and_flowers.inputs[1])  # Distance check
    geometry_nodes_terrain.links.new(compare_above_water.outputs[0], boolean_and_grass.inputs[0])  # Height selection
    geometry_nodes_terrain.links.new(compare_distance.outputs[0], boolean_and_grass.inputs[1])  # Distance check

    # Trees: only height selection (above water)
    geometry_nodes_terrain.links.new(compare_above_water.outputs[0], distribute_points.inputs[1])  
    
    # Flowers: combined height + distance selection  
    geometry_nodes_terrain.links.new(boolean_and_flowers.outputs[0], distribute_points_flowers.inputs[1])  
    
    # Grass: combined height + distance selection
    geometry_nodes_terrain.links.new(boolean_and_grass.outputs[0], distribute_points_grass.inputs[1])  
    
    # SeaGrass: only height selection (below water)
    geometry_nodes_terrain.links.new(compare_below_water.outputs[0], distribute_points_seagrass.inputs[1])  
        
    # Basic links for the water system
    geometry_nodes_terrain.links.new(water_grid.outputs[0], water_position.inputs[0])
    
    # Connect Value nodes to Combine XYZ inputs
    geometry_nodes_terrain.links.new(water_scale_x_value.outputs[0], water_grid.inputs[0])  # Grid Size X
    geometry_nodes_terrain.links.new(water_scale_y_value.outputs[0], water_grid.inputs[1])  # Grid Size Y
    geometry_nodes_terrain.links.new(water_level_value.outputs[0], water_combine.inputs[2])  # Z level
    
    geometry_nodes_terrain.links.new(water_combine.outputs[0], water_position.inputs[3])
    geometry_nodes_terrain.links.new(water_position.outputs[0], water_material.inputs[0])
    geometry_nodes_terrain.links.new(water_material.outputs[0], water_switch.inputs[2])  # True input
    geometry_nodes_terrain.links.new(water_switch.outputs[0], join_node.inputs[0])
    
    # Position the Value nodes next to their respective targets
    water_level_value.location = (water_combine.location.x - 200, water_combine.location.y)
    water_scale_x_value.location = (water_grid.location.x - 200, water_grid.location.y + 50)
    water_scale_y_value.location = (water_grid.location.x - 200, water_grid.location.y - 50)
    
    # Main output link
    geometry_nodes_terrain.links.new(join_node.outputs[0], group_output_1.inputs[0])
    geometry_nodes_terrain.links.new(group.outputs[0], join_node.inputs[0])

    # Position the height restriction nodes properly
    position_node.location = (-800, -400)
    separate_xyz.location = (-600, -400)
    compare_above_water.location = (-400, -300)
    compare_below_water.location = (-400, -500)
    water_level_compare.location = (-600, -350)
    
    # Tree exclusion nodes positioning
    sample_nearest_trees.location = (-400, -100)
    vector_math_distance.location = (-200, -100)
    compare_distance.location = (0, -100)
    boolean_and_flowers.location = (200, -200)
    boolean_and_grass.location = (200, -300)
    
    # Force a view update to make sure the node tree is fully realized
    bpy.context.view_layer.update()
    
    # Debug information
    print(f"Created group node with node_tree: {group.node_tree}")
    print(f"Number of inputs in group node: {len(group.inputs)}")
    
    return geometry_nodes_terrain

#CREATE GEOMETRY NODES PLANET TERRAIN NODE GROUP
def geometry_nodes_planet_terrain_node_group():
    # Check if the node group already exists
    if "Geometry Nodes Planet Terrain" in bpy.data.node_groups:
        return bpy.data.node_groups["Geometry Nodes Planet Terrain"]
    
    print("Creating Geometry Nodes Planet Terrain")
    # Create a new node group
    geometry_nodes_planet_terrain = bpy.data.node_groups.new(type='GeometryNodeTree', name="Geometry Nodes Planet Terrain")
    geometry_nodes_planet_terrain.is_modifier = True
    
    # Create interface sockets
    geometry_socket_1 = geometry_nodes_planet_terrain.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket_2 = geometry_nodes_planet_terrain.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    
    # Create basic nodes
    group_output_1 = geometry_nodes_planet_terrain.nodes.new("NodeGroupOutput")
    
    nodegroup = nodegroup_planet_node_group()
    
    # Create the Group node that will use the planet nodegroup
    group = geometry_nodes_planet_terrain.nodes.new("GeometryNodeGroup")
    group.name = "Group"
    group.node_tree = nodegroup
    
    # Link nodes
    geometry_nodes_planet_terrain.links.new(group.outputs[0], group_output_1.inputs[0])
    
    position_node = geometry_nodes_planet_terrain.nodes.new('GeometryNodeInputPosition')
    position_node.name = "Position"
    position_node.location = (-600, -200)
    
    # Vector Math node 
    normalize_vector = geometry_nodes_planet_terrain.nodes.new('ShaderNodeVectorMath')
    normalize_vector.name = "Normalize Position"
    normalize_vector.operation = 'NORMALIZE'
    normalize_vector.location = (-400, -200)
    
    # Align Euler to Vector nodes 
    align_trees = geometry_nodes_planet_terrain.nodes.new('FunctionNodeAlignEulerToVector')
    align_trees.name = "Align Trees"
    align_trees.axis = 'Z'  #Make the trees 'stand' - WORKS NOW!
    align_trees.pivot_axis = 'AUTO'
    align_trees.location = (-200, 200)
    
    align_flowers = geometry_nodes_planet_terrain.nodes.new('FunctionNodeAlignEulerToVector')
    align_flowers.name = "Align Flowers"
    align_flowers.axis = 'Z'
    align_flowers.pivot_axis = 'AUTO'
    align_flowers.location = (-200, 0)
    
    align_grass = geometry_nodes_planet_terrain.nodes.new('FunctionNodeAlignEulerToVector')
    align_grass.name = "Align Grass"
    align_grass.axis = 'Z'
    align_grass.pivot_axis = 'AUTO'
    align_grass.location = (-200, -200)
    
    # Setup for vegetation - TREES
    distribute_points = geometry_nodes_planet_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points.name = "Distribute Points on Faces"
    distribute_points.distribute_method = 'POISSON'
    distribute_points.inputs["Density Max"].default_value = 50.0
    distribute_points.location = (-600, 300)
    
    # Instance on Points for trees
    instance_points = geometry_nodes_planet_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points.name = "Instance on Points"
    instance_points.location = (200, 300)
    
    collection_info = geometry_nodes_planet_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info.name = "Collection Info"
    collection_info.inputs["Separate Children"].default_value = True
    collection_info.inputs["Reset Children"].default_value = True
    collection_info.location = (-400, 450)
    
    switch_node = geometry_nodes_planet_terrain.nodes.new('GeometryNodeSwitch')
    switch_node.name = "Switch"
    switch_node.input_type = 'GEOMETRY'
    switch_node.location = (400, 300)

    # Setup for vegetation - FLOWERS
    distribute_points_flowers = geometry_nodes_planet_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points_flowers.name = "Distribute Points_Flowers"
    distribute_points_flowers.distribute_method = 'POISSON'
    distribute_points_flowers.inputs["Density Max"].default_value = 20.0
    distribute_points_flowers.location = (-600, 100)

    instance_points_flowers = geometry_nodes_planet_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points_flowers.name = "Instance on Points_Flowers"
    instance_points_flowers.location = (200, 100)

    collection_info_flowers = geometry_nodes_planet_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info_flowers.name = "Collection Info_Flowers"
    collection_info_flowers.inputs["Separate Children"].default_value = True
    collection_info_flowers.inputs["Reset Children"].default_value = True
    collection_info_flowers.location = (-400, 250)

    switch_flowers = geometry_nodes_planet_terrain.nodes.new('GeometryNodeSwitch')
    switch_flowers.name = "Switch_Flowers"
    switch_flowers.input_type = 'GEOMETRY'
    switch_flowers.location = (400, 100)

    # Setup for vegetation - GRASS
    distribute_points_grass = geometry_nodes_planet_terrain.nodes.new('GeometryNodeDistributePointsOnFaces')
    distribute_points_grass.name = "Distribute Points_Grass"
    distribute_points_grass.distribute_method = 'POISSON'
    distribute_points_grass.inputs["Density Max"].default_value = 100.0
    distribute_points_grass.location = (-600, -100)

    instance_points_grass = geometry_nodes_planet_terrain.nodes.new('GeometryNodeInstanceOnPoints')
    instance_points_grass.name = "Instance on Points_Grass"
    instance_points_grass.location = (200, -100)

    collection_info_grass = geometry_nodes_planet_terrain.nodes.new('GeometryNodeCollectionInfo')
    collection_info_grass.name = "Collection Info_Grass"
    collection_info_grass.inputs["Separate Children"].default_value = True
    collection_info_grass.inputs["Reset Children"].default_value = True
    collection_info_grass.location = (-400, 50)

    switch_grass = geometry_nodes_planet_terrain.nodes.new('GeometryNodeSwitch')
    switch_grass.name = "Switch_Grass"
    switch_grass.input_type = 'GEOMETRY'
    switch_grass.location = (400, -100)
    
    # Create join geometry node
    join_node = geometry_nodes_planet_terrain.nodes.new('GeometryNodeJoinGeometry')
    join_node.name = "Join Geometry"
    join_node.location = (600, 100)
    
    geometry_nodes_planet_terrain.links.new(position_node.outputs[0], normalize_vector.inputs[0])
    
    # Normalized position 
    geometry_nodes_planet_terrain.links.new(normalize_vector.outputs[0], align_trees.inputs[2])
    geometry_nodes_planet_terrain.links.new(normalize_vector.outputs[0], align_flowers.inputs[2])
    geometry_nodes_planet_terrain.links.new(normalize_vector.outputs[0], align_grass.inputs[2])
    
    # Align outputs 
    geometry_nodes_planet_terrain.links.new(align_trees.outputs[0], instance_points.inputs[5])  # Rotation
    geometry_nodes_planet_terrain.links.new(align_flowers.outputs[0], instance_points_flowers.inputs[5])  # Rotation
    geometry_nodes_planet_terrain.links.new(align_grass.outputs[0], instance_points_grass.inputs[5])  # Rotation
    
    # Standard vegetation links
    geometry_nodes_planet_terrain.links.new(group.outputs[0], distribute_points.inputs[0])
    geometry_nodes_planet_terrain.links.new(distribute_points.outputs[0], instance_points.inputs[0])
    geometry_nodes_planet_terrain.links.new(collection_info.outputs[0], instance_points.inputs[2])
    geometry_nodes_planet_terrain.links.new(instance_points.outputs[0], switch_node.inputs[2])
    geometry_nodes_planet_terrain.links.new(switch_node.outputs[0], join_node.inputs[0])

    # Links for the flowers system
    geometry_nodes_planet_terrain.links.new(group.outputs[0], distribute_points_flowers.inputs[0])
    geometry_nodes_planet_terrain.links.new(distribute_points_flowers.outputs[0], instance_points_flowers.inputs[0])
    geometry_nodes_planet_terrain.links.new(collection_info_flowers.outputs[0], instance_points_flowers.inputs[2])
    geometry_nodes_planet_terrain.links.new(instance_points_flowers.outputs[0], switch_flowers.inputs[2])
    geometry_nodes_planet_terrain.links.new(switch_flowers.outputs[0], join_node.inputs[0])

    # Links for the grass system
    geometry_nodes_planet_terrain.links.new(group.outputs[0], distribute_points_grass.inputs[0])
    geometry_nodes_planet_terrain.links.new(distribute_points_grass.outputs[0], instance_points_grass.inputs[0])
    geometry_nodes_planet_terrain.links.new(collection_info_grass.outputs[0], instance_points_grass.inputs[2])
    geometry_nodes_planet_terrain.links.new(instance_points_grass.outputs[0], switch_grass.inputs[2])
    geometry_nodes_planet_terrain.links.new(switch_grass.outputs[0], join_node.inputs[0])
    
    # Main output link
    geometry_nodes_planet_terrain.links.new(join_node.outputs[0], group_output_1.inputs[0])
    geometry_nodes_planet_terrain.links.new(group.outputs[0], join_node.inputs[0])
    
    # Force a view update to make sure the node tree is fully realized
    bpy.context.view_layer.update()
    
    print("Planet terrain created with CALCULATED radial vegetation based on sphere position")
    return geometry_nodes_planet_terrain

# CREATE TERRAIN NODE SETUP
def create_terrain_node_setup(context):
    # Create a new plane object
    bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False, align='WORLD', location=(0, 0, 0))
    terrain_obj = context.active_object
    terrain_obj.name = "Terrain"
    
        # Create and assign default materials
    if not context.scene.terrain_material:
        terrain_mat = create_terrain_material()
        context.scene.terrain_material = terrain_mat

    if not context.scene.water_material:
        ocean_mat = create_ocean_material()
        context.scene.water_material = ocean_mat
    
    tree_collection = context.scene.tree_collection
    
    if not tree_collection:
        if "Trees" not in bpy.data.collections:
            tree_collection = bpy.data.collections.new("Trees")
            bpy.context.scene.collection.children.link(tree_collection)
            
            # Create simple cone as a tree placeholder
            bpy.ops.mesh.primitive_cone_add(vertices=8, radius1=0.1, radius2=0, depth=0.3, location=(0, 0, 0.15))
            tree = context.active_object
            tree.name = "Tree"
            
            # Move tree to Trees collection
            for coll in tree.users_collection:
                coll.objects.unlink(tree)
            tree_collection.objects.link(tree)
            
            # Set default tree collection
            context.scene.tree_collection = tree_collection

    # Create or use the flowers collection
    flowers_collection = context.scene.flowers_collection
    if not flowers_collection and context.scene.the_flowers:
        if "Flowers" not in bpy.data.collections:
            flowers_collection = bpy.data.collections.new("Flowers")
            bpy.context.scene.collection.children.link(flowers_collection)
            
            # Create simple cone as a flower placeholder
            bpy.ops.mesh.primitive_cone_add(vertices=8, radius1=0.05, radius2=0, depth=0.15, location=(0, 0, 0.075))
            flower = context.active_object
            flower.name = "Flower"
            
            # Move flower to Flowers collection
            for coll in flower.users_collection:
                coll.objects.unlink(flower)
            flowers_collection.objects.link(flower)
            
            # Set default flowers collection
            context.scene.flowers_collection = flowers_collection

    # Create or use the grass collection
    grass_collection = context.scene.grass_collection
    if not grass_collection and context.scene.the_grass:
        if "Grass" not in bpy.data.collections:
            grass_collection = bpy.data.collections.new("Grass")
            bpy.context.scene.collection.children.link(grass_collection)
            
            # Create simple plane as a grass placeholder
            bpy.ops.mesh.primitive_plane_add(size=0.1, location=(0, 0, 0.05))
            grass = context.active_object
            grass.name = "Grass"
            
            # Move grass to Grass collection
            for coll in grass.users_collection:
                coll.objects.unlink(grass)
            grass_collection.objects.link(grass)
            
            # Set default grass collection
            context.scene.grass_collection = grass_collection
    
    # Create or use the seagrass collection
    seagrass_collection = context.scene.seagrass_collection
    if not seagrass_collection and context.scene.the_seagrass:
        if "SeaGrass" not in bpy.data.collections:
            seagrass_collection = bpy.data.collections.new("SeaGrass")
            bpy.context.scene.collection.children.link(seagrass_collection)
            
            # Create simple plane as a seagrass placeholder
            bpy.ops.mesh.primitive_plane_add(size=0.08, location=(0, 0, 0.04))
            seagrass = context.active_object
            seagrass.name = "SeaGrass"
            
            # Move seagrass to SeaGrass collection
            for coll in seagrass.users_collection:
                coll.objects.unlink(seagrass)
            seagrass_collection.objects.link(seagrass)
            
            # Set default seagrass collection
            context.scene.seagrass_collection = seagrass_collection

    nodegroup = nodegroup_node_group()
    node_group = geometry_nodes_terrain_node_group()
    
    # Add a Geometry Nodes modifier
    geometry_nodes = terrain_obj.modifiers.new(name="TerrainGenerator", type='NODES')
    
    # Assign node group to modifier
    geometry_nodes.node_group = node_group
    
    # Find main Group node
    main_group = None
    for node in node_group.nodes:
        if node.type == 'GROUP' and node.name == "Group":
            main_group = node
            break
    
    # Debug: Print the inputs of the main group
    if main_group:
        print_node_inputs(main_group)
        print(f"Found main_group with {len(main_group.inputs)} inputs")
    else:
        print("Main group node not found!")
        return terrain_obj

    if main_group and main_group.node_tree:
        print(f"Main group node_tree name: {main_group.node_tree.name}")
        
        bpy.context.view_layer.update()
        
        if len(main_group.inputs) >= 15:
            main_group.inputs[0].default_value = context.scene.seed           # Seed
            main_group.inputs[1].default_value = context.scene.vertices_x     # Vertices X
            main_group.inputs[2].default_value = context.scene.vertices_y     # Vertices Y  
            main_group.inputs[3].default_value = context.scene.subdivision    # Subdivision
            main_group.inputs[4].default_value = context.scene.size_x         # Size X
            main_group.inputs[5].default_value = context.scene.size_y         # Size Y
            main_group.inputs[6].default_value = context.scene.scale          # Scale
            main_group.inputs[7].default_value = context.scene.detail         # Detail
            main_group.inputs[8].default_value = context.scene.terrain_level  # Terrain Level
            main_group.inputs[9].default_value = context.scene.ground_level   # Ground Level
            main_group.inputs[10].default_value = context.scene.crater_peaks  # Crater-Peaks
            main_group.inputs[11].default_value = context.scene.mt_height     # Mt Height
            main_group.inputs[12].default_value = context.scene.rocky_surface # Rocky Surface
            main_group.inputs[13].default_value = context.scene.terraces      # Terraces
            main_group.inputs[14].default_value = context.scene.coast         # Coast
        else:
            print(f"Not enough inputs in main_group! Found {len(main_group.inputs)}")
    
    # Find and set properties for all vegetation and water nodes
    for node in node_group.nodes:
        # Trees
        if node.name == "Distribute Points on Faces":
            node.inputs["Density Max"].default_value = context.scene.tree_count
        elif node.name == "Collection Info":
            node.inputs[0].default_value = tree_collection
        elif node.name == "Switch" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_trees
        
        # Flowers 
        elif node.name == "Distribute Points_Flowers":
            node.inputs["Density Max"].default_value = context.scene.flowers_count
        elif node.name == "Collection Info_Flowers":
            if context.scene.flowers_collection:  # Check if collection exists
                node.inputs[0].default_value = context.scene.flowers_collection
        elif node.name == "Switch_Flowers" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_flowers
        
        # Grass 
        elif node.name == "Distribute Points_Grass":
            node.inputs["Density Max"].default_value = context.scene.grass_count
        elif node.name == "Collection Info_Grass":
            if context.scene.grass_collection:  
                node.inputs[0].default_value = context.scene.grass_collection
        elif node.name == "Switch_Grass" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_grass

        # Sea Grass
        if node.name == "Distribute Points_SeaGrass":
            node.inputs["Density Max"].default_value = context.scene.seagrass_count
        elif node.name == "Collection Info_SeaGrass":
            node.inputs[0].default_value = context.scene.seagrass_collection
        elif node.name == "Switch_SeaGrass" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_seagrass
        elif node.name == "Water Level Compare":
            node.outputs[0].default_value = context.scene.water_level
        
        # Materials - set terrain and water materials
        elif node.name == "Set Material":  
            node.inputs[2].default_value = context.scene.terrain_material
        elif node.name == "Set Material.001":  
            node.inputs[2].default_value = context.scene.water_material
        
        # Water
        elif node.name == "Water Level Value":
            node.outputs[0].default_value = context.scene.water_level
        elif node.name == "Water Scale X Value":
            node.outputs[0].default_value = context.scene.water_scale_x
        elif node.name == "Water Scale Y Value":
            node.outputs[0].default_value = context.scene.water_scale_y
        elif node.name == "Switch.001" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_water
        elif node.name == "Water Level Compare":
            node.outputs[0].default_value = context.scene.water_level

    # Set initial scale values for vegetation
    for node in node_group.nodes:
        if node.name == "Instance on Points":
            node.inputs["Scale"].default_value = (context.scene.tree_scale, context.scene.tree_scale, context.scene.tree_scale)
        elif node.name == "Instance on Points_Flowers":
            node.inputs["Scale"].default_value = (context.scene.flowers_scale, context.scene.flowers_scale, context.scene.flowers_scale)
        elif node.name == "Instance on Points_Grass":
            node.inputs["Scale"].default_value = (context.scene.grass_scale, context.scene.grass_scale, context.scene.grass_scale)
        elif node.name == "Instance on Points_SeaGrass":
            node.inputs["Scale"].default_value = (context.scene.seagrass_scale, context.scene.seagrass_scale, context.scene.seagrass_scale)
    
    return terrain_obj

# CREATE PLANET NODE SETUP
def create_planet_node_setup(context):
    # Create a new sphere object as base
    bpy.ops.mesh.primitive_uv_sphere_add(radius=1, enter_editmode=False, align='WORLD', location=(0, 0, 0))
    planet_obj = context.active_object
    planet_obj.name = "Planet"
    
    # Create and assign default materials
    if not context.scene.terrain_material:
        terrain_mat = create_terrain_material()
        context.scene.terrain_material = terrain_mat
    
    tree_collection = context.scene.tree_collection
    
    if not tree_collection:
        # Create a default Trees collection if no collection is specified
        if "Trees" not in bpy.data.collections:
            tree_collection = bpy.data.collections.new("Trees")
            bpy.context.scene.collection.children.link(tree_collection)
            
            # Create simple cone as a tree placeholder
            bpy.ops.mesh.primitive_cone_add(vertices=8, radius1=0.1, radius2=0, depth=0.3, location=(0, 0, 0.15))
            tree = context.active_object
            tree.name = "Tree"
            
            # Move tree to Trees collection
            for coll in tree.users_collection:
                coll.objects.unlink(tree)
            tree_collection.objects.link(tree)
            
            # Set default tree collection
            context.scene.tree_collection = tree_collection

    # Create or use the flowers collection
    flowers_collection = context.scene.flowers_collection
    if not flowers_collection and context.scene.the_flowers:
        if "Flowers" not in bpy.data.collections:
            flowers_collection = bpy.data.collections.new("Flowers")
            bpy.context.scene.collection.children.link(flowers_collection)
            
            # Create simple cone as a flower placeholder
            bpy.ops.mesh.primitive_cone_add(vertices=8, radius1=0.05, radius2=0, depth=0.15, location=(0, 0, 0.075))
            flower = context.active_object
            flower.name = "Flower"
            
            # Move flower to Flowers collection
            for coll in flower.users_collection:
                coll.objects.unlink(flower)
            flowers_collection.objects.link(flower)
            
            # Set default flowers collection
            context.scene.flowers_collection = flowers_collection

    # Create or use grass collection
    grass_collection = context.scene.grass_collection
    if not grass_collection and context.scene.the_grass:
        if "Grass" not in bpy.data.collections:
            grass_collection = bpy.data.collections.new("Grass")
            bpy.context.scene.collection.children.link(grass_collection)
            
            # Create simple plane as a grass placeholder
            bpy.ops.mesh.primitive_plane_add(size=0.1, location=(0, 0, 0.05))
            grass = context.active_object
            grass.name = "Grass"
            
            # Move grass to Grass collection
            for coll in grass.users_collection:
                coll.objects.unlink(grass)
            grass_collection.objects.link(grass)
            
            # Default grass collection
            context.scene.grass_collection = grass_collection

    # Make sure node groups are created first
    nodegroup = nodegroup_planet_node_group()
    node_group = geometry_nodes_planet_terrain_node_group()
    
    # Add a Geometry Nodes modifier
    geometry_nodes = planet_obj.modifiers.new(name="PlanetGenerator", type='NODES')
    
    # Assign the node group to the modifier
    geometry_nodes.node_group = node_group
    
    # Find the main Group node
    main_group = None
    for node in node_group.nodes:
        if node.type == 'GROUP' and node.name == "Group":
            main_group = node
            break
    
    # Debug: Print the inputs of the main group
    if main_group:
        print_node_inputs(main_group)
        print(f"Found main_group with {len(main_group.inputs)} inputs")
    else:
        print("Main group node not found!")
        return planet_obj

    # Get the nodegroup reference again to make sure it's correctly initialized - WORKS NOW
    if main_group and main_group.node_tree:
        print(f"Main group node_tree name: {main_group.node_tree.name}")
        
        # Wait for updates to propagate
        bpy.context.view_layer.update()
        
        # Set planet-specific values
        if len(main_group.inputs) >= 13:
            main_group.inputs[0].default_value = context.scene.seed           # Seed
            main_group.inputs[1].default_value = context.scene.sphere_segments  # Segments
            main_group.inputs[2].default_value = context.scene.sphere_rings   # Rings
            main_group.inputs[3].default_value = context.scene.sphere_radius  # Radius
            main_group.inputs[4].default_value = context.scene.scale          # Scale
            main_group.inputs[5].default_value = context.scene.detail         # Detail
            main_group.inputs[6].default_value = context.scene.terrain_level  # Terrain Level
            main_group.inputs[7].default_value = context.scene.ground_level   # Ground Level
            main_group.inputs[8].default_value = context.scene.crater_peaks   # Crater-Peaks
            main_group.inputs[9].default_value = context.scene.mt_height      # Mt Height
            main_group.inputs[10].default_value = context.scene.rocky_surface # Rocky Surface
            main_group.inputs[11].default_value = context.scene.terraces      # Terraces
            main_group.inputs[12].default_value = context.scene.coast         # Coast
        else:
            print(f"Not enough inputs in main_group! Found {len(main_group.inputs)}")
    
    # Find and set properties for all vegetation nodes
    for node in node_group.nodes:
        # Trees
        if node.name == "Distribute Points on Faces":
            node.inputs["Density Max"].default_value = context.scene.tree_count
        elif node.name == "Collection Info":
            node.inputs[0].default_value = tree_collection
        elif node.name == "Switch" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_trees
        
        # Flowers 
        elif node.name == "Distribute Points_Flowers":
            node.inputs["Density Max"].default_value = context.scene.flowers_count
        elif node.name == "Collection Info_Flowers":
            if context.scene.flowers_collection:
                node.inputs[0].default_value = context.scene.flowers_collection
        elif node.name == "Switch_Flowers" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_flowers
        
        # Grass 
        elif node.name == "Distribute Points_Grass":
            node.inputs["Density Max"].default_value = context.scene.grass_count
        elif node.name == "Collection Info_Grass":
            if context.scene.grass_collection:
                node.inputs[0].default_value = context.scene.grass_collection
        elif node.name == "Switch_Grass" and node.input_type == 'GEOMETRY':
            node.inputs[0].default_value = context.scene.the_grass

        # Materials - set terrain material
        elif node.type == 'GROUP' and node.name == "Group" and node.node_tree:
            for inner_node in node.node_tree.nodes:
                if inner_node.name == "Set Material":  # Terrain material
                    inner_node.inputs[2].default_value = context.scene.terrain_material

    # Set initial scale values for vegetation
    for node in node_group.nodes:
        if node.name == "Instance on Points":
            node.inputs["Scale"].default_value = (context.scene.tree_scale, context.scene.tree_scale, context.scene.tree_scale)
        elif node.name == "Instance on Points_Flowers":
            node.inputs["Scale"].default_value = (context.scene.flowers_scale, context.scene.flowers_scale, context.scene.flowers_scale)
        elif node.name == "Instance on Points_Grass":
            node.inputs["Scale"].default_value = (context.scene.grass_scale, context.scene.grass_scale, context.scene.grass_scale)
    
    return planet_obj


def update_water_checkbox(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Switch.001" and node.input_type == 'GEOMETRY':
                        node.inputs[0].default_value = self.the_water
                        print(f"Water visibility updated to {self.the_water}")
    return None

def update_water_level(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Water Level Value":
                        node.outputs[0].default_value = self.water_level
                        print(f"Water level updated to {self.water_level}")
                    elif node.name == "Water Level Compare":
                        node.outputs[0].default_value = self.water_level
                        print(f"Water level comparison updated to {self.water_level}")
    return None

def update_water_scale_x(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Water Scale X Value":
                        node.outputs[0].default_value = self.water_scale_x
                        print(f"Water Scale X updated to {self.water_scale_x}")
    return None

def update_water_scale_y(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Water Scale Y Value":
                        node.outputs[0].default_value = self.water_scale_y
                        print(f"Water Scale Y updated to {self.water_scale_y}")
    return None

def sync_water_levels(context):
    """Sync water level across all water-related nodes"""
    water_level = context.scene.water_level
    
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Water Level Value":
                        node.outputs[0].default_value = water_level
                    elif node.name == "Water Level Compare":
                        node.outputs[0].default_value = water_level

def update_terrain_material(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                # Look for the main Group node first
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group" and node.node_tree:
                        for inner_node in node.node_tree.nodes:
                            if inner_node.name == "Set Material":  
                                inner_node.inputs[2].default_value = self.terrain_material
                                print(f"Terrain material updated to {self.terrain_material.name if self.terrain_material else 'None'}")
                                return None
    return None

def update_water_material(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Set Material.001":  
                        node.inputs[2].default_value = self.water_material
                        print(f"Water material updated to {self.water_material.name if self.water_material else 'None'}")
    return None

def update_size_x(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 4:  # Safety check
                            node.inputs[4].default_value = self.size_x
                            print(f"Size X updated to {self.size_x}")
    return None

def update_size_y(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 5:  
                            node.inputs[5].default_value = self.size_y
                            print(f"Size Y updated to {self.size_y}")
    return None

def update_seed(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 0: 
                            node.inputs[0].default_value = self.seed
                            print(f"Seed updated to {self.seed}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 0:  
                            node.inputs[0].default_value = self.seed
                            print(f"Seed updated to {self.seed} for planet")
    return None

def update_scale(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 6:  
                            node.inputs[6].default_value = self.scale
                            print(f"Scale updated to {self.scale}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 4:  
                            node.inputs[4].default_value = self.scale
                            print(f"Scale updated to {self.scale} for planet")
    return None

def update_detail(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 7:  
                            node.inputs[7].default_value = self.detail
                            print(f"Detail updated to {self.detail}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 5:  
                            node.inputs[5].default_value = self.detail
                            print(f"Detail updated to {self.detail} for planet")
    return None

def update_terrain_level(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 8:  
                            node.inputs[8].default_value = self.terrain_level
                            print(f"Terrain Level updated to {self.terrain_level}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 6:  
                            node.inputs[6].default_value = self.terrain_level
                            print(f"Terrain Level updated to {self.terrain_level} for planet")
    return None

def update_ground_level(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 9:  
                            node.inputs[9].default_value = self.ground_level
                            print(f"Ground Level updated to {self.ground_level}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 7:  
                            node.inputs[7].default_value = self.ground_level
                            print(f"Ground Level updated to {self.ground_level} for planet")
    return None

def update_crater_peaks(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 10: 
                            node.inputs[10].default_value = self.crater_peaks
                            print(f"Crater-Peaks updated to {self.crater_peaks}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 8:  
                            node.inputs[8].default_value = self.crater_peaks
                            print(f"Crater-Peaks updated to {self.crater_peaks} for planet")
    return None

def update_mt_height(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 11:  
                            node.inputs[11].default_value = self.mt_height
                            print(f"Mt Height updated to {self.mt_height}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 9:  
                            node.inputs[9].default_value = self.mt_height
                            print(f"Mt Height updated to {self.mt_height} for planet")
    return None

def update_rocky_surface(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 12:  
                            node.inputs[12].default_value = self.rocky_surface
                            print(f"Rocky Surface updated to {self.rocky_surface}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 10:  
                            node.inputs[10].default_value = self.rocky_surface
                            print(f"Rocky Surface updated to {self.rocky_surface} for planet")
    return None

def update_terraces(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 13:  
                            node.inputs[13].default_value = self.terraces
                            print(f"Terraces updated to {self.terraces}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 11:  
                            node.inputs[11].default_value = self.terraces
                            print(f"Terraces updated to {self.terraces} for planet")
    return None

def update_coast(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 14:  
                            node.inputs[14].default_value = self.coast
                            print(f"Coast updated to {self.coast}")
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 12:  
                            node.inputs[12].default_value = self.coast
                            print(f"Coast updated to {self.coast} for planet")
    return None


def update_trees_checkbox(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Switch" and node.input_type == 'GEOMETRY':
                        node.inputs[0].default_value = self.the_trees
                        print(f"Trees visibility updated to {self.the_trees} for {obj.name}")
    return None

def update_tree_count(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Distribute Points on Faces":
                        node.inputs["Density Max"].default_value = self.tree_count
                        print(f"Tree count updated to {self.tree_count} for {obj.name}")
    return None

def update_tree_collection(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Collection Info":
                        node.inputs[0].default_value = self.tree_collection
                        print(f"Tree collection updated for {obj.name}")
    return None

def update_flowers_checkbox(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Switch_Flowers" and node.input_type == 'GEOMETRY':
                        node.inputs[0].default_value = self.the_flowers
                        print(f"Flowers visibility updated to {self.the_flowers} for {obj.name}")
    return None

def update_flowers_collection(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Collection Info_Flowers":
                        node.inputs[0].default_value = self.flowers_collection
                        print(f"Flowers collection updated for {obj.name}")
    return None

def update_flowers_count(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Distribute Points_Flowers":
                        node.inputs["Density Max"].default_value = self.flowers_count
                        print(f"Flowers count updated to {self.flowers_count} for {obj.name}")
    return None

def update_grass_checkbox(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Switch_Grass" and node.input_type == 'GEOMETRY':
                        node.inputs[0].default_value = self.the_grass
                        print(f"Grass visibility updated to {self.the_grass} for {obj.name}")
    return None

def update_grass_collection(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Collection Info_Grass":
                        node.inputs[0].default_value = self.grass_collection
                        print(f"Grass collection updated for {obj.name}")
    return None

def update_grass_count(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Distribute Points_Grass":
                        node.inputs["Density Max"].default_value = self.grass_count
                        print(f"Grass count updated to {self.grass_count} for {obj.name}")
    return None

def update_tree_scale(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Instance on Points":
                        node.inputs["Scale"].default_value = (self.tree_scale, self.tree_scale, self.tree_scale)
                        print(f"Tree scale updated to {self.tree_scale} for {obj.name}")
    return None

def update_flowers_scale(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Instance on Points_Flowers":
                        node.inputs["Scale"].default_value = (self.flowers_scale, self.flowers_scale, self.flowers_scale)
                        print(f"Flowers scale updated to {self.flowers_scale} for {obj.name}")
    return None

def update_grass_scale(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Instance on Points_Grass":
                        node.inputs["Scale"].default_value = (self.grass_scale, self.grass_scale, self.grass_scale)
                        print(f"Grass scale updated to {self.grass_scale} for {obj.name}")
    return None

def update_seagrass_checkbox(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Switch_SeaGrass" and node.input_type == 'GEOMETRY':
                        node.inputs[0].default_value = self.the_seagrass
                        print(f"SeaGrass visibility updated to {self.the_seagrass}")
    return None

def update_seagrass_collection(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Collection Info_SeaGrass":
                        node.inputs[0].default_value = self.seagrass_collection
                        print(f"SeaGrass collection updated to {self.seagrass_collection.name if self.seagrass_collection else 'None'}")
    return None

def update_seagrass_count(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Distribute Points_SeaGrass":
                        node.inputs["Density Max"].default_value = self.seagrass_count
                        print(f"SeaGrass count updated to {self.seagrass_count}")
    return None

def update_seagrass_scale(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Instance on Points_SeaGrass":
                        node.inputs["Scale"].default_value = (self.seagrass_scale, self.seagrass_scale, self.seagrass_scale)
                        print(f"SeaGrass scale updated to {self.seagrass_scale}")
    return None

def update_vertices_x(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 1:  # Safety check
                            node.inputs[1].default_value = self.vertices_x
                            print(f"Vertices X updated to {self.vertices_x}")
    return None

def update_vertices_y(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 2:  # Another safety check
                            node.inputs[2].default_value = self.vertices_y
                            print(f"Vertices Y updated to {self.vertices_y}")
    return None

def update_subdivision(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("TerrainGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        if len(node.inputs) > 3:  # Yet another safety check
                            node.inputs[3].default_value = self.subdivision
                            print(f"Subdivision updated to {self.subdivision}")
    return None


# Planet-specific update functions
def update_sphere_segments(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        node.inputs[1].default_value = self.sphere_segments
                        print(f"Sphere Segments updated to {self.sphere_segments}")
    return None

def update_sphere_rings(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        node.inputs[2].default_value = self.sphere_rings
                        print(f"Sphere Rings updated to {self.sphere_rings}")
    return None

def update_sphere_radius(self, context):
    for obj in bpy.data.objects:
        if obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier = obj.modifiers.get("PlanetGenerator")
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.type == 'GROUP' and node.name == "Group":
                        node.inputs[3].default_value = self.sphere_radius  
                        print(f"Sphere Radius updated to {self.sphere_radius}")
    return None

def update_planet_mode(self, context):
    # Switch between plane and planet mode
    print(f"Planet mode updated to {self.planet_mode}")
    return None

def update_tree_exclusion_distance(self, context):
    for obj in bpy.data.objects:
        modifier_name = None
        if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
            modifier_name = "TerrainGenerator"
        elif obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
            modifier_name = "PlanetGenerator"
        
        if modifier_name:
            modifier = obj.modifiers.get(modifier_name)
            if modifier and modifier.node_group:
                for node in modifier.node_group.nodes:
                    if node.name == "Compare Distance":
                        node.inputs[1].default_value = self.tree_exclusion_distance
                        print(f"Tree exclusion distance updated to {self.tree_exclusion_distance} for {obj.name}")
    return None


#HELPER FUNCTIONS FOR PRESETS!
def apply_desert_preset(self, context):
    scene = context.scene
    scene.size_x = 10.0
    scene.size_y = 10.0
    scene.seed = 3 
    scene.scale = 0.4
    scene.detail = 0.0
    scene.terrain_level = 0.52
    scene.ground_level = -0.56
    scene.crater_peaks = 1.6
    scene.mt_height = 0.00
    scene.rocky_surface = 0.032
    scene.terraces = 0.3
    scene.coast = 0.8
    scene.the_water = False
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    sync_water_levels(context)
    
    bpy.ops.mesh.update_terrain()
    return None

def apply_mountains_preset(self, context):
    scene = context.scene
    scene.size_x = 8.0
    scene.size_y = 8.0
    scene.seed = 1
    scene.scale = 0.58
    scene.detail = 15.0
    scene.terrain_level = -0.18
    scene.ground_level = -0.85
    scene.crater_peaks = 2.36
    scene.mt_height = 0.00
    scene.rocky_surface = 0.000
    scene.terraces = 0.00
    scene.coast = 1.0
    scene.the_water = False
    scene.the_trees = True
    scene.tree_count = 2
    scene.the_flowers = True
    scene.flowers_count = 20
    scene.the_grass = True
    scene.grass_count = 300
    sync_water_levels(context)

    bpy.ops.mesh.update_terrain()
    return None

def apply_island_preset(self, context):
    scene = context.scene
    scene.size_x = 9.0
    scene.size_y = 12.0
    scene.seed = 1
    scene.scale = 0.17
    scene.detail = 10.0
    scene.terrain_level = 2.12
    scene.ground_level = 4.77
    scene.crater_peaks = 1.7
    scene.mt_height = 0.00
    scene.rocky_surface = 0.025
    scene.terraces = 0.00
    scene.coast = 1.0
    scene.the_water = True
    scene.water_level = 1.34
    scene.water_scale_x = 9.0
    scene.water_scale_y = 12.0
    scene.the_trees = True
    scene.tree_count = 1
    scene.the_flowers = False
    scene.the_grass = False
    sync_water_levels(context)

    bpy.ops.mesh.update_terrain()
    return None

def apply_canyon_preset(self, context):
    scene = context.scene
    scene.size_x = 6.0
    scene.size_y = 6.0
    scene.seed = 1
    scene.scale = 0.68
    scene.detail = 15.0
    scene.terrain_level = 0.33
    scene.ground_level = 0.16
    scene.crater_peaks = 1.0
    scene.mt_height = 0.0
    scene.rocky_surface = 0.000
    scene.terraces = 1.0
    scene.coast = 1.0
    scene.the_water = False
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    sync_water_levels(context)
    
    bpy.ops.mesh.update_terrain()
    return None

def apply_tundra_preset(self, context):
    scene = context.scene
    scene.size_x = 6.0
    scene.size_y = 6.0
    scene.seed = 2
    scene.scale = 0.52
    scene.detail = 15.0
    scene.terrain_level = 0.43
    scene.ground_level = 0.05
    scene.crater_peaks = 2.25
    scene.mt_height = 3.6
    scene.rocky_surface = 0.08
    scene.terraces = 0.3
    scene.coast = 0.0
    scene.the_water = True
    scene.water_level = 0.29
    scene.water_scale_x = 6.0
    scene.water_scale_y = 6.0
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    sync_water_levels(context)
    
    bpy.ops.mesh.update_terrain()
    return None

def apply_shore_preset(self, context):
    scene = context.scene
    scene.size_x = 5.0
    scene.size_y = 5.0
    scene.seed = 1
    scene.scale = 0.77
    scene.detail = 1.0
    scene.terrain_level = 1.13
    scene.ground_level = -1.17
    scene.crater_peaks = 0.58
    scene.mt_height = 9.14
    scene.rocky_surface = 0.05
    scene.terraces = 1.0
    scene.coast = 0.0
    scene.the_water = True
    scene.water_level = 0.4
    scene.water_scale_x = 5.0
    scene.water_scale_y = 5.0
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    sync_water_levels(context)
    
    bpy.ops.mesh.update_terrain()
    return None


# PLANET PRESETS
def apply_earth_preset(self, context):
    scene = context.scene
    scene.sphere_radius = 6.0
    scene.sphere_segments = 32  
    scene.sphere_rings = 16
    scene.seed = 1
    scene.scale = 0.5
    scene.detail = 10.0
    scene.terrain_level = 0.1
    scene.ground_level = -0.2
    scene.crater_peaks = 0.8
    scene.mt_height = 1.0
    scene.rocky_surface = 0.02
    scene.terraces = 0.1
    scene.coast = 0.8
    scene.the_trees = True
    scene.tree_count = 5
    scene.the_flowers = True
    scene.flowers_count = 15
    scene.the_grass = True
    scene.grass_count = 50
    
    bpy.ops.mesh.update_planet()
    return None

def apply_mars_preset(self, context):
    scene = context.scene
    scene.sphere_radius = 5
    scene.sphere_segments = 32  
    scene.sphere_rings = 16
    scene.seed = 1
    scene.scale = 0.91
    scene.detail = 5.0
    scene.terrain_level = 0.0
    scene.ground_level = -0.3
    scene.crater_peaks = 0.0
    scene.mt_height = 0.0
    scene.rocky_surface = 0.08
    scene.terraces = 1.0
    scene.coast = 1.0
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    
    bpy.ops.mesh.update_planet()
    return None

def apply_moon_preset(self, context):
    scene = context.scene
    scene.sphere_radius = 4
    scene.sphere_segments = 32  
    scene.sphere_rings = 16
    scene.seed = 2
    scene.scale = 0.8
    scene.detail = 12.0
    scene.terrain_level = 0.3
    scene.ground_level = -0.1
    scene.crater_peaks = 2.0
    scene.mt_height = 0.5
    scene.rocky_surface = 0.05
    scene.terraces = 0.0
    scene.coast = 1.0
    scene.the_trees = False
    scene.the_flowers = False
    scene.the_grass = False
    
    bpy.ops.mesh.update_planet()
    return None


    # Helper function to calculate total vertex count
def calculate_vertex_count(vertices_x, vertices_y, subdivision):
    """Calculate the final vertex count after subdivision"""
    base_vertices = vertices_x * vertices_y
    # Each subdivision level multiplies vertices by 4
    final_vertices = base_vertices * (4 ** subdivision)
    return final_vertices

# Helper function to get performance level
def get_performance_level(vertex_count):
    """Return performance level and color based on vertex count"""
    if vertex_count <= 10000:
        return "LIGHT", (0.0, 1.0, 0.0)  # Green
    elif vertex_count <= 50000:
        return "MEDIUM", (1.0, 0.65, 0.0)  # Orange
    elif vertex_count <= 200000:
        return "HEAVY", (1.0, 0.0, 0.0)  # Red
    else:
        return "EXTREME", (0.5, 0.0, 0.5)  # Purple
        #BUHU, no colors in Blender :(

# OPERATOR, CREATOR OF TERRAINS
class MESH_OT_add_terrain(bpy.types.Operator):
    """Add a procedural terrain"""
    bl_idname = "mesh.add_terrain"
    bl_label = "Add Terrain"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Create terrain and apply current scene settings
        terrain_obj = create_terrain_node_setup(context)
        return {'FINISHED'}

# OPERATOR UPDATE TERRAIN THAT IS THERE!
class MESH_OT_update_terrain(bpy.types.Operator):
    """Update the existing terrain settings"""
    bl_idname = "mesh.update_terrain"
    bl_label = "Update Terrain"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        updated = False
        for obj in bpy.data.objects:
            if obj.name.startswith("Terrain") and "TerrainGenerator" in obj.modifiers:
                modifier = obj.modifiers.get("TerrainGenerator")
                if modifier and modifier.node_group:
                    for node in modifier.node_group.nodes:
                        if node.type == 'GROUP' and node.name == "Group":
                            # Finish vid ChuckCG
                            node.inputs[0].default_value = context.scene.seed
                            node.inputs[1].default_value = context.scene.vertices_x
                            node.inputs[2].default_value = context.scene.vertices_y
                            node.inputs[3].default_value = context.scene.subdivision
                            node.inputs[4].default_value = context.scene.size_x
                            node.inputs[5].default_value = context.scene.size_y
                            node.inputs[6].default_value = context.scene.scale
                            node.inputs[7].default_value = context.scene.detail
                            node.inputs[8].default_value = context.scene.terrain_level
                            node.inputs[9].default_value = context.scene.ground_level
                            node.inputs[10].default_value = context.scene.crater_peaks
                            node.inputs[11].default_value = context.scene.mt_height
                            node.inputs[12].default_value = context.scene.rocky_surface
                            node.inputs[13].default_value = context.scene.terraces
                            node.inputs[14].default_value = context.scene.coast
                            updated = True
                    
                    # Update tree options
                    for node in modifier.node_group.nodes:
                        if node.name == "Distribute Points on Faces":
                            node.inputs["Density Max"].default_value = context.scene.tree_count
                        elif node.name == "Collection Info":
                            node.inputs[0].default_value = context.scene.tree_collection
                        elif node.name == "Switch" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_trees
                    
                    # Update flowers options
                    for node in modifier.node_group.nodes:
                        if node.name == "Distribute Points_Flowers":
                            node.inputs["Density Max"].default_value = context.scene.flowers_count
                        elif node.name == "Collection Info_Flowers":
                            node.inputs[0].default_value = context.scene.flowers_collection
                        elif node.name == "Switch_Flowers" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_flowers
                    
                    # Update grass options
                    for node in modifier.node_group.nodes:
                        if node.name == "Distribute Points_Grass":
                            node.inputs["Density Max"].default_value = context.scene.grass_count
                        elif node.name == "Collection Info_Grass":
                            node.inputs[0].default_value = context.scene.grass_collection
                        elif node.name == "Switch_Grass" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_grass

                    # Update scale options
                    for node in modifier.node_group.nodes:
                        if node.name == "Instance on Points":
                            node.inputs["Scale"].default_value = (context.scene.tree_scale, context.scene.tree_scale, context.scene.tree_scale)
                        elif node.name == "Instance on Points_Flowers":
                            node.inputs["Scale"].default_value = (context.scene.flowers_scale, context.scene.flowers_scale, context.scene.flowers_scale)
                        elif node.name == "Instance on Points_Grass":
                            node.inputs["Scale"].default_value = (context.scene.grass_scale, context.scene.grass_scale, context.scene.grass_scale)
                    
                    # Update material options
                    for node in modifier.node_group.nodes:
                        if node.type == 'GROUP' and node.name == "Group" and node.node_tree:
                            for inner_node in node.node_tree.nodes:
                                if inner_node.name == "Set Material":  
                                    inner_node.inputs[2].default_value = context.scene.terrain_material
                        elif node.name == "Set Material.001":  
                             node.inputs[2].default_value = context.scene.water_material
                    
                    # Update water options
                    for node in modifier.node_group.nodes:
                        if node.name == "Water Level Value":
                            node.outputs[0].default_value = context.scene.water_level
                        elif node.name == "Water Scale X Value":
                            node.outputs[0].default_value = context.scene.water_scale_x
                        elif node.name == "Water Scale Y Value":
                            node.outputs[0].default_value = context.scene.water_scale_y
                        elif node.name == "Switch.001" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_water
                        elif node.name == "Water Level Compare":
                            node.outputs[0].default_value = context.scene.water_level
                        elif node.name == "Compare Distance": 
                            node.inputs[1].default_value = context.scene.tree_exclusion_distance
                
                # Force a view update
                context.view_layer.update()
                break
        
        return {'FINISHED'}

# PRESET OPERATORS
class MESH_OT_apply_desert_preset(bpy.types.Operator):
    """Apply desert terrain preset"""
    bl_idname = "mesh.apply_desert_preset"
    bl_label = "Desert"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_desert_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_mountains_preset(bpy.types.Operator):
    """Apply mountains terrain preset"""
    bl_idname = "mesh.apply_mountains_preset"
    bl_label = "Mountains"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_mountains_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_island_preset(bpy.types.Operator):
    """Apply island terrain preset"""
    bl_idname = "mesh.apply_island_preset"
    bl_label = "Island"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_island_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_canyon_preset(bpy.types.Operator):
    """Apply canyon terrain preset"""
    bl_idname = "mesh.apply_canyon_preset"
    bl_label = "Canyon"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_canyon_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_tundra_preset(bpy.types.Operator):
    """Apply tundra terrain preset"""
    bl_idname = "mesh.apply_tundra_preset"
    bl_label = "Tundra"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_tundra_preset(self, context)
        return {'FINISHED'}  

class MESH_OT_apply_shore_preset(bpy.types.Operator):
    """Apply shore terrain preset"""
    bl_idname = "mesh.apply_shore_preset"
    bl_label = "Shore"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_shore_preset(self, context)
        return {'FINISHED'}  


# SIMPLIFICATION OPERATOR
class MESH_OT_simplify_terrain(bpy.types.Operator):
    """Simplify terrain vertices for better performance"""
    bl_idname = "mesh.simplify_terrain"
    bl_label = "Simplify Terrain"
    bl_options = {'REGISTER', 'UNDO'}
    
    simplification_level: bpy.props.EnumProperty(
        name="Simplification Level",
        description="How much to simplify the terrain",
        items=[
            ('LIGHT', "Light (75%)", "Reduce vertices to 75% of current"),
            ('MEDIUM', "Medium (50%)", "Reduce vertices to 50% of current"),
            ('HEAVY', "Heavy (25%)", "Reduce vertices to 25% of current"),
        ],
        default='MEDIUM'
    )
    
    def execute(self, context):
        scene = context.scene
        
        if self.simplification_level == 'LIGHT':
            factor = 0.75
        elif self.simplification_level == 'MEDIUM':
            factor = 0.5
        else:  # HEAVY
            factor = 0.25
        
        # Reduce subdivision first if possible
        if scene.subdivision > 0:
            scene.subdivision = max(0, scene.subdivision - 1)
            self.report({'INFO'}, f"Reduced subdivision level to {scene.subdivision}")
        else:
            # If no subdivision to reduce, reduce base vertices
            new_x = max(10, int(scene.vertices_x * factor))
            new_y = max(10, int(scene.vertices_y * factor))
            
            scene.vertices_x = new_x
            scene.vertices_y = new_y
            
            self.report({'INFO'}, f"Reduced vertices to {new_x} x {new_y}")
        
        return {'FINISHED'}

# PERFORMANCE PRESET OPERATORS
class MESH_OT_set_performance_preset(bpy.types.Operator):
    """Set terrain performance preset"""
    bl_idname = "mesh.set_performance_preset"
    bl_label = "Set Performance Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_type: bpy.props.StringProperty()
    
    def execute(self, context):
        scene = context.scene
        
        if self.preset_type == 'LOW_POLY':
            scene.vertices_x = 100
            scene.vertices_y = 100
            scene.subdivision = 1
            self.report({'INFO'}, "Set to Low Poly (2,500 vertices)")
            
        elif self.preset_type == 'MEDIUM_POLY':
            scene.vertices_x = 100
            scene.vertices_y = 100
            scene.subdivision = 2
            self.report({'INFO'}, "Set to Medium Poly (10,000 vertices)")
            
        elif self.preset_type == 'HIGH_POLY':
            scene.vertices_x = 100
            scene.vertices_y = 100
            scene.subdivision = 3
            self.report({'INFO'}, "Set to High Poly (40,000 vertices)")
            
        elif self.preset_type == 'ULTRA_DETAIL':
            scene.vertices_x = 100
            scene.vertices_y = 100
            scene.subdivision = 4
            self.report({'INFO'}, "Set to Ultra Detail (90,000 vertices)")
        
        return {'FINISHED'}


class MATERIAL_OT_set_terrain_material(bpy.types.Operator):
    """Set terrain material"""
    bl_idname = "material.set_terrain_material"
    bl_label = "Set Terrain Material"
    bl_options = {'REGISTER', 'UNDO'}
    
    material_name: bpy.props.StringProperty()
    
    def execute(self, context):
        if self.material_name == "Terrain Material":
            mat = create_terrain_material()
        elif self.material_name == "Snow Material":
            mat = create_snow_material()
        elif self.material_name == "Sandstone":
            mat = create_sandstone_material()
        elif self.material_name == "sand":
            mat = create_sand_desert_material()
        else:
            return {'CANCELLED'}
        
        context.scene.terrain_material = mat
        return {'FINISHED'}

class MATERIAL_OT_set_water_material(bpy.types.Operator):
    """Set water material"""
    bl_idname = "material.set_water_material"
    bl_label = "Set Water Material"
    bl_options = {'REGISTER', 'UNDO'}
    
    material_name: bpy.props.StringProperty()
    
    def execute(self, context):
        if self.material_name == "Ocean.001":
            mat = create_ocean_material()
        elif self.material_name == "Ice2":
            mat = create_ice_material()
        else:
            return {'CANCELLED'}
        
        context.scene.water_material = mat
        return {'FINISHED'}


# GUI PANEL
class MY_PT_CustomPanel(bpy.types.Panel):
    bl_label = "Terra Forge"
    bl_idname = "VIEW3D_PT_my_custom_gui"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Terra Forge'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.operator("mesh.terrain_info", text="About / Help", icon='INFO')
        
        layout.separator()

        # PLANET MODE TOGGLE - NEW SECTION
        planet_box = layout.box()
        row = planet_box.row()
        row.prop(scene, "planet_mode", text="🪐 Planet Mode", toggle=True)
        
        # PLANET MODE SECTION
        if scene.planet_mode:
            planet_box.operator("mesh.add_planet", text="Add Planet", icon='MESH_UVSPHERE')
            planet_box.operator("mesh.update_planet", text="Update/Debug Planet", icon='ERROR')
            
            # Planet Presets
            presets_box = planet_box.box()
            row = presets_box.row()
            row.prop(scene, "show_planet_presets", icon="TRIA_DOWN" if scene.show_planet_presets else "TRIA_RIGHT", icon_only=True, emboss=False)
            row.label(text="Planet Presets")
            
            if scene.show_planet_presets:
                row = presets_box.row()
                row.operator("mesh.apply_earth_preset", text="🌍 Earth")
                
                row = presets_box.row()
                row.operator("mesh.apply_mars_preset", text="🔴 Mars")
                
                row = presets_box.row()
                row.operator("mesh.apply_moon_preset", text="🌙 Moon")
            
            # Planet-specific controls
            planet_controls_box = planet_box.box()
            planet_controls_box.label(text="Planet Configuration")
            
            col = planet_controls_box.column(align=True)
            col.label(text="Planet Size:")
            col.prop(scene, "sphere_radius", text="Radius")
            col.prop(scene, "sphere_segments", text="Segments")
            col.prop(scene, "sphere_rings", text="Rings")
            
            # Calculate planet vertex count
            vertex_count = (scene.sphere_segments * scene.sphere_rings * 2) - (scene.sphere_segments * 2) + 2
            perf_level, perf_color = get_performance_level(vertex_count)
            
            # Performance indicator for planet
            row = planet_controls_box.row()
            row.label(text=f"Planet Vertices: {vertex_count:,}")
            row = planet_controls_box.row()
            row.label(text=f"Performance: {perf_level}")

        # TERRAIN MODE SECTION (only show when planet mode is off)
        if not scene.planet_mode:
            layout.operator("mesh.add_terrain", text="Add Terrain", icon='WORLD_DATA')
            layout.operator("mesh.update_terrain", text="Update/Debug Terrain", icon='ERROR')

        # Create Materials collapsible section (show for both modes)
        materials_box = layout.box()
        row = materials_box.row()
        row.prop(scene, "show_materials", icon="TRIA_DOWN" if scene.show_materials else "TRIA_RIGHT", icon_only=True, emboss=False)
        row.label(text="Materials")

        if scene.show_materials:
            # Terrain Material
            row = materials_box.row()
            row.prop(scene, "terrain_material", text="Terrain")
            
            # Water Material (only show for terrain mode, not planet mode)
            if not scene.planet_mode:
                row = materials_box.row()
                row.prop(scene, "water_material", text="Water/Ice")

            # Quick material selection
            materials_box.label(text="Quick Select:")
            
            # Terrain materials
            row = materials_box.row()
            row.label(text="Terrain:")
            row = materials_box.row()
            terrain_ops = row.row(align=True)
            terrain_ops.operator("material.set_terrain_material", text="Grass").material_name = "Terrain Material"
            terrain_ops.operator("material.set_terrain_material", text="Snow").material_name = "Snow Material"
            terrain_ops.operator("material.set_terrain_material", text="Sandstone").material_name = "Sandstone"
            terrain_ops.operator("material.set_terrain_material", text="Sand").material_name = "sand"
            
            # Water materials (only for terrain mode)
            if not scene.planet_mode:
                row = materials_box.row()
                row.label(text="Water/Ice:")
                row = materials_box.row()
                water_ops = row.row(align=True)
                water_ops.operator("material.set_water_material", text="Water").material_name = "Ocean.001"
                water_ops.operator("material.set_water_material", text="Ice").material_name = "Ice2"

        # PRESETS SECTION (only show for terrain mode)
        if not scene.planet_mode:
            presets_box = layout.box()
            row = presets_box.row()
            row.prop(scene, "show_presets", icon="TRIA_DOWN" if scene.show_presets else "TRIA_RIGHT", icon_only=True, emboss=False)
            row.label(text="Terrain Presets")

            if scene.show_presets:
                row = presets_box.row()
                row.operator("mesh.apply_desert_preset", text="Desert")
                
                row = presets_box.row()
                row.operator("mesh.apply_mountains_preset", text="Mountains")
                
                row = presets_box.row()
                row.operator("mesh.apply_island_preset", text="Island")
                
                row = presets_box.row()
                row.operator("mesh.apply_canyon_preset", text="Canyon")

                row = presets_box.row()
                row.operator("mesh.apply_tundra_preset", text="Tundra")

                row = presets_box.row()
                row.operator("mesh.apply_shore_preset", text="Shore")

        # VEGETATION SECTION 
        flora_box = layout.box()
        row = flora_box.row()
        row.prop(scene, "show_flora", icon="TRIA_DOWN" if scene.show_flora else "TRIA_RIGHT", icon_only=True, emboss=False)
        row.label(text="Vegetation")
        
        if scene.show_flora:
            # Trees
            row = flora_box.row()
            row.prop(scene, "the_trees", text="Add Trees")
            
            if scene.the_trees:
                row = flora_box.row()
                row.prop(scene, "tree_collection", text="Trees Collection")
                row = flora_box.row()
                row.prop(scene, "tree_count", text="Tree Count")
                row = flora_box.row()
                row.prop(scene, "tree_scale", text="Tree Scale")
            
            # Flowers
            row = flora_box.row()
            row.prop(scene, "the_flowers", text="Add Flowers")
            
            if scene.the_flowers:
                row = flora_box.row()
                row.prop(scene, "flowers_collection", text="Flowers Collection")
                row = flora_box.row()
                row.prop(scene, "flowers_count", text="Flowers Count")
                row = flora_box.row()
                row.prop(scene, "flowers_scale", text="Flowers Scale")
            
            # Grass
            row = flora_box.row()
            row.prop(scene, "the_grass", text="Add Grass")
            
            if scene.the_grass:
                row = flora_box.row()
                row.prop(scene, "grass_collection", text="Grass Collection")
                row = flora_box.row()
                row.prop(scene, "grass_count", text="Grass Count")
                row = flora_box.row()
                row.prop(scene, "grass_scale", text="Grass Scale")

            if scene.the_trees and (scene.the_flowers or scene.the_grass):
                flora_box.separator()
                row = flora_box.row()
                row.prop(scene, "tree_exclusion_distance", text="Tree Exclusion Distance")

            # Sea Grass (only show for terrain mode, not planet mode)
            if not scene.planet_mode:
                row = flora_box.row()
                row.prop(scene, "the_seagrass", text="Add Sea Grass")

                if scene.the_seagrass:
                    row = flora_box.row()
                    row.prop(scene, "seagrass_collection", text="Sea Grass Collection")
                    row = flora_box.row()
                    row.prop(scene, "seagrass_count", text="Sea Grass Count")
                    row = flora_box.row()
                    row.prop(scene, "seagrass_scale", text="Sea Grass Scale")
        
        # WATER SECTION (only show for terrain mode, not planet mode)
        if not scene.planet_mode:
            water_box = layout.box()
            water_box.prop(scene, "the_water", text="Add Water / Ice")
            if scene.the_water:
                row = water_box.row()
                row.prop(scene, "water_level", text="Water / Ice Level")
                row = water_box.row(align = True)
                row.prop(scene, "water_scale_x", text="X")
                row.prop(scene, "water_scale_y", text="Y")

        # TERRAIN CUSTOMIZATION SECTION (show for both modes)
        terrain_box = layout.box()
        terrain_box.label(text="Terrain Customization")
        
        # Size controls (different for planet vs terrain)
        if scene.planet_mode:
            col = terrain_box.column(align=True)
            col.label(text="Planet Properties:")
            col.prop(scene, "sphere_radius", text="Radius")
        else:
            col = terrain_box.column(align=True)
            col.label(text="Size:")
            row = col.row(align=True)
            row.prop(scene, "size_x", text="X")
            row.prop(scene, "size_y", text="Y")
        
        # Terrain appearance controls (same for both modes)
        col = terrain_box.column(align=True)
        col.label(text="Terrain Features:")
        col.prop(scene, "seed", text="Seed") 
        col.prop(scene, "scale", text="Scale")
        col.prop(scene, "detail", text="Detail")
        col.prop(scene, "terrain_level", text="Terrain Level")
        col.prop(scene, "ground_level", text="Ground Level")
        col.prop(scene, "crater_peaks", text="Crater-Peaks")
        col.prop(scene, "mt_height", text="Mt Height")
        col.prop(scene, "rocky_surface", text="Rocky Surface")
        col.prop(scene, "terraces", text="Terraces")
        col.prop(scene, "coast", text="Coast")

        # PERFORMANCE SECTION (only show for terrain mode)
        if not scene.planet_mode:
            vertices_box = layout.box()
            vertices_box.label(text="Terrain Performance", icon='MESH_DATA')
            
            # Calculate current vertex count and performance level
            vertex_count = calculate_vertex_count(scene.vertices_x, scene.vertices_y, scene.subdivision)
            perf_level, perf_color = get_performance_level(vertex_count)
            
            # Performance indicator
            row = vertices_box.row()
            row.label(text=f"Total Vertices: {vertex_count:,}")
            
            # Performance level
            row = vertices_box.row()
            row.label(text=f"Performance: {perf_level}")
            
            # Vertex controls
            col = vertices_box.column(align=True)
            col.label(text="Mesh Resolution:")
            
            # Base vertices
            row = col.row(align=True)
            row.prop(scene, "vertices_x", text="X")
            row.prop(scene, "vertices_y", text="Y")
            
            # Performance presets
            vertices_box.label(text="Quick Presets:")
            row = vertices_box.row(align=True)
            
            preset_op = row.operator("mesh.set_performance_preset", text="Low")
            preset_op.preset_type = 'LOW_POLY'
            
            preset_op = row.operator("mesh.set_performance_preset", text="Med")
            preset_op.preset_type = 'MEDIUM_POLY'
            
            preset_op = row.operator("mesh.set_performance_preset", text="High")
            preset_op.preset_type = 'HIGH_POLY'
            
            preset_op = row.operator("mesh.set_performance_preset", text="Ultra")
            preset_op.preset_type = 'ULTRA_DETAIL'
            
            # Performance tips
            if vertex_count > 100000:
                vertices_box.separator()
                tip_box = vertices_box.box()
                tip_box.label(text="💡 Performance Tips:", icon='INFO')
                tip_box.label(text="• Use lower subdivision levels")
                tip_box.label(text="• Reduce base vertex count first")
                tip_box.label(text="• Consider using displacement instead")


class MESH_OT_terrain_info(bpy.types.Operator):
    """Show information about the Terrain Generator addon"""
    bl_idname = "mesh.terrain_info"
    bl_label = "About Terrain Generator"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        return {'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self, width=500)
    
    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            return {'CANCELLED'}
        return {'PASS_THROUGH'}
    
    def draw(self, context):
        layout = self.layout
        
        # Title
        row = layout.row()
        row.alignment = 'CENTER'
        row.label(text="Terra Forge", icon='WORLD_DATA')
        
        layout.separator()
        
        # Creator info
        box = layout.box()
        box.label(text="Created by: Amélie Schroeder", icon='USER')
        box.label(text="Contact: amelieschroeder.ch@gmail.com")
        
        layout.separator()
        
        # Description
        box = layout.box()
        box.label(text="About this addon:", icon='INFO')
        box.label(text="This powerful terrain generator allows you to create")
        box.label(text="stunning procedural landscapes with just a few clicks! 🎨")
        box.label(text="")
        box.label(text="✨ Features:")
        box.label(text="• 6 Built-in terrain presets (Desert, Mountains, etc.)")
        box.label(text="• Procedural vegetation system 🌲🌸🌱")
        box.label(text="• Dynamic water/ice system 🌊❄️")
        box.label(text="• Material quick-selection")
        box.label(text="• Performance optimization tools ⚡")
        
        layout.separator()
        
        # How to use
        box = layout.box()
        box.label(text="🚀 Quick Start Guide:")
        box.label(text="1) Click 'Add Terrain' to create your base terrain")
        box.label(text="2) Choose a preset from the 'Terrain Presets' section")
        box.label(text="3) Add vegetation from the 'Vegetation' section")
        box.label(text="4) Toggle water/ice if needed 💧")
        box.label(text="5) Fine-tune with 'Terrain Customization'")
        box.label(text="6) Optimize performance with vertex controls")
        box.label(text="7) Same goes for 'Planet Mode'  (more to come!)")
        
        layout.separator()
        
        # Tips
        box = layout.box()
        box.label(text="Pro Tips:", icon='LIGHT')
        box.label(text="• Use Cycles for the default textures")
        box.label(text="• Add HDRI for best results!")
        box.label(text="• Use 'Update/Debug Terrain' if changes don't apply")
        box.label(text="• Start with low vertex counts for better performance")
        box.label(text="• Create collections for trees/flowers before using them")
        
        layout.separator()
        
        # Version info
        box = layout.box()
        box.label(text="Version Info:", icon='PROPERTIES')
        box.label(text="Version: 1.0")
        box.label(text="Compatible with: Blender 3.0+")
        
        layout.separator()
        
        # Thank you message
        row = layout.row()
        row.alignment = 'CENTER'
        row.label(text="🙏 Thank you for using Terrain Generator! 🙏")
        
        row = layout.row()
        row.alignment = 'CENTER'
        row.label(text="HAPPY TERRAIN BUILDING! 🏔️🌋🏝️")


# PlANET OPERATOR CLASSES
class MESH_OT_add_planet(bpy.types.Operator):
    """Add a procedural planet"""
    bl_idname = "mesh.add_planet"
    bl_label = "Add Planet"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Create planet and apply current scene settings
        planet_obj = create_planet_node_setup(context)
        return {'FINISHED'}

class MESH_OT_update_planet(bpy.types.Operator):
    """Update the existing planet settings"""
    bl_idname = "mesh.update_planet"
    bl_label = "Update Planet"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        updated = False
        for obj in bpy.data.objects:
            if obj.name.startswith("Planet") and "PlanetGenerator" in obj.modifiers:
                modifier = obj.modifiers.get("PlanetGenerator")
                if modifier and modifier.node_group:
                    # Update planet group node inputs
                    for node in modifier.node_group.nodes:
                        if node.type == 'GROUP' and node.name == "Group":
                            node.inputs[0].default_value = context.scene.seed
                            node.inputs[1].default_value = context.scene.sphere_segments 
                            node.inputs[2].default_value = context.scene.sphere_rings     
                            node.inputs[3].default_value = context.scene.sphere_radius   
                            node.inputs[4].default_value = context.scene.scale          
                            node.inputs[5].default_value = context.scene.detail         
                            node.inputs[6].default_value = context.scene.terrain_level  
                            node.inputs[7].default_value = context.scene.ground_level   
                            node.inputs[8].default_value = context.scene.crater_peaks   
                            node.inputs[9].default_value = context.scene.mt_height      
                            node.inputs[10].default_value = context.scene.rocky_surface 
                            node.inputs[11].default_value = context.scene.terraces      
                            node.inputs[12].default_value = context.scene.coast         
                            updated = True
                    
                    # Update vegetation and material options (same as terrain)
                    for node in modifier.node_group.nodes:
                        if node.name == "Distribute Points on Faces":
                            node.inputs["Density Max"].default_value = context.scene.tree_count
                        elif node.name == "Collection Info":
                            node.inputs[0].default_value = context.scene.tree_collection
                        elif node.name == "Switch" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_trees
                        elif node.name == "Distribute Points_Flowers":
                            node.inputs["Density Max"].default_value = context.scene.flowers_count
                        elif node.name == "Collection Info_Flowers":
                            node.inputs[0].default_value = context.scene.flowers_collection
                        elif node.name == "Switch_Flowers" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_flowers
                        elif node.name == "Distribute Points_Grass":
                            node.inputs["Density Max"].default_value = context.scene.grass_count
                        elif node.name == "Collection Info_Grass":
                            node.inputs[0].default_value = context.scene.grass_collection
                        elif node.name == "Switch_Grass" and node.input_type == 'GEOMETRY':
                            node.inputs[0].default_value = context.scene.the_grass
                        elif node.name == "Instance on Points":
                            node.inputs["Scale"].default_value = (context.scene.tree_scale, context.scene.tree_scale, context.scene.tree_scale)
                        elif node.name == "Instance on Points_Flowers":
                            node.inputs["Scale"].default_value = (context.scene.flowers_scale, context.scene.flowers_scale, context.scene.flowers_scale)
                        elif node.name == "Instance on Points_Grass":
                            node.inputs["Scale"].default_value = (context.scene.grass_scale, context.scene.grass_scale, context.scene.grass_scale)
                    
                    # Update material options
                    for node in modifier.node_group.nodes:
                        if node.type == 'GROUP' and node.name == "Group" and node.node_tree:
                            # Update terrain material in the inner node group
                            for inner_node in node.node_tree.nodes:
                                if inner_node.name == "Set Material":
                                    inner_node.inputs[2].default_value = context.scene.terrain_material
                
                # Force a view update
                context.view_layer.update()
                break
        
        return {'FINISHED'}

# PlANET PRESET OPERATORS
class MESH_OT_apply_earth_preset(bpy.types.Operator):
    """Apply Earth planet preset"""
    bl_idname = "mesh.apply_earth_preset"
    bl_label = "Earth"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_earth_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_mars_preset(bpy.types.Operator):
    """Apply Mars planet preset"""
    bl_idname = "mesh.apply_mars_preset"
    bl_label = "Mars"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_mars_preset(self, context)
        return {'FINISHED'}

class MESH_OT_apply_moon_preset(bpy.types.Operator):
    """Apply Moon planet preset"""
    bl_idname = "mesh.apply_moon_preset"
    bl_label = "Moon"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        apply_moon_preset(self, context)
        return {'FINISHED'}


# REGISTER ALL CLASSES AND PROPS
def register():
    bpy.utils.register_class(MESH_OT_add_terrain)
    bpy.utils.register_class(MESH_OT_update_terrain)
    bpy.utils.register_class(MESH_OT_apply_desert_preset)
    bpy.utils.register_class(MESH_OT_apply_mountains_preset)
    bpy.utils.register_class(MESH_OT_apply_island_preset)
    bpy.utils.register_class(MESH_OT_apply_canyon_preset)
    bpy.utils.register_class(MESH_OT_apply_tundra_preset)
    bpy.utils.register_class(MESH_OT_apply_shore_preset)
    bpy.utils.register_class(MATERIAL_OT_set_terrain_material)
    bpy.utils.register_class(MATERIAL_OT_set_water_material)  
    bpy.utils.register_class(MESH_OT_simplify_terrain)
    bpy.utils.register_class(MESH_OT_set_performance_preset) 
    bpy.utils.register_class(MESH_OT_terrain_info)
    bpy.utils.register_class(MESH_OT_add_planet)
    bpy.utils.register_class(MESH_OT_update_planet)
    bpy.utils.register_class(MESH_OT_apply_earth_preset)
    bpy.utils.register_class(MESH_OT_apply_mars_preset)
    bpy.utils.register_class(MESH_OT_apply_moon_preset)
    bpy.utils.register_class(MY_PT_CustomPanel)
    
    
    #REGISTER CUSTOM PROPS
    bpy.types.Scene.show_materials = BoolProperty(
        name="Show Materials",
        description="Show or hide material settings",
        default=False
    )
    
    # Add material selection properties
    bpy.types.Scene.terrain_material = PointerProperty(
        name="Terrain Material",
        description="Material to apply to the terrain",
        type=bpy.types.Material,
        update=update_terrain_material
    )
    
    bpy.types.Scene.water_material = PointerProperty(
        name="Water Material",
        description="Material to apply to the water/ice",
        type=bpy.types.Material,
        update=update_water_material
    )
    
    bpy.types.Scene.show_presets = BoolProperty(
        name="Show Presets",
        description="Show or hide terrain presets",
        default=False
    )
    
    bpy.types.Scene.show_flora = BoolProperty(
        name="Show Flora Settings",
        description="Show or hide flora settings",
        default=False
    )
    
    bpy.types.Scene.the_trees = BoolProperty(
        name="Trees",
        description="Add trees to the terrain",
        default=False,
        update=update_trees_checkbox
    )
    
    bpy.types.Scene.tree_count = IntProperty(
        name="Tree Count",
        description="Number of trees",
        default=5,
        min=1,
        max=100,
        update=update_tree_count
    )
    
    bpy.types.Scene.tree_collection = PointerProperty(
        name="Trees Collection",
        description="Collection containing tree objects to instance",
        type=bpy.types.Collection,
        update=update_tree_collection
    )

    bpy.types.Scene.tree_scale = FloatProperty(
        name="Scale",
        description="Scale of the trees",
        default=1.0,
        min=0.001,
        max=5.0,
        step=0.1,
        precision=2,
        update=update_tree_scale
    )
    
    bpy.types.Scene.the_flowers = BoolProperty(
        name="Flowers",
        description="Add flowers to the terrain",
        default=False,
        update=update_flowers_checkbox
    )
    
    bpy.types.Scene.flowers_collection = PointerProperty(
        name="Flowers Collection",
        description="Collection containing flower objects to instance",
        type=bpy.types.Collection,
        update=update_flowers_collection
    )
    
    bpy.types.Scene.flowers_count = IntProperty(
        name="Flowers Count",
        description="Number of flowers",
        default=20,
        min=1,
        max=500,
        update=update_flowers_count
    )

    bpy.types.Scene.flowers_scale = FloatProperty(
        name="Scale", 
        description="Scale of the flowers",
        default=1.0,
        min=0.001,
        max=5.0,
        step=0.1,
        precision=2,
        update=update_flowers_scale
    )
    
    bpy.types.Scene.the_grass = BoolProperty(
        name="Grass",
        description="Add grass to the terrain",
        default=False,
        update=update_grass_checkbox
    )
    
    bpy.types.Scene.grass_collection = PointerProperty(
        name="Grass Collection",
        description="Collection containing grass objects to instance",
        type=bpy.types.Collection,
        update=update_grass_collection
    )
    
    bpy.types.Scene.grass_count = IntProperty(
        name="Grass Count",
        description="Density of grass",
        default=100,
        min=1,
        max=1000,
        update=update_grass_count
    )

    bpy.types.Scene.grass_scale = FloatProperty(
        name="Scale",
        description="Scale of the grass",
        default=1.0,
        min=0.001,
        max=5.0,
        step=0.1,
        precision=2,
        update=update_grass_scale
    )

    bpy.types.Scene.the_seagrass = BoolProperty(
        name="Sea Grass",
        description="Add sea grass underwater",
        default=False,
        update=update_seagrass_checkbox
    )

    bpy.types.Scene.seagrass_collection = PointerProperty(
        name="Sea Grass Collection",
        description="Collection containing sea grass objects to instance",
        type=bpy.types.Collection,
        update=update_seagrass_collection
    )

    bpy.types.Scene.seagrass_count = IntProperty(
        name="Sea Grass Count",
        description="Density of sea grass",
        default=50,
        min=1,
        max=500,
        update=update_seagrass_count
    )

    bpy.types.Scene.seagrass_scale = FloatProperty(
        name="Scale",
        description="Scale of the sea grass",
        default=1.0,
        min=0.001,
        max=5.0,
        step=0.1,
        precision=2,
        update=update_seagrass_scale
    )
    
    bpy.types.Scene.the_water = BoolProperty(
        name="Water",
        description="Add water to the terrain",
        default=False,
        update=update_water_checkbox
    )
    
    bpy.types.Scene.water_level = FloatProperty(
        name="Water Level",
        description="Set the level of the water",
        default=0.4,
        min=0.0,
        max=10.0,
        step=0.1,
        precision=2,
        update=update_water_level
    )
    
    bpy.types.Scene.water_scale_x = FloatProperty(
        name="Water Size X",
        description="Set the X size of the water plane",
        default=6.0,
        min=0.1,
        max=100.0,
        step=0.1,
        precision=2,
        update=update_water_scale_x
    )
    
    bpy.types.Scene.water_scale_y = FloatProperty(
        name="Water Size Y",
        description="Set the Y size of the water plane",
        default=6.0,
        min=0.1,
        max=100.0,
        step=0.1,
        precision=2,
        update=update_water_scale_y
    )
    
    bpy.types.Scene.size_x = FloatProperty(
        name="Size X",
        description="Width of the terrain",
        default=6.0,
        min=0.0,
        max=100.0,
        step=0.1,
        precision=2,
        update=update_size_x
    )
    
    bpy.types.Scene.size_y = FloatProperty(
        name="Size Y",
        description="Length of the terrain",
        default=6.0,
        min=0.0,
        max=100.0,
        step=0.1,
        precision=2,
        update=update_size_y
    )

    bpy.types.Scene.seed = IntProperty(
        name="Seed",
        description="Random seed for terrain generation",
        default=1,
        min=-2147483648,
        max=2147483647,
        update=update_seed
    )
    
    bpy.types.Scene.scale = FloatProperty(
        name="Scale",
        description="Overall scale of the terrain features",
        default=0.68,
        min=-1000.0,
        max=1000.0,
        step=0.1,
        precision=2,
        update=update_scale
    )
    
    bpy.types.Scene.detail = FloatProperty(
        name="Detail",
        description="Level of detail in the terrain",
        default=15.0,
        min=0.0,
        max=15.0,
        step=0.1,
        precision=2,
        update=update_detail
    )
    
    bpy.types.Scene.terrain_level = FloatProperty(
        name="Terrain Level",
        description="Base height level of the terrain",
        default=0.4,
        min=-10.0,
        max=10.0,
        step=0.1,
        precision=2,
        update=update_terrain_level
    )
    
    bpy.types.Scene.ground_level = FloatProperty(
        name="Ground Level",
        description="Height of the lower terrain",
        default=0.0,
        min=-10.0,
        max=10.0,
        step=0.1,
        precision=2,
        update=update_ground_level
    )
    
    bpy.types.Scene.crater_peaks = FloatProperty(
        name="Crater-Peaks",
        description="Intensity of craters and peaks",
        default=1.0,
        min=-10.0,
        max=10.0,
        step=0.1,
        precision=2,
        update=update_crater_peaks
    )
    
    bpy.types.Scene.mt_height = FloatProperty(
        name="Mt Height",
        description="Height of mountains",
        default=0.0,
        min=0.0,
        max=10.0,
        step=0.1,
        precision=2,
        update=update_mt_height
    )
    
    bpy.types.Scene.rocky_surface = FloatProperty(
        name="Rocky Surface",
        description="Roughness of the terrain surface",
        default=0.0,
        min=0.0,
        max=0.1,
        step=0.01,
        precision=3,
        update=update_rocky_surface
    )
    
    bpy.types.Scene.terraces = FloatProperty(
        name="Terraces",
        description="Terrace intensity",
        default=1.0,
        min=0.0,
        max=1.0,
        step=0.1,
        precision=2,
        update=update_terraces
    )
    
    bpy.types.Scene.coast = FloatProperty(
        name="Coast",
        description="Coastal feature intensity",
        default=1.0,
        min=0.0,
        max=1.0,
        step=0.1,
        precision=2,
        update=update_coast
    )

    bpy.types.Scene.vertices_x = IntProperty(
        name="Vertices X",
        description="Number of vertices along X axis",
        default=100,  
        min=2,
        max=1000,
        update=update_vertices_x
    )

    bpy.types.Scene.vertices_y = IntProperty(
        name="Vertices Y", 
        description="Number of vertices along Y axis",
        default=100,  
        min=2,
        max=1000,
        update=update_vertices_y
    )

    bpy.types.Scene.subdivision = IntProperty(
        name="Subdivision",
        description="Subdivision level (adds detail but increases vertex count exponentially)",
        default=3,
        min=0,
        max=4,  # Reduced max to prevent crashes
        update=update_subdivision
    )

    # Planet mode toggle
    bpy.types.Scene.planet_mode = BoolProperty(
        name="Planet Mode",
        description="Switch between terrain (plane) and planet (sphere) generation",
        default=False,
        update=update_planet_mode
    )
    
    # Planet presets collapsible
    bpy.types.Scene.show_planet_presets = BoolProperty(
        name="Show Planet Presets",
        description="Show or hide planet presets",
        default=False
    )
    
    # Planet-specific properties
    bpy.types.Scene.sphere_radius = FloatProperty(
        name="Sphere Radius",
        description="Radius of the planet sphere",
        default=5.0,
        min=0.1,
        max=50.0,
        step=0.1,
        precision=2,
        update=update_sphere_radius
    )
    
    bpy.types.Scene.sphere_segments = IntProperty(
        name="Sphere Segments",
        description="Number of segments (longitude divisions) for the planet sphere",
        default=64, 
        min=3,
        max=500,
        update=update_sphere_segments
    )
    
    bpy.types.Scene.sphere_rings = IntProperty(
        name="Sphere Rings", 
        description="Number of rings (latitude divisions) for the planet sphere",
        default=32,  
        min=3,
        max=500,
        update=update_sphere_rings
    )

    bpy.types.Scene.tree_exclusion_distance = FloatProperty(
        name="Tree Exclusion Distance",
        description="Minimum distance other vegetation keeps from trees",
        default=0.5,
        min=0.0,
        max=2.0,
        step=0.1,
        precision=2,
        update=update_tree_exclusion_distance
    )

# UNREGISTER ALL CLASSES AND PROPS
def unregister():
    bpy.utils.unregister_class(MY_PT_CustomPanel)
    bpy.utils.unregister_class(MESH_OT_update_terrain)
    bpy.utils.unregister_class(MESH_OT_add_terrain)
    bpy.utils.unregister_class(MESH_OT_apply_desert_preset)
    bpy.utils.unregister_class(MESH_OT_apply_mountains_preset)
    bpy.utils.unregister_class(MESH_OT_apply_island_preset)
    bpy.utils.unregister_class(MESH_OT_apply_canyon_preset)
    bpy.utils.unregister_class(MESH_OT_apply_tundra_preset)
    bpy.utils.unregister_class(MESH_OT_apply_shore_preset)
    bpy.utils.register_class(MESH_OT_terrain_info) 
    bpy.utils.unregister_class(MATERIAL_OT_set_terrain_material)
    bpy.utils.unregister_class(MATERIAL_OT_set_water_material)
    bpy.utils.unregister_class(MESH_OT_simplify_terrain)
    bpy.utils.unregister_class(MESH_OT_set_performance_preset)
    bpy.utils.unregister_class(MESH_OT_add_planet)
    bpy.utils.unregister_class(MESH_OT_update_planet)
    bpy.utils.unregister_class(MESH_OT_apply_earth_preset)
    bpy.utils.unregister_class(MESH_OT_apply_mars_preset)
    bpy.utils.unregister_class(MESH_OT_apply_moon_preset)
    
    # UNREGISTER CUSTOM PROPS
    del bpy.types.Scene.show_materials
    del bpy.types.Scene.terrain_material
    del bpy.types.Scene.water_material
    del bpy.types.Scene.show_presets
    del bpy.types.Scene.show_flora
    del bpy.types.Scene.the_trees
    del bpy.types.Scene.tree_count
    del bpy.types.Scene.tree_collection
    del bpy.types.Scene.the_flowers
    del bpy.types.Scene.flowers_collection
    del bpy.types.Scene.flowers_count
    del bpy.types.Scene.the_grass
    del bpy.types.Scene.grass_collection
    del bpy.types.Scene.grass_count
    del bpy.types.Scene.tree_scale
    del bpy.types.Scene.flowers_scale  
    del bpy.types.Scene.grass_scale
    del bpy.types.Scene.the_seagrass
    del bpy.types.Scene.seagrass_collection
    del bpy.types.Scene.seagrass_count
    del bpy.types.Scene.seagrass_scale
    del bpy.types.Scene.the_water
    del bpy.types.Scene.water_level
    del bpy.types.Scene.water_scale_x
    del bpy.types.Scene.water_scale_y
    del bpy.types.Scene.size_x
    del bpy.types.Scene.size_y
    del bpy.types.Scene.seed
    del bpy.types.Scene.scale
    del bpy.types.Scene.detail
    del bpy.types.Scene.terrain_level
    del bpy.types.Scene.ground_level
    del bpy.types.Scene.crater_peaks
    del bpy.types.Scene.mt_height
    del bpy.types.Scene.rocky_surface
    del bpy.types.Scene.terraces
    del bpy.types.Scene.coast
    del bpy.types.Scene.vertices_x
    del bpy.types.Scene.vertices_y
    del bpy.types.Scene.subdivision
    del bpy.types.Scene.planet_mode
    del bpy.types.Scene.show_planet_presets
    del bpy.types.Scene.sphere_radius
    del bpy.types.Scene.sphere_segments  
    del bpy.types.Scene.sphere_rings
    del bpy.types.Scene.tree_exclusion_distance

if __name__ == "__main__":
    register()